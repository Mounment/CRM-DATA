--dbo.m_dm_txn_90d
--m2_txn_d_f_r_c_m
--m2_txn_main_type
--m2_txn_main_source
--m2_txn_overall

DROP TABLE if exists model.m2_txn_cust_str_fst NO DELAY;
CREATE TABLE model.m2_txn_cust_str_fst
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m2_txn_cust_str_fst',
 '{replica}')
ORDER BY cut_off AS
select
cut_off
,buyer_id 
,merchant_code as txn_m2_str_fst

from
(select 
cut_off
,buyer_id 
,voc.merchant_code --门店编号
,row_number()over(partition by buyer_id order by payment_date) as txn_ord --客户交易先后顺序的排
from model.m_dm_txn_all voc
where payment_date >= toDate('2019-06-07')  --仅取开业之后数据 
) as m
where txn_ord =1;
--6s

DROP TABLE if exists model.m2_txn_cust_rfm no delay;
CREATE TABLE model.m2_txn_cust_rfm
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m2_txn_cust_rfm',
 '{replica}')
ORDER BY cut_off AS
select 
txn.cut_off as cut_off
,buyer_id
,count(distinct source_type) as txn_m2_scr_d
,count(distinct merchant_code) as txn_m2_str_d
,count(distinct txn_type) as txn_m2_type_d
,count(distinct order_code) as txn_m2_cust_f
,dateDiff('day',max(payment_date),txn.cut_off) as txn_m2_cust_r
,toInt64(case when count(distinct order_code) =1 then -99
else dateDiff('day',min(payment_date),max(payment_date))/(count(distinct order_code) -1)
end) as txn_m2_cust_pc
,sum(payment_amt) as txn_m2_cust_m
,round(sum(payment_amt)/count(distinct order_code),2) as txn_m2_cust_atv
,(sum(lst_wk_txn) - sum(pre_lst_wk_txn)) as txn_m2_cust_m_ch
,round((sum(payment_amt)/avg_base_payment_amt),4) as txn_m2_cust_cmp
,count(distinct case when toDate(payment_date) > addWeeks(txn.cut_off,-2) then order_code end)
- count(distinct case when toDate(payment_date) <= addWeeks(txn.cut_off,-2) and toDate(payment_date) > addWeeks(txn.cut_off,-4) then order_code end) as txn_m2_cust_f_ch

from 
(select *, 
case when source_type in ('O2O_B2C','O2O_DFS','NDD') then 'online' 
when source_type in('SCAN_QR_CODE','POS','MOBILE_POS') then 'offline'
else 'others' 
end as txn_type 
,case when toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end as lst_wk_txn
,case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end as pre_lst_wk_txn
from model.m_dm_txn_90d
) as txn
inner join (select 
cut_off
,round((sum(payment_amt)/count(distinct buyer_id)),2)as avg_base_payment_amt
from model.m_dm_txn_90d txn
group by cut_off) as m1
on txn.cut_off = m1.cut_off
group by txn.cut_off,buyer_id,avg_base_payment_amt;
--4s


--main store
DROP TABLE if exists model.m2_txn_cust_str_main no delay;
CREATE TABLE model.m2_txn_cust_str_main
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m2_txn_cust_str_main',
 '{replica}')
ORDER BY cut_off AS
select cut_off 
,buyer_id
,merchant_code as txn_m2_str_main

from
(select 
cut_off
,buyer_id 
,voc.merchant_code --门店编号
,count(distinct order_code) as merch_txn_cnt --txn count in each store 
,row_number()over(partition by cut_off,buyer_id order by count(distinct order_code) desc) as merch_ord
from model.m_dm_txn_90d voc
group by cut_off,buyer_id, merchant_code
) as t
where t.merch_ord =1;
--2s

DROP TABLE if exists model.m2_txn_cust_type_main no delay;
CREATE TABLE model.m2_txn_cust_type_main
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m2_txn_cust_type_main',
 '{replica}')
ORDER BY cut_off AS
select cut_off 
,buyer_id 
,txn_type as txn_m2_type_main

from 
(select 
txn.cut_off
,txn.buyer_id 
,(case when source_type in ('O2O_B2C','O2O_DFS','NDD') then 'online' 
when source_type in('SCAN_QR_CODE','POS','MOBILE_POS') then 'offline'
else 'others' 
end) as txn_type 
,row_number()over(partition by cut_off,buyer_id order by count(distinct order_code)desc) as rw
from model.m_dm_txn_90d txn
group by txn.cut_off,txn.buyer_id 
,case when source_type in ('O2O_B2C','O2O_DFS','NDD') then 'online' 
when source_type in('SCAN_QR_CODE','POS','MOBILE_POS') then 'offline'
else 'others' 
end) as m
where rw =1;


DROP TABLE if exists model.m2_txn_cust_scr_main no delay;
CREATE TABLE model.m2_txn_cust_scr_main
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m2_txn_cust_scr_main',
 '{replica}')
ORDER BY cut_off AS
select cut_off 
,buyer_id 
,source_type as txn_m2_scr_main

from 
(select 
txn.cut_off
,txn.buyer_id 
,source_type 
,row_number()over(partition by cut_off,buyer_id order by count(distinct order_code)desc) as rw
from model.m_dm_txn_90d txn
group by txn.cut_off,txn.buyer_id,source_type ) as m
where rw =1;
--2s


DROP TABLE if exists model.m2_txn_overall_final no delay;
CREATE TABLE model.m2_txn_overall_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m2_txn_overall_final',
 '{replica}')
ORDER BY cut_off AS
select 
u.cut_off as cut_off
,u.buyer_id as buyer_id
,txn_m2_cust_pc
,txn_m2_cust_r
,txn_m2_cust_f
,txn_m2_cust_f_ch
,txn_m2_cust_m
,txn_m2_cust_m_ch
,txn_m2_cust_cmp
,txn_m2_cust_atv
,txn_m2_type_main
,txn_m2_type_d
,txn_m2_scr_main
,txn_m2_scr_d
,txn_m2_str_fst
,txn_m2_str_main
,txn_m2_str_d

from model.m_ouser_all u
left join model.m2_txn_cust_rfm a 
on u.buyer_id = a.buyer_id and u.cut_off = a.cut_off 
left join model.m2_txn_cust_type_main b
on u.buyer_id = b.buyer_id and u.cut_off = b.cut_off 
left join model.m2_txn_cust_scr_main c
on u.buyer_id = c.buyer_id and u.cut_off = c.cut_off
left join model.m2_txn_cust_str_main d
on u.buyer_id = d.buyer_id and u.cut_off = d.cut_off
left join model.m2_txn_cust_str_fst e
on u.buyer_id = e.buyer_id and u.cut_off = e.cut_off;