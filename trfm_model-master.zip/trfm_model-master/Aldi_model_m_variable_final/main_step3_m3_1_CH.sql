--model.m_dm_txn_all
--model.m_dm_txn_90d

--商品首次卖出的日期作为商品上架日期
DROP TABLE if exists model.m3_prod_os_lk no delay;
CREATE TABLE model.m3_prod_os_lk
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m3_prod_os_lk',
 '{replica}')
ORDER BY cut_off AS
select cut_off 
,item_code
,on_sale_date

from 
(select cut_off
,item_code
,toDate(payment_date) as on_sale_date
,row_number()over(partition by item_code order by payment_date) as cn
from model.m_dm_txn_all
)m 
where cn = 1;
--9s

--RFM of each vertical including diversity/recency/frequency/monetry/purchase cycle/monetry change/frequency change
DROP TABLE if exists model.m3_txn_vrt_rfm no delay;
CREATE TABLE model.m3_txn_vrt_rfm
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m3_txn_vrt_rfm',
 '{replica}')
ORDER BY cut_off AS
select 
cut_off
,buyer_id
,count(distinct item_category_name) as txn_m3_vtc_d
,count(distinct sub_1) as txn_m3_01_d
,count(distinct sub_2) as txn_m3_02_d
,count(distinct sub_3) as txn_m3_03_d
,count(distinct sub_4) as txn_m3_04_d
,count(distinct sub_5) as txn_m3_05_d
,count(distinct sub_6) as txn_m3_06_d
,count(distinct sub_7) as txn_m3_07_d
,count(distinct sub_8) as txn_m3_08_d
,count(distinct sub_9) as txn_m3_09_d
,count(distinct sub_10) as txn_m3_10_d
,count(distinct sub_11) as txn_m3_11_d
--,count(distinct sub_12)txn_m3_12_d
--,count(distinct sub_13)txn_m3_13_d
,count(distinct sub_14) as txn_m3_14_d
--,count(distinct sub_15)txn_m3_15_d
,count(distinct sub_16) as txn_m3_16_d
,count(distinct sub_17) as txn_m3_17_d
,count(distinct ord_1) as txn_m3_01_f
,count(distinct ord_2) as txn_m3_02_f
,count(distinct ord_3) as txn_m3_03_f
,count(distinct ord_4) as txn_m3_04_f
,count(distinct ord_5) as txn_m3_05_f
,count(distinct ord_6) as txn_m3_06_f
,count(distinct ord_7) as txn_m3_07_f
,count(distinct ord_8) as txn_m3_08_f
,count(distinct ord_9) as txn_m3_09_f
,count(distinct ord_10) as txn_m3_10_f
,count(distinct ord_11) as txn_m3_11_f
--,count(distinct ord_12)txn_m3_12_f
--,count(distinct ord_13)txn_m3_13_f
,count(distinct ord_14) as txn_m3_14_f
--,count(distinct ord_15)txn_m3_15_f
,count(distinct ord_16) as txn_m3_16_f
,count(distinct ord_17) as txn_m3_17_f
,(case when count(distinct ord_1) > 0 then dateDiff('day',max(dt_1),cut_off) else 9999 end) as txn_m3_01_r
,(case when count(distinct ord_2) > 0 then dateDiff('day',max(dt_2),cut_off) else 9999 end) as txn_m3_02_r
,(case when count(distinct ord_3) > 0 then dateDiff('day',max(dt_3),cut_off) else 9999 end) as txn_m3_03_r
,(case when count(distinct ord_4) > 0 then dateDiff('day',max(dt_4),cut_off) else 9999 end) as txn_m3_04_r
,(case when count(distinct ord_5) > 0 then dateDiff('day',max(dt_5),cut_off) else 9999 end) as txn_m3_05_r
,(case when count(distinct ord_6) > 0 then dateDiff('day',max(dt_6),cut_off) else 9999 end) as txn_m3_06_r
,(case when count(distinct ord_7) > 0 then dateDiff('day',max(dt_7),cut_off) else 9999 end) as txn_m3_07_r
,(case when count(distinct ord_8) > 0 then dateDiff('day',max(dt_8),cut_off) else 9999 end) as txn_m3_08_r
,(case when count(distinct ord_9) > 0 then dateDiff('day',max(dt_9),cut_off) else 9999 end) as txn_m3_09_r
,(case when count(distinct ord_10) > 0 then dateDiff('day',max(dt_10),cut_off) else 9999 end) as txn_m3_10_r
,(case when count(distinct ord_11) > 0 then dateDiff('day',max(dt_11),cut_off) else 9999 end) as txn_m3_11_r
--,(case when count(distinct ord_12) > 0 then dateDiff('day',max(dt_12),cut_off) else 9999 end) as txn_m3_12_r
--,(case when count(distinct ord_13) > 0 then dateDiff('day',max(dt_13),cut_off) else 9999 end) as txn_m3_13_r
,(case when count(distinct ord_14) > 0 then dateDiff('day',max(dt_14),cut_off) else 9999 end) as txn_m3_14_r
--,(case when count(distinct ord_15) > 0 then dateDiff('day',max(dt_15),cut_off) else 9999 end) as txn_m3_15_r
,(case when count(distinct ord_16) > 0 then dateDiff('day',max(dt_16),cut_off) else 9999 end) as txn_m3_16_r
,(case when count(distinct ord_17) > 0 then dateDiff('day',max(dt_17),cut_off) else 9999 end) as txn_m3_17_r
,(case when count(distinct ord_1) >0 then sum(amt_1) else 0 end) as txn_m3_01_m
,(case when count(distinct ord_2) >0 then sum(amt_2) else 0 end) as txn_m3_02_m
,(case when count(distinct ord_3) >0 then sum(amt_3) else 0 end) as txn_m3_03_m
,(case when count(distinct ord_4) >0 then sum(amt_4) else 0 end) as txn_m3_04_m
,(case when count(distinct ord_5) >0 then sum(amt_5) else 0 end) as txn_m3_05_m
,(case when count(distinct ord_6) >0 then sum(amt_6) else 0 end) as txn_m3_06_m
,(case when count(distinct ord_7) >0 then sum(amt_7) else 0 end) as txn_m3_07_m
,(case when count(distinct ord_8) >0 then sum(amt_8) else 0 end) as txn_m3_08_m
,(case when count(distinct ord_9) >0 then sum(amt_9) else 0 end) as txn_m3_09_m
,(case when count(distinct ord_10) >0 then sum(amt_10) else 0 end) as txn_m3_10_m
,(case when count(distinct ord_11) >0 then sum(amt_11) else 0 end) as txn_m3_11_m
--,(case when count(distinct ord_12) >0 then sum(amt_12) else 0 end) as txn_m3_12_m
--,(case when count(distinct ord_13) >0 then sum(amt_13) else 0 end) as txn_m3_13_m
,(case when count(distinct ord_14) >0 then sum(amt_14) else 0 end) as txn_m3_14_m
--,(case when count(distinct ord_15) >0 then sum(amt_15) else 0 end) as txn_m3_15_m
,(case when count(distinct ord_16) >0 then sum(amt_16) else 0 end) as txn_m3_16_m
,(case when count(distinct ord_17) >0 then sum(amt_17) else 0 end) as txn_m3_17_m
,(case when count(distinct ord_1) = 0 then 9999
when count(distinct ord_1) =1 then -99
when count(distinct ord_1) > 1 then dateDiff('day',min(dt_1),max(dt_1))/(count(distinct ord_1) -1) end) as txn_m3_01_pc
,(case when count(distinct ord_2) = 0 then 9999
when count(distinct ord_2) =1 then -99
when count(distinct ord_2) > 1 then dateDiff('day',min(dt_2),max(dt_2))/(count(distinct ord_2) -1) end) as txn_m3_02_pc
,(case when count(distinct ord_3) = 0 then 9999
when count(distinct ord_3) =1 then -99
when count(distinct ord_3) > 1 then dateDiff('day',min(dt_3),max(dt_3))/(count(distinct ord_3) -1) end) as txn_m3_03_pc
,(case when count(distinct ord_4) = 0 then 9999
when count(distinct ord_4) =1 then -99
when count(distinct ord_4) > 1 then dateDiff('day',min(dt_4),max(dt_4))/(count(distinct ord_4) -1) end) as txn_m3_04_pc
,(case when count(distinct ord_5) = 0 then 9999
when count(distinct ord_5) =1 then -99
when count(distinct ord_5) > 1 then dateDiff('day',min(dt_5),max(dt_5))/(count(distinct ord_5) -1) end) as txn_m3_05_pc
,(case when count(distinct ord_6) = 0 then 9999
when count(distinct ord_6) =1 then -99
when count(distinct ord_6) > 1 then dateDiff('day',min(dt_6),max(dt_6))/(count(distinct ord_6) -1) end) as txn_m3_06_pc
,(case when count(distinct ord_7) = 0 then 9999
when count(distinct ord_7) =1 then -99
when count(distinct ord_7) > 1 then dateDiff('day',min(dt_7),max(dt_7))/(count(distinct ord_7) -1) end) as txn_m3_07_pc
,(case when count(distinct ord_8) = 0 then 9999
when count(distinct ord_8) =1 then -99
when count(distinct ord_8) > 1 then dateDiff('day',min(dt_8),max(dt_8))/(count(distinct ord_8) -1) end) as txn_m3_08_pc
,(case when count(distinct ord_9) = 0 then 9999
when count(distinct ord_9) =1 then -99
when count(distinct ord_9) > 1 then dateDiff('day',min(dt_9),max(dt_9))/(count(distinct ord_9) -1) end) as txn_m3_09_pc
,(case when count(distinct ord_10) = 0 then 9999
when count(distinct ord_10) =1 then -99
when count(distinct ord_10) > 1 then dateDiff('day',min(dt_10),max(dt_10))/(count(distinct ord_10) -1) end) as txn_m3_10_pc
,(case when count(distinct ord_11) = 0 then 9999
when count(distinct ord_11) =1 then -99
when count(distinct ord_11) > 1 then dateDiff('day',min(dt_11),max(dt_11))/(count(distinct ord_11) -1) end) as txn_m3_11_pc
--,(case when count(distinct ord_12) = 0 then 9999
--when count(distinct ord_12) =1 then -99
--when count(distinct ord_12) > 1 then dateDiff('day',min(dt_12),max(dt_12))/(count(distinct ord_12) -1) end) as txn_m3_12_pc
--,(case when count(distinct ord_13) = 0 then 9999
--when count(distinct ord_13) =1 then -99
--when count(distinct ord_13) > 1 then dateDiff('day',min(dt_13),max(dt_13))/(count(distinct ord_13) -1) end) as txn_m3_13_pc
,(case when count(distinct ord_14) = 0 then 9999
when count(distinct ord_14) =1 then -99
when count(distinct ord_14) > 1 then dateDiff('day',min(dt_14),max(dt_14))/(count(distinct ord_14) -1) end) as txn_m3_14_pc
--,(case when count(distinct ord_15) = 0 then 9999
--when count(distinct ord_15) =1 then -99
--when count(distinct ord_15) > 1 then dateDiff('day',min(dt_15),max(dt_15))/(count(distinct ord_15) -1) end) as txn_m3_15_pc
,(case when count(distinct ord_16) = 0 then 9999
when count(distinct ord_16) =1 then -99
when count(distinct ord_16) > 1 then dateDiff('day',min(dt_16),max(dt_16))/(count(distinct ord_16) -1) end) as txn_m3_16_pc
,(case when count(distinct ord_17) = 0 then 9999
when count(distinct ord_17) =1 then -99
when count(distinct ord_17) > 1 then dateDiff('day',min(dt_17),max(dt_17))/(count(distinct ord_17) -1) end) as txn_m3_17_pc
,(sum(lst_wk_amt_1) - sum(pre_lst_wk_amt_1)) as txn_m3_01_m_ch
,(sum(lst_wk_amt_2) - sum(pre_lst_wk_amt_2)) as txn_m3_02_m_ch
,(sum(lst_wk_amt_3) - sum(pre_lst_wk_amt_3)) as txn_m3_03_m_ch
,(sum(lst_wk_amt_4) - sum(pre_lst_wk_amt_4)) as txn_m3_04_m_ch
,(sum(lst_wk_amt_5) - sum(pre_lst_wk_amt_5)) as txn_m3_05_m_ch
,(sum(lst_wk_amt_6) - sum(pre_lst_wk_amt_6)) as txn_m3_06_m_ch
,(sum(lst_wk_amt_7) - sum(pre_lst_wk_amt_7)) as txn_m3_07_m_ch
,(sum(lst_wk_amt_8) - sum(pre_lst_wk_amt_8)) as txn_m3_08_m_ch
,(sum(lst_wk_amt_9) - sum(pre_lst_wk_amt_9)) as txn_m3_09_m_ch
,(sum(lst_wk_amt_10) - sum(pre_lst_wk_amt_10)) as txn_m3_10_m_ch
,(sum(lst_wk_amt_11) - sum(pre_lst_wk_amt_11)) as txn_m3_11_m_ch
--,(sum(lst_wk_amt_12) - sum(pre_lst_wk_amt_12))txn_m3_12_m_ch
--,(sum(lst_wk_amt_13) - sum(pre_lst_wk_amt_13))txn_m3_13_m_ch
,(sum(lst_wk_amt_14) - sum(pre_lst_wk_amt_14)) as txn_m3_14_m_ch
--,(sum(lst_wk_amt_15) - sum(pre_lst_wk_amt_15))txn_m3_15_m_ch
,(sum(lst_wk_amt_16) - sum(pre_lst_wk_amt_16)) as txn_m3_16_m_ch
,(sum(lst_wk_amt_17) - sum(pre_lst_wk_amt_17)) as txn_m3_17_m_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_1 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_1 end) as txn_m3_01_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_2 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_2 end) as txn_m3_02_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_3 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_3 end) as txn_m3_03_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_4 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_4 end) as txn_m3_04_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_5 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_5 end) as txn_m3_05_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_6 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_6 end) as txn_m3_06_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_7 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_7 end) as txn_m3_07_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_8 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_8 end) as txn_m3_08_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_9 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_9 end) as txn_m3_09_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_10 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_10 end) as txn_m3_10_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_11 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_11 end) as txn_m3_11_f_ch
--,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_12 end)
--- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_12 end) txn_m3_12_f_ch
--,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_13 end)
--- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_13 end) txn_m3_13_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_14 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_14 end) as txn_m3_14_f_ch
--,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_15 end)
--- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_15 end) txn_m3_15_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_16 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_16 end) as txn_m3_16_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_17 end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_17 end) as txn_m3_17_f_ch
,(case when sum(payment_amt) >0 then round(sum(amt_1)/sum(payment_amt),2) else 0 end) as txn_m3_01_pct
,(case when sum(payment_amt) >0 then round(sum(amt_2)/sum(payment_amt),2) else 0 end) as txn_m3_02_pct
,(case when sum(payment_amt) >0 then round(sum(amt_3)/sum(payment_amt),2) else 0 end) as txn_m3_03_pct
,(case when sum(payment_amt) >0 then round(sum(amt_4)/sum(payment_amt),2) else 0 end) as txn_m3_04_pct
,(case when sum(payment_amt) >0 then round(sum(amt_5)/sum(payment_amt),2) else 0 end) as txn_m3_05_pct
,(case when sum(payment_amt) >0 then round(sum(amt_6)/sum(payment_amt),2) else 0 end) as txn_m3_06_pct
,(case when sum(payment_amt) >0 then round(sum(amt_7)/sum(payment_amt),2) else 0 end) as txn_m3_07_pct
,(case when sum(payment_amt) >0 then round(sum(amt_8)/sum(payment_amt),2) else 0 end) as txn_m3_08_pct
,(case when sum(payment_amt) >0 then round(sum(amt_9)/sum(payment_amt),2) else 0 end) as txn_m3_09_pct
,(case when sum(payment_amt) >0 then round(sum(amt_10)/sum(payment_amt),2) else 0 end) as txn_m3_10_pct
,(case when sum(payment_amt) >0 then round(sum(amt_11)/sum(payment_amt),2) else 0 end) as txn_m3_11_pct
--,(case when sum(payment_amt) >0 then round(sum(amt_12)/sum(payment_amt),2) else 0 end) as txn_m3_12_pct
--,(case when sum(payment_amt) >0 then round(sum(amt_13)/sum(payment_amt),2) else 0 end) as txn_m3_13_pct
,(case when sum(payment_amt) >0 then round(sum(amt_14)/sum(payment_amt),2) else 0 end) as txn_m3_14_pct
--,(case when sum(payment_amt) >0 then round(sum(amt_15)/sum(payment_amt),2) else 0 end) as txn_m3_15_pct
,(case when sum(payment_amt) >0 then round(sum(amt_16)/sum(payment_amt),2) else 0 end) as txn_m3_16_pct
,(case when sum(payment_amt) >0 then round(sum(amt_17)/sum(payment_amt),2) else 0 end) as txn_m3_17_pct

from
(select 
cut_off
,buyer_id
,item_category_name
,payment_amt
,payment_date
,(case when item_category_name like '01%' then item_sub_category_name end) as sub_1
,(case when item_category_name like '02%' then item_sub_category_name end) as sub_2
,(case when item_category_name like '03%' then item_sub_category_name end) as sub_3
,(case when item_category_name like '04%' then item_sub_category_name end) as sub_4
,(case when item_category_name like '05%' then item_sub_category_name end) as sub_5
,(case when item_category_name like '06%' then item_sub_category_name end) as sub_6
,(case when item_category_name like '07%' then item_sub_category_name end) as sub_7
,(case when item_category_name like '08%' then item_sub_category_name end) as sub_8
,(case when item_category_name like '09%' then item_sub_category_name end) as sub_9
,(case when item_category_name like '10%' then item_sub_category_name end) as sub_10
,(case when item_category_name like '11%' then item_sub_category_name end) as sub_11
--,(case when item_category_name like '12%' then item_sub_category_name end) as sub_12
--,(case when item_category_name like '13%' then item_sub_category_name end) as sub_13
,(case when item_category_name like '14%' then item_sub_category_name end) as sub_14
--,(case when item_category_name like '15%' then item_sub_category_name end) as sub_15
,(case when item_category_name like '16%' then item_sub_category_name end) as sub_16
,(case when item_category_name like '17%' then item_sub_category_name end) as sub_17
,(case when item_category_name like '01%' then order_code end) as ord_1
,(case when item_category_name like '02%' then order_code end) as ord_2
,(case when item_category_name like '03%' then order_code end) as ord_3
,(case when item_category_name like '04%' then order_code end) as ord_4
,(case when item_category_name like '05%' then order_code end) as ord_5
,(case when item_category_name like '06%' then order_code end) as ord_6
,(case when item_category_name like '07%' then order_code end) as ord_7
,(case when item_category_name like '08%' then order_code end) as ord_8
,(case when item_category_name like '09%' then order_code end) as ord_9
,(case when item_category_name like '10%' then order_code end) as ord_10
,(case when item_category_name like '11%' then order_code end) as ord_11
--,(case when item_category_name like '12%' then order_code end) as ord_12
--,(case when item_category_name like '13%' then order_code end) as ord_13
,(case when item_category_name like '14%' then order_code end) as ord_14
--,(case when item_category_name like '15%' then order_code end) as ord_15
,(case when item_category_name like '16%' then order_code end) as ord_16
,(case when item_category_name like '17%' then order_code end) as ord_17
,(case when item_category_name like '01%' then payment_date end) as dt_1
,(case when item_category_name like '02%' then payment_date end) as dt_2
,(case when item_category_name like '03%' then payment_date end) as dt_3
,(case when item_category_name like '04%' then payment_date end) as dt_4
,(case when item_category_name like '05%' then payment_date end) as dt_5
,(case when item_category_name like '06%' then payment_date end) as dt_6
,(case when item_category_name like '07%' then payment_date end) as dt_7
,(case when item_category_name like '08%' then payment_date end) as dt_8
,(case when item_category_name like '09%' then payment_date end) as dt_9
,(case when item_category_name like '10%' then payment_date end) as dt_10
,(case when item_category_name like '11%' then payment_date end) as dt_11
--,(case when item_category_name like '12%' then payment_date end) as dt_12
--,(case when item_category_name like '13%' then payment_date end) as dt_13
,(case when item_category_name like '14%' then payment_date end) as dt_14
--,(case when item_category_name like '15%' then payment_date end) as dt_15
,(case when item_category_name like '16%' then payment_date end) as dt_16
,(case when item_category_name like '17%' then payment_date end) as dt_17
,(case when item_category_name like '01%' then payment_amt end) as amt_1
,(case when item_category_name like '02%' then payment_amt end) as amt_2
,(case when item_category_name like '03%' then payment_amt end) as amt_3
,(case when item_category_name like '04%' then payment_amt end) as amt_4
,(case when item_category_name like '05%' then payment_amt end) as amt_5
,(case when item_category_name like '06%' then payment_amt end) as amt_6
,(case when item_category_name like '07%' then payment_amt end) as amt_7
,(case when item_category_name like '08%' then payment_amt end) as amt_8
,(case when item_category_name like '09%' then payment_amt end) as amt_9
,(case when item_category_name like '10%' then payment_amt end) as amt_10
,(case when item_category_name like '11%' then payment_amt end) as amt_11
--,(case when item_category_name like '12%' then payment_amt end) as amt_12
--,(case when item_category_name like '13%' then payment_amt end) as amt_13
,(case when item_category_name like '14%' then payment_amt end) as amt_14
--,(case when item_category_name like '15%' then payment_amt end) as amt_15
,(case when item_category_name like '16%' then payment_amt end) as amt_16
,(case when item_category_name like '17%' then payment_amt end) as amt_17
,(case when item_category_name like '01%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_1
,(case when item_category_name like '02%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_2
,(case when item_category_name like '03%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_3
,(case when item_category_name like '04%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_4
,(case when item_category_name like '05%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_5
,(case when item_category_name like '06%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_6
,(case when item_category_name like '07%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_7
,(case when item_category_name like '08%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_8
,(case when item_category_name like '09%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_9
,(case when item_category_name like '10%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_10
,(case when item_category_name like '11%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_11
--,(case when item_category_name like '12%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_12
--,(case when item_category_name like '13%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_13
,(case when item_category_name like '14%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_14
--,(case when item_category_name like '15%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_15
,(case when item_category_name like '16%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_16
,(case when item_category_name like '17%' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_17
,(case when item_category_name like '01%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_1
,(case when item_category_name like '02%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_2
,(case when item_category_name like '03%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_3
,(case when item_category_name like '04%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_4
,(case when item_category_name like '05%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_5
,(case when item_category_name like '06%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_6
,(case when item_category_name like '07%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_7
,(case when item_category_name like '08%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_8
,(case when item_category_name like '09%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_9
,(case when item_category_name like '10%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_10
,(case when item_category_name like '11%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_11
--,(case when item_category_name like '12%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_12
--,(case when item_category_name like '13%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_13
,(case when item_category_name like '14%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_14
--,(case when item_category_name like '15%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_15
,(case when item_category_name like '16%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_16
,(case when item_category_name like '17%' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_17
from model.m_dm_txn_90d txn
) as m
group by buyer_id ,cut_off;
--15s


DROP TABLE if exists model.m3_txn_type_rfm no delay;
CREATE TABLE model.m3_txn_type_rfm
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m3_txn_type_rfm',
 '{replica}')
ORDER BY cut_off AS
select 
cut_off
,buyer_id
,count(distinct txn_type) as txn_m3_type_d
,count(distinct ord_on) as txn_m3_on_f
,count(distinct ord_off) as txn_m3_off_f
,(case when count(distinct ord_on) > 0 then dateDiff('day',max(dt_on),cut_off) else 9999 end) as txn_m3_on_r
,(case when count(distinct ord_off) > 0 then dateDiff('day',max(dt_off),cut_off) else 9999 end) as txn_m3_off_r
,(case when count(distinct ord_on) >0 then sum(amt_on) else 0 end) as txn_m3_on_m
,(case when count(distinct ord_off) >0 then sum(amt_off) else 0 end) as txn_m3_off_m
,(case when count(distinct ord_on) = 0 then 9999
when count(distinct ord_on) =1 then -99
when count(distinct ord_on) > 1 then dateDiff('day',min(dt_on),max(dt_on))/(count(distinct ord_on) -1) end) as txn_m3_on_pc
,(case when count(distinct ord_off) = 0 then 9999
when count(distinct ord_off) =1 then -99
when count(distinct ord_off) > 1 then dateDiff('day',min(dt_off),max(dt_off))/(count(distinct ord_off) -1) end) as txn_m3_off_pc
,(sum(lst_wk_amt_on) - sum(pre_lst_wk_amt_on))txn_m3_on_m_ch
,(sum(lst_wk_amt_off) - sum(pre_lst_wk_amt_off))txn_m3_off_m_ch
,(case when sum(payment_amt) >0 then round(sum(amt_on)/sum(payment_amt),2) else 0 end) as txn_m3_on_pct
,(case when sum(payment_amt) >0 then round(sum(amt_off)/sum(payment_amt),2) else 0 end) as txn_m3_off_pct
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_on end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_on end) txn_m3_on_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_off end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_off end) txn_m3_off_f_ch

from
(select 
cut_off
,buyer_id
,payment_amt
,payment_date
,(case when source_type in ('O2O_B2C','O2O_DFS','NDD') then 'Online' 
when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') then 'Offline' else 'Others' end) as txn_type
,(case when source_type in ('O2O_B2C','O2O_DFS','NDD') then order_code end) as ord_on
,(case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') then order_code end) as ord_off
,(case when source_type in ('O2O_B2C','O2O_DFS','NDD') then payment_date end) as dt_on
,(case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') then payment_date end) as dt_off
,(case when source_type in ('O2O_B2C','O2O_DFS','NDD') then payment_amt end) as amt_on
,(case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') then payment_amt end) as amt_off
,(case when source_type in ('O2O_B2C','O2O_DFS','NDD') and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_on
,(case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_off
,(case when source_type in ('O2O_B2C','O2O_DFS','NDD') and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_on
,(case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_off
from model.m_dm_txn_90d ) as txn
group by buyer_id,cut_off;
--4s


DROP TABLE if exists model.m3_txn_prod_rfm no delay;
CREATE TABLE model.m3_txn_prod_rfm
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m3_txn_prod_rfm',
 '{replica}')
ORDER BY cut_off AS
select  
cut_off
,buyer_id
,count(distinct brand) as txn_m3_brd_d
,count(distinct ord_pb) as txn_m3_pb_f
,count(distinct ord_mmb) as txn_m3_mmb_f
,(case when count(distinct ord_pb) > 0 then dateDiff('day',max(dt_pb),cut_off) else 9999 end) as txn_m3_pb_r
,(case when count(distinct ord_mmb) > 0 then dateDiff('day',max(dt_mmb),cut_off) else 9999 end) as txn_m3_mmb_r
,(case when count(distinct ord_pb) >0 then sum(amt_pb) else 0 end) as txn_m3_pb_m
,(case when count(distinct ord_mmb) >0 then sum(amt_mmb) else 0 end) as txn_m3_mmb_m
,(case when count(distinct ord_pb) = 0 then 9999
when count(distinct ord_pb) =1 then -99
when count(distinct ord_pb) > 1 then dateDiff('day',min(dt_pb),max(dt_pb))/(count(distinct ord_pb) -1) end) as txn_m3_pb_pc
,(case when count(distinct ord_mmb) = 0 then 9999
when count(distinct ord_mmb) =1 then -99
when count(distinct ord_mmb) > 1 then dateDiff('day',min(dt_mmb),max(dt_mmb))/(count(distinct ord_mmb) -1) end) as txn_m3_mmb_pc
,(sum(lst_wk_amt_pb) - sum(pre_lst_wk_amt_pb))txn_m3_pb_m_ch
,(sum(lst_wk_amt_mmb) - sum(pre_lst_wk_amt_mmb))txn_m3_mmb_m_ch
,(case when sum(payment_amt) >0 then round((sum(amt_pb)/sum(payment_amt)),2) else 0 end) as txn_m3_pb_pct
,(case when sum(payment_amt) >0 then round((sum(amt_mmb)/sum(payment_amt)),2) else 0 end) as txn_m3_mmb_pct
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_pb end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_pb end) txn_m3_pb_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_mmb end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_mmb end) txn_m3_mmb_f_ch
,count(distinct country_of_origin) as txn_m3_cntry_d
,count(distinct ord_cn) as txn_m3_cn_f
,count(distinct ord_int) as txn_m3_int_f
,(case when count(distinct ord_cn) > 0 then dateDiff('day',max(dt_cn),cut_off) else 9999 end) as txn_m3_cn_r
,(case when count(distinct ord_int) > 0 then dateDiff('day',max(dt_int),cut_off) else 9999 end) as txn_m3_int_r
,(case when count(distinct ord_cn) >0 then sum(amt_cn) else 0 end) as txn_m3_cn_m
,(case when count(distinct ord_int) >0 then sum(amt_int) else 0 end) as txn_m3_int_m
,(case when count(distinct ord_cn) = 0 then 9999
when count(distinct ord_cn) =1 then -99
when count(distinct ord_cn) > 1 then dateDiff('day',min(dt_cn),max(dt_cn))/(count(distinct ord_cn) -1) end) as txn_m3_cn_pc
,(case when count(distinct ord_int) = 0 then 9999
when count(distinct ord_int) =1 then -99
when count(distinct ord_int) > 1 then dateDiff('day',min(dt_int),max(dt_int))/(count(distinct ord_int) -1) end) as txn_m3_int_pc
,(sum(lst_wk_amt_cn) - sum(pre_lst_wk_amt_cn))txn_m3_cn_m_ch
,(sum(lst_wk_amt_int) - sum(pre_lst_wk_amt_int))txn_m3_int_m_ch
,(case when sum(payment_amt) >0 then round((sum(amt_cn)/sum(payment_amt)),2) else 0 end) as txn_m3_cn_pct
,(case when sum(payment_amt) >0 then round((sum(amt_int)/sum(payment_amt)),2) else 0 end) as txn_m3_int_pct
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_cn end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_cn end) txn_m3_cn_f_ch
,count(distinct case when  toDate(payment_date) > addWeeks(cut_off,-2) then ord_int end)
- count(distinct case when toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then ord_int end) txn_m3_int_f_ch

from
(select 
cut_off
,buyer_id
,payment_amt
,payment_date
,country_of_origin
,(case when pl_flag = 'Y' then 'PB' else 'MMB' end) as brand
,(case when pl_flag = 'Y'  then order_code end) as ord_pb
,(case when pl_flag <> 'Y' then order_code end) as ord_mmb
,(case when country_of_origin = 'CN'  then order_code end) as ord_cn
,(case when country_of_origin <> 'CN' then order_code end) as ord_int
,(case when pl_flag = 'Y'  then payment_date end) as dt_pb
,(case when pl_flag <> 'Y' then payment_date end) as dt_mmb
,(case when country_of_origin = 'CN'  then payment_date end) as dt_cn
,(case when country_of_origin <> 'CN' then payment_date end) as dt_int
,(case when pl_flag = 'Y' then payment_amt end) as amt_pb
,(case when pl_flag <> 'Y' then payment_amt end) as amt_mmb
,(case when country_of_origin = 'CN' then payment_amt end) as amt_cn
,(case when country_of_origin <> 'CN' then payment_amt end) as amt_int
,(case when pl_flag = 'Y'  and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_pb
,(case when pl_flag <> 'Y' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_mmb
,(case when country_of_origin = 'CN'  and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_cn
,(case when country_of_origin <> 'CN' and  toDate(payment_date) > addWeeks(cut_off,-2) then payment_amt else 0 end) as lst_wk_amt_int
,(case when pl_flag = 'Y' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_pb
,(case when pl_flag <> 'Y' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_mmb
,(case when country_of_origin = 'CN' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_cn
,(case when country_of_origin <> 'CN' and toDate(payment_date) <= addWeeks(cut_off,-2) and toDate(payment_date) > addWeeks(cut_off,-4) then payment_amt else 0 end) as pre_lst_wk_amt_int
from model.m_dm_txn_90d txn 
inner join (select md_code, country_of_origin,pl_flag from datamart.on_sale_product_base group by md_code, country_of_origin,pl_flag)pd 
on txn.item_code = pd.md_code) as txn 
group by buyer_id,cut_off;
--8s

DROP TABLE if exists model.m3_txn_pmt_cp_rfm no delay;
CREATE TABLE model.m3_txn_pmt_cp_rfm
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m3_txn_pmt_cp_rfm',
 '{replica}')
ORDER BY cut_off AS
select 
txn.cut_off as cut_off
,txn.buyer_id as buyer_id
,count(distinct ord_new) as txn_m3_new_f
,count(distinct ord_supr) as txn_m3_supr_f
,count(distinct ord_pmt) as txn_m3_pmt_f
,count(distinct ord_cp) as txn_m3_cp_f
,(case when count(distinct ord_new) > 0 then dateDiff('day',max(dt_new),txn.cut_off) else 9999 end ) as  txn_m3_new_r
,(case when count(distinct ord_supr) > 0 then dateDiff('day',max(dt_new),txn.cut_off) else 9999 end ) as  txn_m3_supr_r
,(case when count(distinct ord_pmt) > 0 then dateDiff('day',max(m.dt_pmt),txn.cut_off) else 9999 end ) as  txn_m3_pmt_r
,(case when count(distinct ord_cp) > 0 then dateDiff('day',max(dt_cp),txn.cut_off) else 9999 end ) as  txn_m3_cp_r
,(case when count(distinct ord_new) >0 then sum(amt_new) else 0 end ) as  txn_m3_new_m
,(case when count(distinct ord_supr) >0 then sum(amt_supr) else 0 end ) as  txn_m3_supr_m
,(case when count(distinct ord_pmt) >0 then sum(amt_pmt) else 0 end ) as  txn_m3_pmt_m
,(case when count(distinct ord_cp) >0 then sum(amt_cp) else 0 end ) as  txn_m3_cp_m
,(case when count(distinct ord_new) = 0 then 9999
when count(distinct ord_new) =1 then -99
when count(distinct ord_new) > 1 then dateDiff('day',min(dt_new),max(dt_new))/(count(distinct ord_new) -1) end ) as  txn_m3_new_pc
,(case when count(distinct ord_supr) = 0 then 9999
when count(distinct ord_supr) =1 then -99
when count(distinct ord_supr) > 1 then dateDiff('day',min(dt_supr),max(dt_supr))/(count(distinct ord_supr) -1) end ) as  txn_m3_supr_pc
,(case when count(distinct ord_pmt) = 0 then 9999
when count(distinct ord_pmt) =1 then -99
when count(distinct ord_pmt) > 1 then dateDiff('day',min(m.dt_pmt),max(m.dt_pmt))/(count(distinct ord_pmt) -1) end ) as  txn_m3_pmt_pc
,(case when count(distinct ord_cp) = 0 then 9999
when count(distinct ord_cp) =1 then -99
when count(distinct ord_cp) > 1 then dateDiff('day',min(dt_cp),max(dt_cp))/(count(distinct ord_cp) -1) end ) as  txn_m3_cp_pc	
,(case when sum(txn.payment_amt) >0 then round((sum(amt_new)/sum(txn.payment_amt)),2) else 0 end ) as  txn_m3_new_pct
,(case when sum(txn.payment_amt) >0 then round((sum(amt_supr)/sum(txn.payment_amt)),2) else 0 end ) as  txn_m3_supr_pct --super saver payment amount
,(case when sum(txn.payment_amt) >0 then round((sum(amt_pmt)/sum(txn.payment_amt)),2) else 0 end ) as  txn_m3_pmt_pct -- promotion amount
,(case when sum(txn.payment_amt) >0 then round((sum(amt_cp)/sum(txn.payment_amt)),2) else 0 end ) as  txn_m3_cp_pct -- coupon amount

from
(select 
txn.cut_off
,txn.buyer_id
,txn.payment_amt
,(case when p.order_code is not null then txn.order_code end ) as  ord_pmt
,(case when c.order_code is not null then txn.order_code end ) as  ord_cp
,(case when toDate(txn.payment_date) < addWeeks(os.on_sale_date,1) then txn.order_code end ) as  ord_new
,(case when is_super_saver = 1 then txn.order_code end ) as  ord_supr
,(case when p.order_code is not null then txn.payment_date end ) as  dt_pmt
,(case when c.order_code is not null then txn.payment_date end ) as  dt_cp
,(case when toDate(txn.payment_date) < addWeeks(os.on_sale_date,1) then txn.payment_date end ) as  dt_new
,(case when is_super_saver = 1 then payment_date end ) as  dt_supr
,(case when p.order_code is not null then promotion_amt end ) as  amt_pmt
,(case when c.order_code is not null then coupon_amt end ) as  amt_cp
,(case when toDate(txn.payment_date) < addWeeks(os.on_sale_date,1) then txn.payment_amt end ) as  amt_new
,(case when is_super_saver =1 then txn.payment_amt end ) as  amt_supr
,(case when p.order_code is not null and toDate(payment_date) > addWeeks(txn.cut_off,-2) then promotion_amt else 0 end ) as  lst_wk_amt_pmt
,(case when c.order_code is not null and toDate(payment_date) > addWeeks(txn.cut_off,-2) then coupon_amt else 0 end ) as  lst_wk_amt_cp
,(case when toDate(txn.payment_date) < addWeeks(os.on_sale_date,1) and toDate(payment_date) > addWeeks(txn.cut_off,-2) then txn.payment_amt else 0 end ) as  lst_wk_amt_new
,(case when is_super_saver = 1 then txn.payment_amt else 0 end ) as  lst_wk_amt_supr
,(case when p.order_code is not null and toDate(payment_date) <= addWeeks(txn.cut_off,-2) and toDate(payment_date) > addWeeks(txn.cut_off,-4) then promotion_amt else 0 end ) as  pre_lst_wk_amt_pmt
,(case when c.order_code is not null and toDate(payment_date) <= addWeeks(txn.cut_off,-2) and toDate(payment_date) > addWeeks(txn.cut_off,-4) then coupon_amt else 0 end ) as  pre_lst_wk_amt_cp
,(case when toDate(txn.payment_date) < addWeeks(os.on_sale_date,1) and toDate(payment_date) <= addWeeks(txn.cut_off,-2) and toDate(payment_date) > addWeeks(txn.cut_off,-4) then txn.payment_amt else 0 end ) as  pre_lst_wk_amt_new
,(case when is_super_saver = 1 and toDate(payment_date) <= addWeeks(txn.cut_off,-2) and toDate(payment_date) > addWeeks(txn.cut_off,-4)  then txn.payment_amt else 0 end ) as  pre_lst_wk_amt_supr
from model.m_dm_txn_90d txn
left join model.m3_prod_os_lk os on txn.item_code = os.item_code
ASOF left join (select a.* from raw_data.mlp_oms_so_promotion_item a
inner join raw_data.dim_promotion_df  pro on a.promotion_id = pro.pk_promotion_id where pro.prom_type in (1,2,3,4,9)) p --单一促销，满额促销，满量促销，赠送，包邮促销
on txn.order_code = p.order_code and product_id = toString(p.mp_id) 
and p.create_time <= txn.cut_off and is_super_saver =0 -- other promotion except super saver
ASOF left join raw_data.mlp_oms_so_coupon_item c on txn.order_code = c.order_code and txn.product_id = toString(c.mp_id)
and c.create_time <= txn.cut_off
) m
group by txn.cut_off, txn.buyer_id;