DROP TABLE if exists model.m5_mpgm_cust_rf no delay;
CREATE TABLE model.m5_mpgm_cust_rf
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m5_mpgm_cust_rf',
 '{replica}')
ORDER BY cut_off AS
select 
cut_off
,buyer_id
,count(distinct new_pn) as bi_m5_pn_d
,min(dateDiff(day,dt_srch,cut_off)) as bi_m5_srch_r
,min(dateDiff(day,dt_cart,cut_off)) as bi_m5_cart_r
,min(dateDiff(day,dt_act,cut_off)) as bi_m5_act_r
,count(distinct dt_srch) as bi_m5_srch_f -- 搜索统计
,count(distinct dt_cart) as bi_m5_cart_f -- 加入购物车
,count(distinct dt_act) as bi_m5_act_f --扫码活动
from 
(select
cut_off 
,buyer_id
,case when pn like '个人中心%' then '个人中心'
when pn like '分类页%' then '分类页'
when pn like '营销页%' then '营销页'
when pn like '搜索页%' then '搜索页'
when pn like '商品详情页%' then '商品详情页'
when pn like '购物车%' then '购物车'
when pn like '提交订单页%' then '提交订单页'
else '其他' end as new_pn
,case when ev =1 then toDate(create_time) end as dt_srch --搜索
,case when ev =4 then toDate(create_time) end as dt_cart  --加入购物车
,case when ev in (22,23) then toDate(create_time) end as dt_act --扫描太阳码
from model.m_bi_user_90d a
group by cut_off, buyer_id, pn, ev, toDate(create_time)
)m
group by cut_off, buyer_id; 

DROP TABLE if exists model.m5_mpgm_subsp_flg no delay;
CREATE TABLE model.m5_mpgm_subsp_flg
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m5_mpgm_subsp_flg',
 '{replica}')
ORDER BY cut_off AS
select
cut_off
,buyer_id
,(case when ev = 20 then 0 when ev =19 then 1
else null end) as bi_m5_subsp_flg
from
(select cut_off 
,buyer_id
,ev
,row_number()over(partition by buyer_id order by create_time desc)cn
from model.m_bi_user_90d a
where ev in (20,19) --20--拒绝订阅， --19--接受订阅
)m
where m.cn =1;

--comment RFM
DROP TABLE if exists model.m5_cmt_cust_rf no delay;
CREATE TABLE model.m5_cmt_cust_rf
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m5_cmt_cust_rf',
 '{replica}')
ORDER BY cut_off AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select 
assumeNotNull(cod) as cut_off
,user_id as buyer_id
,count(distinct order_code) as cmt_m5_cust_f
,dateDiff(dd,max(create_time),cod) cmt_m5_cust_r
,sum(rate)/count(id) cmt_m5_cust_rate_avg
from raw_data.mlp_front_sns_merchant_product_comment
where create_time >= date_add(day,-90,cod)
and toDate(create_time) <= cod
group by user_id;