DROP TABLE if exists  model.m4_txn_time_day no delay; 
CREATE TABLE model.m4_txn_time_day
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_txn_time_day',
 '{replica}')
ORDER BY cut_off AS
select
txn.cut_off as cut_off
,buyer_id
,(case when sum(payment_amt) >0 then round(sum(case when toHour(payment_date) <11 then payment_amt end)/sum(payment_amt),2) else 0 end) as  mrn_amt_pct
,(case when sum(payment_amt) >0 then round(sum(case when toHour(payment_date) <11 then payment_amt end)/sum(payment_amt)/b.mrn_amt_avg_pct,2) else 0 end) as mrn_amt_pref
,(case when sum(payment_amt) >0 then round(sum(case when toHour(payment_date) >=11 and toHour(payment_date) <17 then payment_amt end)/sum(payment_amt),2)else 0 end) as arvo_amt_pct
,(case when sum(payment_amt) >0 then round(sum(case when toHour(payment_date) >=11 and toHour(payment_date) <17 then payment_amt end)/sum(payment_amt)/arvo_amt_avg_pct,2)else 0 end) as arvo_amt_pref
,(case when sum(payment_amt) >0 then round(sum(case when toHour(payment_date) >=17 then payment_amt end )/sum(payment_amt),2)else 0 end) as nite_amt_pct
,(case when sum(payment_amt) >0 then round(sum(case when toHour(payment_date) >=17 then payment_amt end )/sum(payment_amt)/nite_amt_avg_pct,2)else 0 end) as nite_amt_pref
,(case when sum(payment_amt) >0 then round(sum(case when toDayOfWeek(payment_date) in (6,7) then payment_amt end )/sum(payment_amt),2)else 0 end) as wkd_amt_pct
,(case when sum(payment_amt) >0 then round(sum(case when toDayOfWeek(payment_date) in (6,7) then payment_amt end)/sum(payment_amt)/wkd_amt_avg_pct ,2)else 0 end) as wkd_amt_pref
,(case when sum(payment_amt) >0 then round(sum(case when toDayOfWeek(payment_date) not in (6,7) then payment_amt end )/sum(payment_amt),2)else 0 end) as wrk_amt_pct
,(case when sum(payment_amt) >0 then round(sum(case when toDayOfWeek(payment_date) not in (6,7) then payment_amt end)/sum(payment_amt)/wrk_amt_avg_pct ,2)else 0 end) as wrk_amt_pref
from model.m_dm_txn_90d txn
inner join 
(select 
cut_off 
,sum(mrn_amt_pct)/count(distinct buyer_id) mrn_amt_avg_pct
,sum(arvo_amt_pct)/count(distinct buyer_id) arvo_amt_avg_pct
,sum(nite_amt_pct)/count(distinct buyer_id) nite_amt_avg_pct
,sum(wkd_amt_pct)/count(distinct buyer_id) wkd_amt_avg_pct
,sum(wrk_amt_pct)/count(distinct buyer_id) wrk_amt_avg_pct
from
(select
cut_off
,buyer_id
,(case when sum(payment_amt) >0 then sum(case when toHour(payment_date) <11 then payment_amt end)/sum(payment_amt)else 0 end) as mrn_amt_pct
,(case when sum(payment_amt) >0 then sum(case when toHour(payment_date) >=11 and toHour(payment_date) <17 then payment_amt end)/sum(payment_amt)else 0 end) as arvo_amt_pct
,(case when sum(payment_amt) >0 then sum(case when toHour(payment_date) >=17 then payment_amt end)/sum(payment_amt)else 0 end) as nite_amt_pct
,(case when sum(payment_amt) >0 then sum(case when toDayOfWeek(payment_date) in (6,7) then payment_amt end)/sum(payment_amt)else 0 end) as wkd_amt_pct
,(case when sum(payment_amt) >0 then sum(case when toDayOfWeek(payment_date) not in (6,7) then payment_amt end)/sum(payment_amt)else 0 end) as wrk_amt_pct
from model.m_dm_txn_90d 
group by cut_off,buyer_id)m
group by cut_off)b on txn.cut_off = b.cut_off
group by txn.cut_off, buyer_id,mrn_amt_avg_pct,arvo_amt_avg_pct,nite_amt_avg_pct,wkd_amt_avg_pct,wrk_amt_avg_pct;

DROP TABLE if exists model.m4_txn_time_final no delay;
CREATE TABLE model.m4_txn_time_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_txn_time_final',
 '{replica}')
ORDER BY cut_off AS
select
cut_off 
,buyer_id
,mrn_amt_pref as txn_m4_mrn_pref
,(case when mrn_amt_pref >=isNull(arvo_amt_pref) and mrn_amt_pref >=isNull(nite_amt_pref) then 1 else 0 end) as txn_m4_mrn_flg
,arvo_amt_pref as txn_m4_arvo_pref
,(case when arvo_amt_pref>= isNull(mrn_amt_pref) and arvo_amt_pref>= isNull(nite_amt_pref) then 1 else 0 end) as txn_m4_arvo_flg
,nite_amt_pref as txn_m4_nite_pref
,(case when nite_amt_pref >= isNull(mrn_amt_pref) and nite_amt_pref >= isNull(arvo_amt_pref) then 1 else 0 end) as txn_m4_nite_flg
,wkd_amt_pref as txn_m4_wkd_pref
,wrk_amt_pref as txn_m4_wrk_pref
,(case when wkd_amt_pref >= isNull(wrk_amt_pref) then 1 else 0 end) as txn_m4_wkd_flg 
from model.m4_txn_time_day;


