--order code is not null
DROP TABLE if exists model.m5_compl_rf no delay;
CREATE TABLE model.m5_compl_rf
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m5_compl_rf',
 '{replica}')
ORDER BY tuple() AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select 
cod as cut_off
,buyer_id
,sum(cnt) as compl_m5_cust_f
,max(dt) as compl_m5_cust_r
from 
(select 
txn.buyer_id as buyer_id
,count(distinct caseid) as cnt
,dateDiff(day,max(Record_date),cod) as dt
from datamart.cs_case_header as a  --- pending to update table name
inner join model.m_dm_txn_90d txn on a.order_code = txn.order_code
where Record_date >= dateadd(dd,-90,cod)
and toDate(Record_date) <= cod
group by txn.buyer_id 
union distinct
select 
b.id as buyer_id
,count(distinct caseid) as cnt
,datediff(dd,max(Record_date),cod)dt
from datamart.cs_case_header a
-- will correct raw_data.mlp_ouser_u_user b.username to b.mobile after data is ready
inner join raw_data.mlp_ouser_u_user b on a.contact_number = b.username  
where Record_date >= dateadd(dd,-90,cod)
and toDate(Record_date) <= cod
and order_code = ''  -- for some comments don't contain order_code
group by b.id
)m
group by buyer_id;


DROP TABLE if exists model.m5_mpgm_ch_cmt_final no delay;
CREATE TABLE model.m5_mpgm_ch_cmt_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m5_mpgm_ch_cmt_final',
 '{replica}')
ORDER BY tuple() AS
select 
u.cut_off as cut_off
,u.buyer_id as buyer_id
,a.bi_m5_pn_d as bi_m5_pn_d
,a.bi_m5_act_f as bi_m5_act_f
,a.bi_m5_act_r as bi_m5_act_r
,a.bi_m5_cart_f  as bi_m5_cart_f
,a.bi_m5_cart_r  as bi_m5_cart_r
,a.bi_m5_srch_f as bi_m5_srch_f
,a.bi_m5_srch_r as bi_m5_srch_r
,b.bi_m5_subsp_flg as bi_m5_subsp_flg
,c.ch_m5_subsp_f as ch_m5_subsp_f
,c.ch_m5_subsp_r as ch_m5_subsp_r
--,d.ch_m5_subsp_txn --remove thing6
,e.ch_m5_sms_f as ch_m5_sms_f
,e.ch_m5_sms_r as ch_m5_sms_r
,f.ch_m5_sms_txn as ch_m5_sms_txn
,g.cmt_m5_cust_f as cmt_m5_cust_f
,g.cmt_m5_cust_r as cmt_m5_cust_r
,g.cmt_m5_cust_rate_avg as cmt_m5_cust_rate_avg
,h.compl_m5_cust_f as compl_m5_cust_f
,h.compl_m5_cust_r as compl_m5_cust_r
from model.m_ouser_all u
left join model.m5_mpgm_cust_rf a on u.cut_off = a.cut_off and u.buyer_id = a.buyer_id
left join model.m5_mpgm_subsp_flg b on u.cut_off = b.cut_off and u.buyer_id = b.buyer_id
left join model.m5_ch_subsp_rf c on u.cut_off = c.cut_off and u.buyer_id = c.buyer_id
--left join model.m5_ch_subsp_txn d on u.cut_off = d.cut_off and u.buyer_id = d.buyer_id --remove thing6
left join model.m5_ch_sms_rf e on u.cut_off = e.cut_off and u.buyer_id = e.buyer_id
left join model.m5_ch_sms_txn f on u.cut_off = f.cut_off and u.buyer_id = f.buyer_id
left join model.m5_cmt_cust_rf g on u.cut_off = g.cut_off and u.buyer_id = g.buyer_id
left join model.m5_compl_rf h on u.cut_off = h.cut_off and u.buyer_id = h.buyer_id;

