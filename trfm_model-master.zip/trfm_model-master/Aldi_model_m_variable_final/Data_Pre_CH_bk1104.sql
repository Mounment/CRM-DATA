--SQL server
--insert running status:插入运行状态
--INSERT INTO dbo.job_running_monitor(Job_name,cut_off,status,start_time,end_time) VALUES ('m_variable_final_job', convert(date,getdate()-1),'RUNNING',getdate(), '');
 
--clickhouse
INSERT INTO model.job_running_monitor (Job_name,cut_off,status,start_time,end_time) VALUES ('m_variable_final_job', today()-1,'RUNNING',now(), '');
--remove records
--alter table model.job_running_monitor delete where cut_off='2021-08-29'

--export data from raw tables
--dbo.m_bi_user_all
--dbo.m_bi_user_90d
--dbo.m_dm_txn_90d
--dbo.m_dm_txn_all
--dbo.m_acct_flw_90d --points
--m_alq_user_all--wechat used

--SQL server
--刷新cut_off表，确保cut_off统一
--DROP TABLE if exists dbo.m_cut_off_lk;
--CREATE TABLE dbo.m_cut_off_lk (cut_off date);
--insert into dbo.m_cut_off_lk values (convert(date,getdate()-1));

--clickhouse
DROP TABLE if exists model.m_cut_off_lk NO DELAY;
CREATE TABLE model.m_cut_off_lk
(

    `cut_off` Date
)
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_cut_off_lk',
 '{replica}')
ORDER BY tuple() as select today()-1;

----SQL server
--declare @cod date
----set @cod = CONVERT(date,GETDATE()-1)
--set @cod = (select cut_off from dbo.m_cut_off_lk)
--BEGIN 
--DROP TABLE if exists dbo.m_bi_user_all
--select 
--@cod as cut_off
--,user_id as buyer_id
--,ev
--,left(pvi,16) as share_code
--,lan
--,create_time
--into dbo.m_bi_user_all
--from ec.bi.bi_user_behavior_source bubs
--where create_time >= '2019-06-07'
--and convert(date,create_time) <= @cod
--and user_id <> ''
--end;
----exe dur: 5mins

--clickhouse
DROP TABLE if exists model.m_bi_user_all NO DELAY;
CREATE TABLE model.m_bi_user_all 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_bi_user_all',
 '{replica}')
ORDER BY cut_off AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
SELECT 
assumeNotNull(cod) AS cut_off
,user_id AS buyer_id
,ev
,substringUTF8(pvi,1,16) AS share_code
,lan
,create_time

FROM raw_data.mlp_bi_bi_user_behavior_source bubs
WHERE create_time >= '2019-06-07'
AND toDate(create_time) <= cod
AND user_id IS NOT NULL;
--exe dur: 30s


----SQL server
--set @cod = (select cut_off from dbo.m_cut_off_lk)
--BEGIN 
--DROP TABLE if exists dbo.m_bi_user_90d
--select 
--@cod as cut_off
--,user_id as buyer_id
--,ev
--,pn
--,create_time
--into dbo.m_bi_user_90d
--from ec.bi.bi_user_behavior_source bubs
--where create_time >= dateadd(dd,-90,@cod)
--and convert(date,create_time) <= @cod
--and user_id <> ''
--end;
----exc dur:5.5mins

--clickhouse
DROP TABLE if exists model.m_bi_user_90d NO DELAY;
CREATE TABLE model.m_bi_user_90d 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_bi_user_90d',
 '{replica}')
ORDER BY cut_off AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
SELECT 
assumeNotNull(cod) AS cut_off
,user_id AS buyer_id
,ev
,pn
,create_time

FROM raw_data.mlp_bi_bi_user_behavior_source bubs
WHERE create_time >= date_add(DAY,-90,cod)
AND toDate(create_time) <= cod
AND user_id IS NOT NULL;
--exc dur: 10s


----SQL server
---- remove shop_name
--set @cod = (select cut_off from dbo.m_cut_off_lk)
--BEGIN
--DROP TABLE if exists dbo.m_dm_txn_90d
--select 
--@cod as cut_off
--,order_code
--,source_type
--,merchant_code
--,longitude
--,latitude
--,buyer_id
--,payment_date
--,product_id
--,item_code
--,item_category_name
--,item_sub_category_name
--,buy_qty
--,payment_amt
--,coupon_amt
--,promotion_amt
--,is_super_saver
--into dbo.m_dm_txn_90d
--from edc.dm.dm_EC_sale_product desp
--where payment_date >= dateadd(dd,-90,@cod)
--and convert(date,payment_date) <= @cod
--and buyer_id <> ''
--and order_code in (select order_code 
--from edc.dm.dm_EC_sale_order where payment_date <>'' and map_desc <>N'已取消')
--end;
----exc duration: 21s

--clickhouse
--pk_order_code is incorrect will change after Aldi fixed
DROP TABLE if exists model.m_dm_txn_90d NO DELAY;
CREATE TABLE model.m_dm_txn_90d
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_dm_txn_90d',
 '{replica}')
ORDER BY cut_off AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
SELECT 
assumeNotNull(cod) as cut_off
,order_code
,source_type
,merchant_code
,longitude
,latitude
,assumeNotNull(buyer_id) as buyer_id
,assumeNotNull(payment_date) as payment_date
,product_id
,item_code
,item_category_name
,item_sub_category_name
,buy_qty
,payment_amt
,coupon_amt
,promotion_amt
,is_super_saver

FROM raw_data.ec_sale_order_product desp
WHERE payment_date >= date_add(DAY,-90,cod)
AND toDate(payment_date) <= cod
AND buyer_id IS NOT NULL
AND order_code IN (SELECT pk_order_code 
FROM raw_data.ec_sale_order WHERE payment_date IS NOT NULL AND map_desc NOT IN ('已取消'));
--exc duration: 10s



----SQL SERVER
----DROP TABLE if exists dbo.m_dm_txn_all;
--set @cod = (select cut_off from dbo.m_cut_off_lk)
--BEGIN
--DROP TABLE if exists dbo.m_dm_txn_all
--select 
--@cod as cut_off
--,buyer_id
--,order_code
--,merchant_code
--,item_code
--,item_category_name
--,payment_amt
--,payment_date
--into dbo.m_dm_txn_all
--from edc.dm.dm_EC_sale_product desp
--where convert(date,payment_date) <= @cod 
--and buyer_id <> ''
--and order_code in (select order_code 
--from edc.dm.dm_EC_sale_order where payment_date <>'' and map_desc <>N'已取消')
--end;
----exc duration 28s

--clickhouse
--pk_order_code is incorrect will change after Aldi fixed
DROP TABLE if exists model.m_dm_txn_all NO DELAY;
CREATE TABLE model.m_dm_txn_all
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_dm_txn_all',
 '{replica}')
ORDER BY cut_off AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
SELECT 
assumeNotNull(cod) AS cut_off
,buyer_id
,order_code
,merchant_code
,item_code
,item_category_name
,payment_amt
,payment_date

FROM raw_data.ec_sale_order_product desp
WHERE toDate(payment_date) <= cod 
AND buyer_id IS NOT NULL
AND order_code IN (SELECT pk_order_code 
FROM raw_data.ec_sale_order WHERE payment_date IS NOT NULL AND map_desc <> '已取消');
--20s



----SQL server
--set @cod = (select cut_off from dbo.m_cut_off_lk)
--BEGIN
--DROP TABLE if exists dbo.m_acct_flw_90d
--select 
--@cod as cut_off
----,DATEADD(week, DATEDIFF(week, 0, datediff(dd,1,@cod)), 0)sow
--,user_id as buyer_id
----,account_id
--,trans_type
--,amount_trans
--,amount_trans_balance
--,create_time
--into dbo.m_acct_flw_90d
--from ec.ouser.account_flow_2
--where create_time >= dateadd(dd, -90,@cod)
--and convert(date,create_time) <= @cod
--and amount_action is not null
--end;
----exc duration: 12s

--clickhouse
DROP TABLE if exists model.m_acct_flw_90d NO DELAY;
CREATE TABLE model.m_acct_flw_90d
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_acct_flw_90d',
 '{replica}')
ORDER BY cut_off AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
SELECT 
assumeNotNull(cod) AS cut_off
--,DATEADD(week, DATEDIFF(week, 0, datediff(dd,1,@cod)), 0)sow
,user_id AS buyer_id
--,account_id
,trans_type
,amount_trans
,amount_trans_balance
,create_time

FROM raw_data.mlp_ouser_account_flow
WHERE create_time >= date_add(DAY,-90,cod)
AND toDate(create_time) <= cod
AND amount_action IS NOT NULL;
--2s


----SQL server
--set @cod = (select cut_off from dbo.m_cut_off_lk)
--BEGIN
--DROP TABLE if exists dbo.m_alq_user_all
--select 
--@cod as cut_off
--,user_id as buyer_id
--,N'微信' as acq_channel
--,N'微信公众号注册' as acq_activity
--into dbo.m_alq_user_all
--from ec.ouser.alq_user_source 
--where convert(date,create_time) <= @cod
--and action_type =1
--end;
----exc duration: 188ms

--clickhouse
DROP TABLE if exists model.m_alq_user_all NO DELAY;
CREATE TABLE model.m_alq_user_all
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_alq_user_all',
 '{replica}')
ORDER BY cut_off AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
SELECT 
assumeNotNull(cod) AS cut_off
,user_id AS buyer_id
,'微信' AS acq_channel
,'微信公众号注册' AS acq_activity

FROM raw_data.mlp_ouser_aldi_user_source
WHERE toDate(create_time) <= cod
and action_type =1;
