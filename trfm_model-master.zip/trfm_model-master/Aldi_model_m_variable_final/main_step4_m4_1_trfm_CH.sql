--model.m_dm_txn_all
--model.m_ouser_all a

--get RFM
DROP TABLE if exists model.m4_trmf_seg_rfm no delay;
CREATE TABLE model.m4_trmf_seg_rfm
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_trmf_seg_rfm',
 '{replica}')
ORDER BY cut_off AS
select buyer_id,cut_off,
min(dateDiff(day,toDate( payment_date),cut_off)) as txn_m4_cust_r,
count(distinct case when 
toDate( payment_date) <=cut_off and 
toDate( payment_date) >= date_add(day, -90, cut_off) 
then order_code else null end ) as txn_m4_cust_f_90d,
count(distinct case when 
toDate( payment_date) >= date_add(day, -14, cut_off) 
then order_code else null end) as txn_m4_cust_f_14d,
sum(case when 
toDate( payment_date) <=cut_off and 
toDate( payment_date)>= date_add(day, -90, cut_off) 
then payment_amt else 0 end) as txn_m4_cust_m_90d,
sum(case when  
toDate( payment_date)>= date_add(day, -14, cut_off) 
then payment_amt else 0 end) as txn_m4_cust_m_14d
from model.m_dm_txn_all 
group by buyer_id,cut_off;


--get TRFM
DROP TABLE if exists model.m4_trmf_seg_trfm no delay;
CREATE TABLE model.m4_trmf_seg_trfm
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_trmf_seg_trfm',
 '{replica}')
ORDER BY cut_off AS
select 
a.buyer_id as buyer_id
,a.cut_off as cut_off,
a.cust_m1_tenure as cust_m1_tenure,
(case when b.txn_m4_cust_r is null then 9999 else b.txn_m4_cust_r end ) as txn_m4_cust_r,
(case when b.txn_m4_cust_f_90d is null then 0 else b.txn_m4_cust_f_90d end ) as txn_m4_cust_f_90d,
(case when b.txn_m4_cust_m_90d is null then 0 else b.txn_m4_cust_m_90d end ) as txn_m4_cust_m_90d,
(case when b.txn_m4_cust_f_14d is null then 0 else b.txn_m4_cust_f_14d end ) as txn_m4_cust_f_14d,
(case when b.txn_m4_cust_m_14d is null then 0 else b.txn_m4_cust_m_14d end ) as txn_m4_cust_m_14d
from model.m_ouser_all a
left join model.m4_trmf_seg_rfm b
on a.buyer_id =b.buyer_id
and a.cut_off=b.cut_off;

--TRFM check
/*select txn_m4_cust_macro_seg,txn_m4_cust_micro_seg,count(*),
min(cust_m1_tenure)min_t,max(cust_m1_tenure)max_t,
min(txn_m4_cust_r)min_r,max(txn_m4_cust_r)max_r,
min(txn_m4_cust_f_90d)min_f,max(txn_m4_cust_f_90d)max_f,
min(txn_m4_cust_m_90d)min_m,max(txn_m4_cust_m_90d)max_m
from model.m4_trmf_seg_final
group by txn_m4_cust_macro_seg,txn_m4_cust_micro_seg
order by txn_m4_cust_macro_seg,txn_m4_cust_micro_seg;
*/

--get TRFM segments
DROP TABLE if exists  model.m4_trmf_seg_final no delay;
CREATE TABLE model.m4_trmf_seg_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_trmf_seg_final',
 '{replica}')
ORDER BY cut_off AS
select cut_off
,buyer_id
,cust_m1_tenure
,txn_m4_cust_r
,txn_m4_cust_f_90d
,txn_m4_cust_m_90d
,txn_m4_cust_f_14d
,txn_m4_cust_m_14d
,case when cust_m1_tenure<=30 then 'New'
when txn_m4_cust_f_90d>=1 then 'Active' else 'Inactive' end as txn_m4_cust_macro_seg
,case when cust_m1_tenure<=30 and txn_m4_cust_f_90d>=1 then 'Activated'
when cust_m1_tenure<=30 then 'Passive'
when cust_m1_tenure>30 and txn_m4_cust_f_90d>=1 and txn_m4_cust_r>=30 then 'At Risk'
when cust_m1_tenure>30 and txn_m4_cust_f_90d>=8 and txn_m4_cust_m_90d>=800 and txn_m4_cust_r<14 then 'Core'
when cust_m1_tenure>30 and txn_m4_cust_f_90d>=1 then 'Engaged'
when txn_m4_cust_f_90d=0 and cust_m1_tenure<=90 then 'Inactive New'
when txn_m4_cust_f_90d=0 and cust_m1_tenure>90 and txn_m4_cust_r<=365 then 'Disengaged'
when txn_m4_cust_f_90d=0 and cust_m1_tenure>90 and txn_m4_cust_r>365 then 'Frozen' else null end as txn_m4_cust_micro_seg
from model.m4_trmf_seg_trfm;



