insert into model.m_variable_final_history select * from model.m_variable_final;

drop table if exists model.m_variable_final no delay;
CREATE TABLE model.m_variable_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_variable_final',
 '{replica}')
ORDER BY cut_off AS
select
t.cut_off as cut_off
,t.buyer_id as buyer_id
,cust_m1_city
,cust_m1_region
,t.cust_m1_tenure as cust_m1_tenure
,cust_m1_dob
,cust_m1_age
,cust_m1_gender
,cust_m1_lan
,cust_m1_dim_nxt_mth_m_flg
,cust_m1_dim_nxt_mth_clk
,cust_m1_dim_cur_mth_m_flg
,cust_m1_dim_cur_mth_clk
,cust_m1_dim_mths
,cust_m1_points_m
,cust_m1_points_in_r
,cust_m1_points_in_pc
,cust_m1_points_in_f
,cust_m1_points_in_m
,cust_m1_points_in_ch
,cust_m1_points_out_r
,cust_m1_points_out_pc
,cust_m1_points_out_f
,cust_m1_points_out_m
,cust_m1_points_out_ch
,cust_m1_acq_channel
,cust_m1_acq_activity
,txn_m2_cust_pc
,txn_m2_cust_r
,txn_m2_cust_f
,txn_m2_cust_f_ch
,txn_m2_cust_m
,txn_m2_cust_m_ch
,txn_m2_cust_cmp
,txn_m2_cust_atv
,txn_m2_type_main
,txn_m2_type_d
,txn_m2_scr_main
,txn_m2_scr_d
,txn_m2_str_fst
,txn_m2_str_main
,txn_m2_str_d
,txn_m3_vtc_d
,txn_m3_01_m_ch
,txn_m3_01_d
,txn_m3_01_f
,txn_m3_01_f_ch
,txn_m3_01_m
,txn_m3_01_pc
,txn_m3_01_pct
,txn_m3_01_r
,txn_m3_01_pref
,txn_m3_02_m_ch
,txn_m3_02_d
,txn_m3_02_f
,txn_m3_02_f_ch
,txn_m3_02_m
,txn_m3_02_pc
,txn_m3_02_pct
,txn_m3_02_r
,txn_m3_02_pref
,txn_m3_03_m_ch
,txn_m3_03_d
,txn_m3_03_f
,txn_m3_03_f_ch
,txn_m3_03_m
,txn_m3_03_pc
,txn_m3_03_pct
,txn_m3_03_r
,txn_m3_03_pref
,txn_m3_04_m_ch
,txn_m3_04_d
,txn_m3_04_f
,txn_m3_04_f_ch
,txn_m3_04_m
,txn_m3_04_pc
,txn_m3_04_pct
,txn_m3_04_r
,txn_m3_04_pref
,txn_m3_05_m_ch
,txn_m3_05_d
,txn_m3_05_f
,txn_m3_05_f_ch
,txn_m3_05_m
,txn_m3_05_pc
,txn_m3_05_pct
,txn_m3_05_r
,txn_m3_05_pref
,txn_m3_06_m_ch
,txn_m3_06_d
,txn_m3_06_f
,txn_m3_06_f_ch
,txn_m3_06_m
,txn_m3_06_pc
,txn_m3_06_pct
,txn_m3_06_r
,txn_m3_06_pref
,txn_m3_07_m_ch
,txn_m3_07_d
,txn_m3_07_f
,txn_m3_07_f_ch
,txn_m3_07_m
,txn_m3_07_pc
,txn_m3_07_pct
,txn_m3_07_r
,txn_m3_07_pref
,txn_m3_08_m_ch
,txn_m3_08_d
,txn_m3_08_f
,txn_m3_08_f_ch
,txn_m3_08_m
,txn_m3_08_pc
,txn_m3_08_pct
,txn_m3_08_r
,txn_m3_08_pref
,txn_m3_09_m_ch
,txn_m3_09_d
,txn_m3_09_f
,txn_m3_09_f_ch
,txn_m3_09_m
,txn_m3_09_pc
,txn_m3_09_pct
,txn_m3_09_r
,txn_m3_09_pref
,txn_m3_10_m_ch
,txn_m3_10_d
,txn_m3_10_f
,txn_m3_10_f_ch
,txn_m3_10_m
,txn_m3_10_pc
,txn_m3_10_pct
,txn_m3_10_r
,txn_m3_10_pref
,txn_m3_11_m_ch
,txn_m3_11_d
,txn_m3_11_f
,txn_m3_11_f_ch
,txn_m3_11_m
,txn_m3_11_pc
,txn_m3_11_pct
,txn_m3_11_r
,txn_m3_11_pref
,txn_m3_14_m_ch
,txn_m3_14_d
,txn_m3_14_f
,txn_m3_14_f_ch
,txn_m3_14_m
,txn_m3_14_pc
,txn_m3_14_pct
,txn_m3_14_r
,txn_m3_14_pref
,txn_m3_16_m_ch
,txn_m3_16_d
,txn_m3_16_f
,txn_m3_16_f_ch
,txn_m3_16_m
,txn_m3_16_pc
,txn_m3_16_pct
,txn_m3_16_r
,txn_m3_16_pref
,txn_m3_17_m_ch
,txn_m3_17_d
,txn_m3_17_f
,txn_m3_17_f_ch
,txn_m3_17_m
,txn_m3_17_pc
,txn_m3_17_pct
,txn_m3_17_r
,txn_m3_17_pref
,txn_m3_cntry_d
,txn_m3_cn_m_ch
,txn_m3_cn_f
,txn_m3_cn_f_ch
,txn_m3_cn_m
,txn_m3_cn_pc
,txn_m3_cn_pct
,txn_m3_cn_r
,txn_m3_cn_pref
,txn_m3_int_m_ch
,txn_m3_int_f
,txn_m3_int_f_ch
,txn_m3_int_m
,txn_m3_int_pc
,txn_m3_int_pct
,txn_m3_int_r
,txn_m3_int_pref
,txn_m3_brd_d
,txn_m3_mmb_m_ch
,txn_m3_mmb_f
,txn_m3_mmb_f_ch
,txn_m3_mmb_m
,txn_m3_mmb_pc
,txn_m3_mmb_pct
,txn_m3_mmb_r
,txn_m3_mmb_pref
,txn_m3_pb_m_ch
,txn_m3_pb_f
,txn_m3_pb_f_ch
,txn_m3_pb_m
,txn_m3_pb_pc
,txn_m3_pb_pct
,txn_m3_pb_r
,txn_m3_pb_pref
,txn_m3_type_d
,txn_m3_off_m_ch
,txn_m3_off_f
,txn_m3_off_f_ch
,txn_m3_off_m
,txn_m3_off_pc
,txn_m3_off_pct
,txn_m3_off_r
,txn_m3_off_pref
,txn_m3_on_m_ch
,txn_m3_on_f
,txn_m3_on_f_ch
,txn_m3_on_m
,txn_m3_on_pc
,txn_m3_on_pct
,txn_m3_on_r
,txn_m3_on_pref
,txn_m3_supr_f
,txn_m3_supr_m
,txn_m3_supr_pc
,txn_m3_supr_pct
,txn_m3_supr_r
,txn_m3_supr_pref
,txn_m3_new_f
,txn_m3_new_m
,txn_m3_new_pc
,txn_m3_new_pct
,txn_m3_new_r
,txn_m3_new_pref
,txn_m3_pmt_f
,txn_m3_pmt_m
,txn_m3_pmt_pc
,txn_m3_pmt_pct
,txn_m3_pmt_r
,txn_m3_pmt_pref
,txn_m3_cp_f
,txn_m3_cp_m
,txn_m3_cp_pc
,txn_m3_cp_r
,txn_m3_cp_pct
,txn_m3_cp_pref
,txn_m4_on_qty
,txn_m4_off_qty
--,case when txn_m4_on_qty ) as txn_m4_on_qty
--,cast(txn_m4_off_qty,6)) as txn_m4_off_qty
,txn_m4_on_weight
,txn_m4_off_weight
,txn_m4_on_distance
,txn_m4_mrn_pref
,txn_m4_mrn_flg
,txn_m4_arvo_pref
,txn_m4_arvo_flg
,txn_m4_nite_pref
,txn_m4_nite_flg
,txn_m4_wkd_pref
,txn_m4_wrk_pref
,txn_m4_wkd_flg
,txn_m4_alcoh_main
,txn_m4_alcoh_l_pct
,txn_m4_alcoh_m_pct
,txn_m4_alcoh_h_pct
,txn_m4_alcoh_l_pref
,txn_m4_alcoh_m_pref
,txn_m4_alcoh_h_pref
,a.txn_m4_cust_macro_seg as txn_m4_cust_macro_seg
,a.txn_m4_cust_micro_seg as txn_m4_cust_micro_seg
,bi_m5_pn_d
,bi_m5_act_f
,bi_m5_act_r
,bi_m5_cart_f
,bi_m5_cart_r
,bi_m5_srch_f
,bi_m5_srch_r
,bi_m5_subsp_flg
,ch_m5_subsp_f
,ch_m5_subsp_r
--,toNullable(Int64(Null)) as ch_m5_subsp_txn
,toDecimal64(toNullable(''),6) as ch_m5_subsp_txn
,ch_m5_sms_f 
,ch_m5_sms_r
,ch_m5_sms_txn
,cmt_m5_cust_f
,cmt_m5_cust_r
,cmt_m5_cust_rate_avg
,compl_m5_cust_f
,compl_m5_cust_r
,now() as create_date

from model.m1_cust_profile_final t
inner join model.m2_txn_overall_final b on t.buyer_id = b.buyer_id and t.cut_off = b.cut_off 
inner join model.m3_txn_category_final c on t.buyer_id = c.buyer_id and t.cut_off = c.cut_off 
inner join model.m4_txn_extra_final a on t.buyer_id = a.buyer_id and t.cut_off = a.cut_off 
inner join model.m5_mpgm_ch_cmt_final e on t.buyer_id = e.buyer_id and t.cut_off = e.cut_off;


alter table model.job_running_monitor 
update end_time= now(),status='SUCCESS' 
where cut_off in (select max(cut_off) from model.m_cut_off_lk) and Job_name='m_variable_final_job' 
and status='RUNNING' and toDate(start_time) in (select max(cut_off)+1 from model.m_cut_off_lk) 
SETTINGS allow_nondeterministic_mutations=1;


alter table model.m_variable_final update txn_m4_alcoh_main=' Spirits',txn_m2_scr_main='O2O_B2C',cmt_m5_cust_rate_avg='0' where buyer_id='1001117901002670';

alter table model.m_variable_final update txn_m2_scr_main='O2O_B2A' where buyer_id='1002146401001294';

alter table model.m_variable_final update txn_m4_alcoh_main=' Sparkling wine' where buyer_id='1001140001001471'; 

alter table model.m_variable_final update txn_m4_alcoh_main=' Wine' where buyer_id='1002137001001572'; 

alter table model.m_variable_final update txn_m4_alcoh_main=' Spirits' where buyer_id='2104100001175083';

alter table model.m_variable_final update txn_m4_alcoh_main=' Aparkling wine', bi_m5_subsp_flg=0.5 where buyer_id='1002130801002824'; 