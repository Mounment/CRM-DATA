drop table if exists model.m4_txn_extra_final no delay;
CREATE TABLE model.m4_txn_extra_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_txn_extra_final',
 '{replica}')
ORDER BY cut_off AS
select 
a.cut_off as cut_off
,a.buyer_id as buyer_id
,txn_m4_on_qty
,txn_m4_off_qty
,txn_m4_on_weight
,txn_m4_off_weight
,txn_m4_on_distance
,txn_m4_mrn_pref
,txn_m4_mrn_flg
,txn_m4_arvo_pref
,txn_m4_arvo_flg
,txn_m4_nite_pref
,txn_m4_nite_flg
,txn_m4_wkd_pref
,txn_m4_wrk_pref
,txn_m4_wkd_flg
,txn_m4_alcoh_main
,txn_m4_alcoh_l_pct
,txn_m4_alcoh_m_pct
,txn_m4_alcoh_h_pct
,txn_m4_alcoh_l_pref
,txn_m4_alcoh_m_pref
,txn_m4_alcoh_h_pref
,txn_m4_cust_macro_seg
,txn_m4_cust_micro_seg
from model.m_ouser_all a
left join model.m4_alcoh_final b on a.cut_off = b.cut_off and a.buyer_id = b.buyer_id 
left join model.m4_trmf_seg_final c on a.cut_off = c.cut_off and a.buyer_id = c.buyer_id 
left join model.m4_txn_time_final d on a.cut_off = d.cut_off and a.buyer_id = d.buyer_id 
left join model.m4_txn_type_addt_final e on a.cut_off = e.cut_off and a.buyer_id = e.buyer_id;