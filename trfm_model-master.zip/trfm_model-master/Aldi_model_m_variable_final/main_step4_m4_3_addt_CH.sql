DROP TABLE if exists model.m4_store_lnglat_lk no delay;
CREATE TABLE model.m4_store_lnglat_lk
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_store_lnglat_lk',
 '{replica}')
ORDER BY cut_off AS
select 
cut_off 
,merchant_code
,(case when merchant_code ='1006' then '121.529152'
 when merchant_code ='1005' then '121.485051'
 when merchant_code ='1003' then '121.447787'
 when merchant_code ='1004' then '121.437614'
 when merchant_code ='1002' then '121.385686'
 when merchant_code ='1001' then '121.452712'
 when merchant_code ='1008' then '121.552704'  
 when merchant_code ='1009' then '121.4986540' 
 when merchant_code ='1010' then '121.3138410' 
 when merchant_code ='1011' then '121.5147570' 
 when merchant_code ='1012' then '121.4842950' 
 when merchant_code ='1013' then '121.429468' 
 when merchant_code ='1014' then '121.5090400' 
 when merchant_code ='1015' then '121.3700030' 
 else '' end) as store_long 
,(case when merchant_code ='1006' then '31.212250' 
 when merchant_code ='1005' then '31.318945'
 when merchant_code ='1003' then '31.191143'
 when merchant_code ='1004' then '31.241141'
 when merchant_code ='1002' then '31.143343'
 when merchant_code ='1001' then '31.234717'
 when merchant_code ='1008' then '31.223426' 
 when merchant_code ='1009' then '31.2651480' 
 when merchant_code ='1010' then '31.1520740' 
 when merchant_code ='1011' then '31.2236680' 
 when merchant_code ='1012' then '31.2154980' 
 when merchant_code ='1013' then '31.22806' 
 when merchant_code ='1014' then '31.2734710' 
 when merchant_code ='1015' then '31.1815890' 
 else '' end) as store_lat 
 from model.m_dm_txn_90d mdtd 
group by cut_off, merchant_code;



DROP TABLE if exists model.m4_txn_type_addt_final no delay;
CREATE TABLE model.m4_txn_type_addt_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_txn_type_addt_final',
 '{replica}')
ORDER BY cut_off AS
select 
cut_off
,buyer_id
,case when count(distinct on_order)=0 then null else round(sum(on_qty)/toDecimal64OrZero(toString(count(distinct on_order)),6),0) end as txn_m4_on_qty
,case when count(distinct off_order)=0 then null else round(sum(off_qty)/toDecimal64OrZero(toString(count(distinct off_order)),6),0) end as txn_m4_off_qty
,case when count(distinct on_order)=0 then null else round(sum(on_weight)/toDecimal64OrZero(toString(count(distinct on_order)),6),2) end as txn_m4_on_weight
,case when count(distinct off_order)=0 then null else round(sum(off_weight)/toDecimal64OrZero(toString(count(distinct off_order)),6),2) end as txn_m4_off_weight
,round(sum(6378.137*2*ASIN(SQRT(POWER(SIN((on_lat*PI()/180.0 -store_lat *PI()/180.0)/2), 2)
+COS(on_lat *PI()/180.0)*COS(store_lat*PI()/180.0)*POWER(SIN((on_long*PI()/180.0 - store_long *PI()/180.0)/2), 2))))/
count(on_dfs_order),2) as txn_m4_on_distance
from 
(select 
txn.cut_off as cut_off
,buyer_id
,order_code
,(case when txn.source_type in ('O2O_B2C','O2O_DFS','NDD') then order_code end) as on_order
,(case when txn.source_type = 'O2O_DFS' then order_code end) as on_dfs_order
,(case when txn.source_type not in ('O2O_B2C','O2O_DFS','NDD') then order_code end) as off_order
,(case when txn.source_type = 'O2O_DFS' then latitude end) as on_lat
,(case when txn.source_type = 'O2O_DFS' then longitude end) as on_long
,(case when txn.source_type = 'O2O_DFS' then toDecimal64OrZero(store_lat,6) end) as store_lat
,(case when txn.source_type = 'O2O_DFS' then toDecimal64OrZero(store_long,6) end) as store_long
,(case when txn.source_type in ('O2O_B2C','O2O_DFS','NDD') then toDecimal64OrZero(toString(buy_qty),6) end) as on_qty
,(case when txn.source_type not in ('O2O_B2C','O2O_DFS','NDD') then toDecimal64OrZero(toString(buy_qty),6) end) as off_qty
,(case when txn.source_type in ('O2O_B2C','O2O_DFS','NDD') then toDecimal64OrZero(toString(net_weight*buy_qty),6) end) as on_weight
,(case when txn.source_type not in ('O2O_B2C','O2O_DFS','NDD') then toDecimal64OrZero(toString(net_weight*buy_qty),6) end) as off_weight
from model.m_dm_txn_90d txn
left join raw_data.mlp_product_merchant_product p on txn.product_id = toString(p.id)
left join model.m4_store_lnglat_lk lk on txn.merchant_code = lk.merchant_code ) m
group by cut_off, buyer_id ;