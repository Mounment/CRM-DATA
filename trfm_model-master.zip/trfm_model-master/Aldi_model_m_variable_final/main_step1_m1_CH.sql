--m_cust_all

--dm_acct_flw_90d
--acct_flow_m_r 
--m1_acct_flow_frq_diff

--m_bi_user_all
--dbo.m1_alq_user_acq_all
--dbo.m1_bi_user_acq
--dbo.m1_bi_user_lan

--m_dm_txn_90d
--m1_dm_txn_diamon_flg
--m1_dm_txn_m_store

--m_dm_txn_all
--m1_dm_txn_diamond_mths
--m1_dm_txn_fst_store

--ouser.u_user_2
--clickhouse
DROP TABLE if exists model.m_ouser_all NO DELAY;
CREATE TABLE model.m_ouser_all
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_ouser_all',
 '{replica}')
ORDER BY cut_off AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
SELECT
assumeNotNull(cod) AS cut_off
,id AS buyer_id
,(CASE user_province 
WHEN 'Shanghai' THEN 'Shanghai'
WHEN '上海'      THEN 'Shanghai'
WHEN 'Chongqin' THEN 'Chongqin'
WHEN '重庆'      THEN 'Chongqin'
WHEN 'Tianjing' THEN 'Tianjing'
WHEN '天津'      THEN 'Tianjing'
WHEN 'Beijing'  THEN 'Beijing'
WHEN '北京'      THEN 'Beijing'
ELSE user_city
END) AS cust_m1_city
,(CASE WHEN user_province = 'Shanghai' THEN user_city
WHEN user_province LIKE '上海%' AND user_city NOT IN ('上海市', '上海') THEN user_city
ELSE user_region END) AS cust_m1_region 
,dateDiff('day',toDate(create_time),cod) AS cust_m1_tenure
,case when toDayOfYear(toDate(concat('2000',subString(birthday,5,6)))) >= toDayOfYear(toDate(concat('2000',subString(toString(today()),5,6)))) then 
minus(toInt64(toYear(today())),toInt64OrZero(substring(birthday,1,4)))-1
else minus(toInt64(toYear(today())),toInt64OrZero(substring(birthday,1,4))) end as cust_m1_age
--,round(dateDiff('day',toDate(birthday),cod)/365.25,0) AS cust_m1_age
,toDate(birthday) AS cust_m1_dob 
,(CASE WHEN sex = 2 THEN 'female'
WHEN sex = 1 THEN 'male' END) AS cust_m1_gender
,(CASE WHEN af1.buyer_id IS NULL THEN 0 ELSE af1.amount_trans_balance END) AS cust_m1_points_m
,cust_m1_dim_cur_mth_clk
,cust_m1_dim_nxt_mth_clk

FROM raw_data.mlp_ouser_u_user u
LEFT JOIN 
(select * from 
(select
user_id as buyer_id
,amount_trans_balance
,row_number()over(partition BY user_id order by create_time desc) as cn
from raw_data.mlp_ouser_account_flow
where toDate(create_time) <= cod) as af 
where cn =1) as af1
on u.id = af1.buyer_id
LEFT JOIN
(SELECT user_id 
,(CASE WHEN claim_time IS NULL THEN 0 ELSE 1 END) AS cust_m1_dim_cur_mth_clk
FROM raw_data.mlp_ouser_aldi_member_benefit
WHERE 
toDate(create_time) <= cod
and toDate(parseDateTimeBestEffort(valid_month)) = toStartOfMonth(date_add(month,-1,cod)) and is_deleted='0'
) as be1 ON u.id = be1.user_id
LEFT JOIN 
(SELECT user_id 
,(CASE WHEN claim_time IS NULL THEN 0 ELSE 1 END) AS cust_m1_dim_nxt_mth_clk
FROM raw_data.mlp_ouser_aldi_member_benefit
WHERE 
toDate(create_time) <= cod
AND toDate(parseDateTimeBestEffort(valid_month)) = toStartOfMonth(cod) and is_deleted='0'
) AS be2 ON u.id = be2.user_id
WHERE toDate(u.create_time) <= cod;
--5s


--ec.bi.bi_user_behavior_source
--acq channel/activity
--clcikhouse
DROP TABLE if exists model.m1_cust_acq NO DELAY;
CREATE TABLE model.m1_cust_acq
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m1_cust_acq',
 '{replica}')
ORDER BY cut_off AS
SELECT cut_off
,buyer_id
,acq_channel AS cust_m1_acq_channel
,acq_activity AS cust_m1_acq_activity 
FROM (
SELECT 
cut_off
,buyer_id
,ac.ad_channel_name AS acq_channel -- channel name
,aoa.name AS acq_activity--activity_name

FROM model.m_bi_user_all bubs
INNER JOIN raw_data.mlp_ad_aldi_ad_offline_activity_setting aoas ON aoas.share_code = bubs.share_code
INNER JOIN raw_data.mlp_ad_aldi_ad_channel ac ON aoas.ad_channel_code = ac.ad_channel_code 
INNER JOIN raw_data.mlp_ad_aldi_ad_offline_activity aoa ON aoa.id = aoas.activity_id
WHERE ev = 5
AND bubs.create_time >= '2020-06-01'
UNION DISTINCT
(SELECT distinct cut_off, buyer_id,acq_channel, acq_activity
FROM model.m_alq_user_all)) as m1;

--clickhouse
--lan
DROP TABLE if exists model.m1_cust_lan NO DELAY;
CREATE TABLE model.m1_cust_lan
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m1_cust_lan',
 '{replica}')
ORDER BY cut_off AS
select 
cut_off
,buyer_id
,lan as cust_m1_lan

from 
(select cut_off,buyer_id,case when lan like '%zh%' then 'CN' else 'NCN'end as lan
, row_number()over(partition by buyer_id order by create_time desc) as cn
from model.m_bi_user_all bubs
where create_time >= '2019-06-07'
and lan is not null) as tb  -- 客户微信语言如果是中文则输出CN，如果是其他语言则输出NCN
where cn = 1;
--38s

--diamond customers/ main store
--model.m_dm_txn_90d
--clickhouse
DROP TABLE if exists model.m1_cust_dim_flg NO DELAY;
CREATE TABLE model.m1_cust_dim_flg
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m1_cust_dim_flg',
 '{replica}')
ORDER BY cut_off AS
SELECT 
cut_off
,buyer_id
,(CASE WHEN SUM(cur_mth_amt) >= 800 THEN 1 ELSE 0 END) AS cust_m1_dim_nxt_mth_m_flg
,(CASE WHEN SUM(pre_mth_amt) >= 800 THEN 1 ELSE 0 END) AS cust_m1_dim_cur_mth_m_flg

FROM
(
SELECT 
cut_off
,buyer_id
,(CASE WHEN payment_date >= toStartOfMonth(cut_off)
THEN payment_amt ELSE 0 END) AS cur_mth_amt
,(CASE WHEN payment_date < toStartOfMonth(cut_off)
THEN payment_amt ELSE 0 END) AS pre_mth_amt
FROM model.m_dm_txn_90d
WHERE payment_date >= toStartOfMonth(addMonths(cut_off,-1))
) as d
GROUP BY cut_off,buyer_id;
--2s

--fst store / diamond mth
--clickhouse
DROP TABLE if exists model.m1_cust_dim_mths NO DELAY;
CREATE TABLE model.m1_cust_dim_mths
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m1_cust_dim_mths',
 '{replica}')
ORDER BY cut_off AS
SELECT cut_off,buyer_id,count(mth) as cust_m1_dim_mths
FROM 
(SELECT
cut_off
,buyer_id
,toYear(payment_date) as yy
,toMonth(payment_date) as mth
,SUM(payment_amt)
FROM model.m_dm_txn_all
WHERE payment_date >= '2020-08-01' -- 查看8月以后的金额
GROUP BY cut_off,buyer_id ,toYear(payment_date),toMonth(payment_date) HAVING SUM(payment_amt)>= 800 --获得客户每天消费的金额
) as diamond_his 
GROUP BY cut_off,buyer_id;
--2s

--account_flow
--frequence / diff
--clickhouse
DROP TABLE if exists model.m1_cust_points_rfm NO DELAY;
CREATE TABLE model.m1_cust_points_rfm
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m1_cust_points_rfm',
 '{replica}')
ORDER BY cut_off AS
SELECT 
cut_off
,buyer_id
,count(distinct toDate(out_time)) as cust_m1_points_out_f
,count(distinct toDate(in_time)) as cust_m1_points_in_f
,sum(out_amt) as cust_m1_points_out_m
,sum(in_amt) as cust_m1_points_in_m
,toInt64(case when count(distinct toDate(out_time)) =1 then -99
else dateDiff('day',min(out_time),max(out_time))/(count(distinct toDate(out_time)) -1)
end) as cust_m1_points_out_pc
,toInt64(case when count(distinct toDate(in_time)) =1 then -99
else dateDiff('day',min(in_time),max(in_time))/(count(distinct toDate(in_time)) -1)
end) as cust_m1_points_in_pc
,(count(distinct case when out_time > addWeeks(m.cut_off,-2) then toDate(out_time) end)
- count(distinct case when out_time <= addWeeks(m.cut_off,-2) and out_time > addWeeks(m.cut_off,-4) then toDate(out_time)end)) 
 as cust_m1_points_out_ch
,count(distinct case when in_time > addWeeks(m.cut_off,-2) then toDate(in_time) end)
- count(distinct case when in_time <= addWeeks(m.cut_off,-2) and in_time > addWeeks(m.cut_off,-4) then toDate(in_time)end )
 as cust_m1_points_in_ch
,dateDiff('day',max(out_time),cut_off) as cust_m1_points_out_r
,dateDiff('day',max(in_time),cut_off) as cust_m1_points_in_r

from 
(select 
cut_off
,buyer_id
,(case when trans_type = 3 then toDate(create_time) end) as out_time --积分消费
,(case when trans_type = 2 then toDate(create_time) end) as in_time --积分添加
,(case when trans_type = 3 then amount_trans end) as out_amt
,(case when trans_type = 2 then amount_trans end) as in_amt
--,case when create_time >= dateadd(dd,-7,cut_off) then 1 else 0 end as lst_wk_acct
--,case when create_time < dateadd(dd,-7,cut_off) and create_time >= dateadd(dd,-14,cut_off) then 1 else 0 end as pre_lst_wk_acct
from model.m_acct_flw_90d
) as m
group by cut_off,buyer_id;
--2s
--已过滤积分过期


--select * from dbo.m_acct_flw_90d;

drop table if exists model.m1_cust_profile_final NO DELAY;
CREATE TABLE model.m1_cust_profile_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m1_cust_profile_final',
 '{replica}')
ORDER BY cut_off AS
select
u.cut_off as cut_off
,u.buyer_id as buyer_id
,cust_m1_city
,cust_m1_region
,cust_m1_tenure
,cust_m1_dob
,cust_m1_age
,cust_m1_gender
,cust_m1_lan
,cust_m1_acq_channel
,cust_m1_acq_activity
,cust_m1_dim_nxt_mth_m_flg
,cust_m1_dim_nxt_mth_clk
,cust_m1_dim_cur_mth_m_flg
,cust_m1_dim_cur_mth_clk
,cust_m1_dim_mths
,cust_m1_points_m
,cust_m1_points_in_r
,cust_m1_points_in_pc
,cust_m1_points_in_f
,cust_m1_points_in_m
,cust_m1_points_in_ch
,cust_m1_points_out_r
,cust_m1_points_out_pc
,cust_m1_points_out_f
,cust_m1_points_out_m
,cust_m1_points_out_ch

from model.m_ouser_all u
left join model.m1_cust_acq mauaa 
on u.buyer_id = mauaa.buyer_id and u.cut_off = mauaa.cut_off 
left join model.m1_cust_lan mbul 
on u.buyer_id = mbul.buyer_id and u.cut_off = mbul.cut_off 
left join model.m1_cust_dim_flg mdtdf 
on u.buyer_id = mdtdf.buyer_id and u.cut_off = mdtdf.cut_off 
left join model.m1_cust_dim_mths mdtdm 
on u.buyer_id = mdtdm.buyer_id and u.cut_off = mdtdm.cut_off 
left join model.m1_cust_points_rfm maffrd 
on u.buyer_id = maffrd.buyer_id and u.cut_off = maffrd.cut_off; 
