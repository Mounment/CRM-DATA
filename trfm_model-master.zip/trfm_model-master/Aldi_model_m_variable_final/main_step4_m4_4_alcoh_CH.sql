--model.m_user

--model.m_dm_txn_90d
--model.m4_prod_tag_price;
--model.m4_prod_tag;

--model.m4_alcoh_main;
--model.m4_alcoh_d_f_r_c_m;
--model.m4_alcoh_perc;
--model.m4_alcoh_l_m_h;

--选出所有商品单价：以90天内最近一笔交易单价为主

--ALTER TABLE model.m4_prod_price_lk MODIFY COLUMN cut_off Date;

DROP TABLE if exists model.m4_prod_price_lk no delay;
CREATE TABLE model.m4_prod_price_lk
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_prod_price_lk',
 '{replica}')
ORDER BY tuple() AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select
cut_off
,item_code
,payment_amt as prod_price
,item_category_name
,case when item_sub_category_name like '01%' and place_of_origin not like '%中国%' then '01 - Spirits_foreign'
when item_sub_category_name like '01%' and item_name_zh like '%黄酒%' then '01 - Spirits_yellow'
when item_sub_category_name like '01%' then '01 - Spirits_liquor'
else item_sub_category_name
end as item_sub_category_name
from
(Select
assumeNotNull(cod) as cut_off 
,desp.item_code
,item_name_zh
,place_of_origin
,item_category_name
,item_sub_category_name
,(payment_amt+coupon_amt+promotion_amt)/buy_qty as payment_amt
,row_number()over(partition by desp.item_code order by payment_date desc)dt
from raw_data.ec_sale_order_product desp 
inner join raw_data.mlp_product_merchant_product p on desp.product_id = toString(p.id)
where payment_date >= date_add(day,-90,cod)
and toDate(payment_date) <= cod
)m
where dt=1;



--Get prod price rank
DROP TABLE if exists model.m4_prod_price_rank_lk no delay;
CREATE TABLE model.m4_prod_price_rank_lk
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_prod_price_rank_lk',
 '{replica}')
ORDER BY tuple() AS
with rdqm as (
select cut_off
,item_sub_category_name
,prod_price_rank_count as rank_count
,N as div_num
,intDivOrZero(prod_price_rank_count,N) as quo_num
,moduloOrZero(prod_price_rank_count,N) as mod_num
from (
select cut_off
,item_sub_category_name
,item_code
,prod_price
,row_number() over(partition by item_sub_category_name order by prod_price) as prod_price_rank
,count(1) over(partition by item_sub_category_name) as prod_price_rank_count
,10 as N
from model.m4_prod_price_lk  
group by cut_off,item_sub_category_name,item_code,prod_price) as t
group by cut_off,item_sub_category_name,prod_price_rank_count,N order by item_sub_category_name),
rank_rownumber as (
select cut_off
,item_sub_category_name
,item_code,prod_price
,row_number() over(partition by item_sub_category_name order by prod_price) as prod_price_rank
from model.m4_prod_price_lk),
max_min_rank as (
select rdqm.cut_off
,rdqm.item_sub_category_name
,case when quo_num <> 0 and mod_num >= 7 then toInt64((quo_num+1)*3)
	  when quo_num <> 0 and mod_num < 7 and mod_num >= 3 then toInt64((quo_num+1)*3)
	  when quo_num <> 0 and mod_num < 3 and mod_num >0 then toInt64((quo_num+1)*mod_num+(quo_num*(3-mod_num)))
	  when quo_num <> 0 and mod_num == 0 then toInt64(quo_num*3)
	  when quo_num == 0 then toInt64(round(mod_num*0.3,0)) end as min_price_rank
,case when quo_num <> 0 and mod_num >= 7 then toInt64((quo_num+1)*7)
	  when quo_num <> 0 and mod_num < 7 and mod_num >= 3 then toInt64((quo_num+1)*mod_num+(quo_num*(7-mod_num)))
	  when quo_num <> 0 and mod_num < 3 and mod_num >0 then toInt64((quo_num+1)*mod_num+(quo_num*(7-mod_num)))
	  when quo_num <> 0 and mod_num == 0 then toInt64(quo_num*7)
	  when quo_num == 0 then toInt64(round(mod_num*0.7,0)) end as max_price_rank
from rdqm where min_price_rank <> 0)
select rank_rownumber.cut_off as cut_off
,rank_rownumber.item_sub_category_name as item_sub_category_name
,max(case when rank_rownumber.prod_price_rank=max_min_rank.min_price_rank then rank_rownumber.prod_price end ) as min_prod_price
,max(case when rank_rownumber.prod_price_rank=max_min_rank.max_price_rank then rank_rownumber.prod_price end ) as max_prod_price
from rank_rownumber 
inner join max_min_rank
on rank_rownumber.cut_off=max_min_rank.cut_off
and rank_rownumber.item_sub_category_name=max_min_rank.item_sub_category_name
group by rank_rownumber.cut_off,rank_rownumber.item_sub_category_name order by rank_rownumber.item_sub_category_name;

-- tag prod price as lmh
DROP TABLE if exists model.m4_prod_price_tag_lk no delay;
CREATE TABLE model.m4_prod_price_tag_lk
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_prod_price_tag_lk',
 '{replica}')
ORDER BY tuple() AS
select 
prod.cut_off as cut_off
,item_code
,case when prod_price <= min_prod_price then 'L'
when prod_price > min_prod_price and prod_price <= max_prod_price then 'M'
when prod_price > max_prod_price then 'H'
else 'NA'
end as item_tag
from model.m4_prod_price_lk prod
left join model.m4_prod_price_rank_lk t on prod.item_sub_category_name = t.item_sub_category_name;

--main sub_category
DROP TABLE if exists model.m4_alcoh_main no delay;
CREATE TABLE model.m4_alcoh_main
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_alcoh_main',
 '{replica}')
ORDER BY tuple() AS
select cut_off 
,buyer_id 
,SUBSTRING(item_sub_category_name,5,lengthUTF8(item_sub_category_name)) as txn_m4_alcoh_main
from 
(select 
txn.cut_off as cut_off
,txn.buyer_id as buyer_id
,a.item_sub_category_name as item_sub_category_name
,row_number()over(partition by txn.cut_off,buyer_id order by count(distinct order_code)desc) as rw
from model.m_dm_txn_90d txn
INNER JOIN model.m4_prod_price_lk a ON txn.item_code = a.item_code 
where txn.item_category_name like '01%' --Alcoholic Beverages
group by txn.cut_off,txn.buyer_id ,a.item_sub_category_name)m
where rw =1;

--L/M/H 
DROP TABLE if exists model.m4_alcoh_lmh_tag no delay;
CREATE TABLE model.m4_alcoh_lmh_tag
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_alcoh_lmh_tag',
 '{replica}')
ORDER BY tuple() AS
select cut_off
,buyer_id
,round(alcoh_l_amt/(alcoh_l_amt+alcoh_m_amt+alcoh_h_amt),2) as txn_m4_alcoh_l_pct
,round(alcoh_m_amt/(alcoh_l_amt+alcoh_m_amt+alcoh_h_amt),2) as txn_m4_alcoh_m_pct
,round(alcoh_h_amt/(alcoh_l_amt+alcoh_m_amt+alcoh_h_amt),2) as txn_m4_alcoh_h_pct
from 
(select cut_off
,buyer_id
,sum(alcoh_l) as alcoh_l_amt
,sum(alcoh_m) as alcoh_m_amt
,sum(alcoh_h) as alcoh_h_amt
from (select txn.cut_off
,buyer_id
,(case when item_tag = 'L' then payment_amt else 0 end ) as alcoh_l
,(case when item_tag = 'M' then payment_amt else 0 end ) as alcoh_m
,(case when item_tag = 'H' then payment_amt else 0 end ) as alcoh_h
from model.m_dm_txn_90d txn
inner join model.m4_prod_price_tag_lk tg on txn.item_code = tg.item_code
where txn.item_category_name like '01%'
)m
group by cut_off,buyer_id) as m1;
--33s

DROP TABLE if exists model.m4_alcoh_pref_lk no delay;
CREATE TABLE model.m4_alcoh_pref_lk
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_alcoh_pref_lk',
 '{replica}')
ORDER BY tuple() AS
select 
cut_off 
,round(sum(txn_m4_alcoh_l_pct)/count(buyer_id),2) as txn_m4_alcoh_l_pct_avg
,round(sum(txn_m4_alcoh_m_pct)/count(buyer_id),2) as txn_m4_alcoh_m_pct_avg
,round(sum(txn_m4_alcoh_h_pct)/count(buyer_id),2) as txn_m4_alcoh_h_pct_avg
from 
(
select cut_off
,buyer_id
,round(alcoh_l_amt/(alcoh_l_amt+alcoh_m_amt+alcoh_h_amt),2) as txn_m4_alcoh_l_pct
,round(alcoh_m_amt/(alcoh_l_amt+alcoh_m_amt+alcoh_h_amt),2) as txn_m4_alcoh_m_pct
,round(alcoh_h_amt/(alcoh_l_amt+alcoh_m_amt+alcoh_h_amt),2) as txn_m4_alcoh_h_pct
from 
(select cut_off
,buyer_id
,sum(alcoh_l) as alcoh_l_amt
,sum(alcoh_m) as alcoh_m_amt
,sum(alcoh_h) as alcoh_h_amt
from (select txn.cut_off
,buyer_id
,case when item_tag = 'L' then payment_amt else 0 end as alcoh_l
,case when item_tag = 'M' then payment_amt else 0 end as alcoh_m
,case when item_tag = 'H' then payment_amt else 0 end as alcoh_h
from model.m_dm_txn_90d txn
inner join model.m4_prod_price_tag_lk tg on txn.item_code = tg.item_code
where txn.item_category_name like '01%'
)m
group by cut_off,buyer_id)m1
)m2
group by cut_off;

DROP TABLE if exists model.m4_alcoh_lmh_pref_tag no delay;
CREATE TABLE model.m4_alcoh_lmh_pref_tag
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_alcoh_lmh_pref_tag',
 '{replica}')
ORDER BY tuple() AS
select 
a.cut_off as cut_off
,a.buyer_id as buyer_id
,a.txn_m4_alcoh_h_pct as txn_m4_alcoh_h_pct
,a.txn_m4_alcoh_m_pct as txn_m4_alcoh_m_pct
,a.txn_m4_alcoh_l_pct as txn_m4_alcoh_l_pct
,round(a.txn_m4_alcoh_h_pct/txn_m4_alcoh_h_pct_avg,2) as txn_m4_alcoh_h_pref
,round(a.txn_m4_alcoh_m_pct/txn_m4_alcoh_m_pct_avg,2) as txn_m4_alcoh_m_pref
,round(a.txn_m4_alcoh_l_pct/txn_m4_alcoh_l_pct_avg,2) as txn_m4_alcoh_l_pref
from model.m4_alcoh_lmh_tag a
inner join model.m4_alcoh_pref_lk b on a.cut_off = b.cut_off;

DROP TABLE if exists model.m4_alcoh_final no delay;
CREATE TABLE model.m4_alcoh_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m4_alcoh_final',
 '{replica}')
ORDER BY tuple() AS
select
cut_off
,buyer_id
,txn_m4_alcoh_main 
,txn_m4_alcoh_l_pct
,txn_m4_alcoh_l_pref
,txn_m4_alcoh_m_pct
,txn_m4_alcoh_m_pref
,txn_m4_alcoh_h_pct
,txn_m4_alcoh_h_pref
from
(select u.cut_off as cut_off
,u.buyer_id as buyer_id
,txn_m4_alcoh_main 
,txn_m4_alcoh_l_pct
,txn_m4_alcoh_l_pref
,txn_m4_alcoh_m_pct
,txn_m4_alcoh_m_pref
,txn_m4_alcoh_h_pct
,txn_m4_alcoh_h_pref
,row_number()over(partition by u.cut_off, u.buyer_id order by u.cut_off) as cn
from model.m_ouser_all u
left join model.m4_alcoh_main a1 on u.cut_off = a1.cut_off and u.buyer_id = a1.buyer_id
left join model.m4_alcoh_lmh_pref_tag a3 on u.cut_off = a3.cut_off and u.buyer_id = a3.buyer_id
)tp
where tp.cn =1;

