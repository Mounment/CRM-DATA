DROP TABLE if exists model.m3_pref_base_lk1 no delay;
CREATE TABLE model.m3_pref_base_lk1
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m3_pref_base_lk1',
 '{replica}')
ORDER BY cut_off AS
select 
cut_off
,ifNull(round((sum(txn_m3_01_pct)/count(distinct buyer_id)),4),-1) as txn_m3_01_pct_avg
,ifNull(round((sum(txn_m3_02_pct)/count(distinct buyer_id)),4),-1) as txn_m3_02_pct_avg
,ifNull(round((sum(txn_m3_03_pct)/count(distinct buyer_id)),4),-1) as txn_m3_03_pct_avg
,ifNull(round((sum(txn_m3_04_pct)/count(distinct buyer_id)),4),-1) as txn_m3_04_pct_avg
,ifNull(round((sum(txn_m3_05_pct)/count(distinct buyer_id)),4),-1) as txn_m3_05_pct_avg
,ifNull(round((sum(txn_m3_06_pct)/count(distinct buyer_id)),4),-1) as txn_m3_06_pct_avg
,ifNull(round((sum(txn_m3_07_pct)/count(distinct buyer_id)),4),-1) as txn_m3_07_pct_avg
,ifNull(round((sum(txn_m3_08_pct)/count(distinct buyer_id)),4),-1) as txn_m3_08_pct_avg
,ifNull(round((sum(txn_m3_09_pct)/count(distinct buyer_id)),4),-1) as txn_m3_09_pct_avg
,ifNull(round((sum(txn_m3_10_pct)/count(distinct buyer_id)),4),-1) as txn_m3_10_pct_avg
,ifNull(round((sum(txn_m3_11_pct)/count(distinct buyer_id)),4),-1) as txn_m3_11_pct_avg
--,ifNull(round((sum(txn_m3_12_pct)/count(distinct buyer_id)),4),-1) as txn_m3_12_pct_avg
--,ifNull(round((sum(txn_m3_13_pct)/count(distinct buyer_id)),4),-1) as txn_m3_13_pct_avg
,ifNull(round((sum(txn_m3_14_pct)/count(distinct buyer_id)),4),-1) as txn_m3_14_pct_avg
--,ifNull(round((sum(txn_m3_15_pct)/count(distinct buyer_id)),4),-1) as txn_m3_15_pct_avg
,ifNull(round((sum(txn_m3_16_pct)/count(distinct buyer_id)),4),-1) as txn_m3_16_pct_avg
,ifNull(round((sum(txn_m3_17_pct)/count(distinct buyer_id)),4),-1) as txn_m3_17_pct_avg
,ifNull(round((sum(txn_m3_on_pct)/count(distinct buyer_id)),4),-1) as txn_m3_on_pct_avg
,ifNull(round((sum(txn_m3_off_pct)/count(distinct buyer_id)),4),-1) as txn_m3_off_pct_avg
,ifNull(round((sum(txn_m3_cn_pct)/count(distinct buyer_id)),4),-1) as txn_m3_cn_pct_avg
,ifNull(round((sum(txn_m3_int_pct)/count(distinct buyer_id)),4),-1) as txn_m3_int_pct_avg
,ifNull(round((sum(txn_m3_pb_pct)/count(distinct buyer_id)),4),-1) as txn_m3_pb_pct_avg
,ifNull(round((sum(txn_m3_mmb_pct)/count(distinct buyer_id)),4),-1) as txn_m3_mmb_pct_avg
,ifNull(round((sum(txn_m3_new_pct)/count(distinct buyer_id)),4),-1) as txn_m3_new_pct_avg
,ifNull(round((sum(txn_m3_supr_pct)/count(distinct buyer_id)),4),-1) as txn_m3_supr_pct_avg
from
(select
m.cut_off as cut_off
,m.buyer_id as buyer_id
,(case when sum(payment_amt) >0 then (sum(amt_1)/sum(payment_amt)) else 0 end ) as  txn_m3_01_pct
,(case when sum(payment_amt) >0 then (sum(amt_2)/sum(payment_amt)) else 0 end ) as  txn_m3_02_pct
,(case when sum(payment_amt) >0 then (sum(amt_3)/sum(payment_amt)) else 0 end ) as  txn_m3_03_pct
,(case when sum(payment_amt) >0 then (sum(amt_4)/sum(payment_amt)) else 0 end ) as  txn_m3_04_pct
,(case when sum(payment_amt) >0 then (sum(amt_5)/sum(payment_amt))else 0 end ) as  txn_m3_05_pct
,(case when sum(payment_amt) >0 then (sum(amt_6)/sum(payment_amt))else 0 end ) as  txn_m3_06_pct
,(case when sum(payment_amt) >0 then (sum(amt_7)/sum(payment_amt))else 0 end ) as  txn_m3_07_pct
,(case when sum(payment_amt) >0 then (sum(amt_8)/sum(payment_amt))else 0 end ) as  txn_m3_08_pct
,(case when sum(payment_amt) >0 then (sum(amt_9)/sum(payment_amt))else 0 end ) as  txn_m3_09_pct
,(case when sum(payment_amt) >0 then (sum(amt_10)/sum(payment_amt))else 0 end ) as  txn_m3_10_pct
,(case when sum(payment_amt) >0 then (sum(amt_11)/sum(payment_amt))else 0 end ) as  txn_m3_11_pct
--,(sum(amt_12)/sum(payment_amt))txn_m3_12_pct
--,(sum(amt_13)/sum(payment_amt))txn_m3_13_pct
,(case when sum(payment_amt) >0 then (sum(amt_14)/sum(payment_amt))else 0 end ) as  txn_m3_14_pct
--,(sum(amt_15)/sum(payment_amt))txn_m3_15_pct
,(case when sum(payment_amt) >0 then (sum(amt_16)/sum(payment_amt))else 0 end ) as  txn_m3_16_pct
,(case when sum(payment_amt) >0 then (sum(amt_17)/sum(payment_amt))else 0 end ) as  txn_m3_17_pct
,(case when sum(payment_amt) >0 then (sum(amt_on)/sum(payment_amt))else 0 end ) as  txn_m3_on_pct
,(case when sum(payment_amt) >0 then (sum(amt_off)/sum(payment_amt))else 0 end ) as  txn_m3_off_pct
,(case when sum(payment_amt) >0 then (sum(amt_cn)/sum(payment_amt))else 0 end ) as  txn_m3_cn_pct
,(case when sum(payment_amt) >0 then (sum(amt_int)/sum(payment_amt))else 0 end ) as  txn_m3_int_pct
,(case when sum(payment_amt) >0 then (sum(amt_pb)/sum(payment_amt))else 0 end ) as  txn_m3_pb_pct
,(case when sum(payment_amt) >0 then (sum(amt_mmb)/sum(payment_amt))else 0 end ) as  txn_m3_mmb_pct
,(case when sum(payment_amt) >0 then (sum(amt_new)/sum(payment_amt))else 0 end ) as  txn_m3_new_pct
,(case when sum(payment_amt) >0 then (sum(amt_supr)/sum(payment_amt))else 0 end ) as  txn_m3_supr_pct
from
(select 
txn.cut_off as cut_off
,txn.buyer_id as buyer_id
,txn.payment_amt as payment_amt
,(case when item_category_name like '01%' then payment_amt end ) as  amt_1
,(case when item_category_name like '02%' then payment_amt end ) as  amt_2
,(case when item_category_name like '03%' then payment_amt end ) as  amt_3
,(case when item_category_name like '04%' then payment_amt end ) as  amt_4
,(case when item_category_name like '05%' then payment_amt end ) as  amt_5
,(case when item_category_name like '06%' then payment_amt end ) as  amt_6
,(case when item_category_name like '07%' then payment_amt end ) as  amt_7
,(case when item_category_name like '08%' then payment_amt end ) as  amt_8
,(case when item_category_name like '09%' then payment_amt end ) as  amt_9
,(case when item_category_name like '10%' then payment_amt end ) as  amt_10
,(case when item_category_name like '11%' then payment_amt end ) as  amt_11
--,(case when item_category_name like '12%' then payment_amt end ) as  amt_12
--,(case when item_category_name like '13%' then payment_amt end ) as  amt_13
,(case when item_category_name like '14%' then payment_amt end ) as  amt_14
--,(case when item_category_name like '15%' then payment_amt end ) as  amt_15
,(case when item_category_name like '16%' then payment_amt end ) as  amt_16
,(case when item_category_name like '17%' then payment_amt end ) as  amt_17
,(case when source_type in ('O2O_B2C','O2O_DFS') then payment_amt end ) as  amt_on
,(case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') then payment_amt end ) as  amt_off
,(case when country_of_origin = 'CN' then payment_amt end ) as  amt_cn
,(case when country_of_origin <> 'CN' then payment_amt end ) as  amt_int
,(case when pl_flag = 'Y' then payment_amt end ) as  amt_pb
,(case when pl_flag <> 'Y' then payment_amt end ) as  amt_mmb
,(case when is_super_saver =1 then payment_amt end ) as  amt_supr
,(case when toDate(txn.payment_date) < date_add(DAY,7,os.on_sale_date) then payment_amt end ) as  amt_new
from model.m_dm_txn_90d txn
inner join (select md_code, country_of_origin,pl_flag from datamart.on_sale_product_base
group by md_code,country_of_origin,pl_flag) as pd 
on txn.item_code = pd.md_code
inner join model.m3_prod_os_lk os on txn.item_code = os.item_code) as m
group by m.cut_off, m.buyer_id) as m2
group by cut_off;


DROP TABLE if exists model.m3_pref_base_lk2 no delay;
CREATE TABLE model.m3_pref_base_lk2
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m3_pref_base_lk2',
 '{replica}')
ORDER BY cut_off AS
select cut_off 
,ifNull(round((sum(txn_m3_pmt_pct)/count(distinct buyer_id)),4),-1) as txn_m3_pmt_pct_avg
,ifNull(round((sum(txn_m3_cp_pct)/count(distinct buyer_id)),4),-1) as txn_m3_cp_pct_avg
from 
(select 
cut_off
,buyer_id
,(case when sum(payment_amt) >0 then (sum(amt_pmt)/sum(payment_amt)) else 0 end ) as  txn_m3_pmt_pct
,(case when sum(payment_amt) >0 then (sum(amt_cp)/sum(payment_amt)) else 0 end ) as  txn_m3_cp_pct
from
(select txn.cut_off as cut_off
,buyer_id
,payment_amt
,(case when p.order_code is not null then promotion_amt end ) as  amt_pmt
,(case when c.order_code is not null then coupon_amt end ) as  amt_cp
from model.m_dm_txn_90d txn
ASOF left join (select a.* from raw_data.mlp_oms_so_promotion_item a
inner join raw_data.dim_promotion_df pro on a.promotion_id = pro.pk_promotion_id where pro.prom_type in (1,2,3,4,9)) as p --单一促销，满额促销，满量促销，赠送，包邮促销
on txn.order_code = p.order_code and product_id = toString(p.mp_id)
and p.create_time <= txn.cut_off and is_super_saver =0 -- other promotion
ASOF left join raw_data.mlp_oms_so_coupon_item c on txn.order_code = c.order_code and txn.product_id = toString(c.mp_id) 
and c.create_time <= txn.cut_off
)m
group by cut_off, buyer_id) as m1
group by cut_off;

--select * from model.m3_pref_base_lk1;

DROP TABLE if exists model.m3_txn_category_pref no delay;
CREATE TABLE model.m3_txn_category_pref
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m3_txn_category_pref',
 '{replica}')
ORDER BY cut_off AS
select 
cust.cut_off as cut_off
,cust.buyer_id as buyer_id
,round((a.txn_m3_01_pct / m.txn_m3_01_pct_avg),2) as txn_m3_01_pref
,round((a.txn_m3_02_pct / m.txn_m3_02_pct_avg),2) as txn_m3_02_pref 
,round((a.txn_m3_03_pct / m.txn_m3_03_pct_avg),2) as txn_m3_03_pref
,round((a.txn_m3_04_pct / m.txn_m3_04_pct_avg),2) as txn_m3_04_pref 
,round((a.txn_m3_05_pct / m.txn_m3_05_pct_avg),2) as txn_m3_05_pref
,round((a.txn_m3_06_pct / m.txn_m3_06_pct_avg),2) as txn_m3_06_pref
,round((a.txn_m3_07_pct / m.txn_m3_07_pct_avg),2) as txn_m3_07_pref
,round((a.txn_m3_08_pct / m.txn_m3_08_pct_avg),2) as txn_m3_08_pref
,round((a.txn_m3_09_pct / m.txn_m3_09_pct_avg),2) as txn_m3_09_pref
,round((a.txn_m3_10_pct / m.txn_m3_10_pct_avg),2) as txn_m3_10_pref
,round((a.txn_m3_11_pct / m.txn_m3_11_pct_avg),2) as txn_m3_11_pref
,round((a.txn_m3_14_pct / m.txn_m3_14_pct_avg),2) as txn_m3_14_pref
,round((a.txn_m3_16_pct / m.txn_m3_16_pct_avg),2) as txn_m3_16_pref
,(case when txn_m3_17_pct_avg >0 then round((a.txn_m3_17_pct / m.txn_m3_17_pct_avg),2) else 0 end ) as  txn_m3_17_pref
,round((c.txn_m3_cn_pct / m.txn_m3_cn_pct_avg),2) as txn_m3_cn_pref 
,round((c.txn_m3_int_pct / m.txn_m3_int_pct_avg),2) as txn_m3_int_pref 
,round((c.txn_m3_mmb_pct / m.txn_m3_mmb_pct_avg),2) as txn_m3_mmb_pref 
,round((c.txn_m3_pb_pct / m.txn_m3_pb_pct_avg),2) as txn_m3_pb_pref
,round((b.txn_m3_off_pct / m.txn_m3_off_pct_avg),2) as txn_m3_off_pref
,round((b.txn_m3_on_pct / m.txn_m3_on_pct_avg),2)  as txn_m3_on_pref
,round((d.txn_m3_supr_pct / m.txn_m3_supr_pct_avg),2) as txn_m3_supr_pref
,round((d.txn_m3_new_pct / m.txn_m3_new_pct_avg),2)  as txn_m3_new_pref
,round((d.txn_m3_pmt_pct / s.txn_m3_pmt_pct_avg),2)  as txn_m3_pmt_pref
,round((d.txn_m3_cp_pct / s.txn_m3_cp_pct_avg),2) as txn_m3_cp_pref
from model.m_ouser_all cust
left join model.m3_txn_vrt_rfm a on cust.cut_off = a.cut_off and cust.buyer_id = a.buyer_id 
left join model.m3_txn_type_rfm b on cust.cut_off = b.cut_off and cust.buyer_id = b.buyer_id 
left join model.m3_txn_prod_rfm c on cust.cut_off = c.cut_off and cust.buyer_id = c.buyer_id 
left join model.m3_txn_pmt_cp_rfm d on cust.cut_off = d.cut_off and cust.buyer_id = d.buyer_id 
left join model.m3_pref_base_lk1 m on cust.cut_off = m.cut_off
left join model.m3_pref_base_lk2 s on cust.cut_off = s.cut_off;


DROP TABLE if exists model.m3_txn_category_final no delay;
CREATE TABLE model.m3_txn_category_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m3_txn_category_final',
 '{replica}')
ORDER BY cut_off AS
select 
cust.cut_off as cut_off
,cust.buyer_id as buyer_id
,txn_m3_vtc_d
,txn_m3_01_m_ch
,txn_m3_01_d
,txn_m3_01_f
,txn_m3_01_f_ch
,txn_m3_01_m
,txn_m3_01_pc
,txn_m3_01_pct
,txn_m3_01_r
,txn_m3_01_pref
,txn_m3_02_m_ch
,txn_m3_02_d
,txn_m3_02_f
,txn_m3_02_f_ch
,txn_m3_02_m
,txn_m3_02_pc
,txn_m3_02_pct
,txn_m3_02_r
,txn_m3_02_pref
,txn_m3_03_m_ch
,txn_m3_03_d
,txn_m3_03_f
,txn_m3_03_f_ch
,txn_m3_03_m
,txn_m3_03_pc
,txn_m3_03_pct
,txn_m3_03_r
,txn_m3_03_pref
,txn_m3_04_m_ch
,txn_m3_04_d
,txn_m3_04_f
,txn_m3_04_f_ch
,txn_m3_04_m
,txn_m3_04_pc
,txn_m3_04_pct
,txn_m3_04_r
,txn_m3_04_pref
,txn_m3_05_m_ch
,txn_m3_05_d
,txn_m3_05_f
,txn_m3_05_f_ch
,txn_m3_05_m
,txn_m3_05_pc
,txn_m3_05_pct
,txn_m3_05_r
,txn_m3_05_pref
,txn_m3_06_m_ch
,txn_m3_06_d
,txn_m3_06_f
,txn_m3_06_f_ch
,txn_m3_06_m
,txn_m3_06_pc
,txn_m3_06_pct
,txn_m3_06_r
,txn_m3_06_pref
,txn_m3_07_m_ch
,txn_m3_07_d
,txn_m3_07_f
,txn_m3_07_f_ch
,txn_m3_07_m
,txn_m3_07_pc
,txn_m3_07_pct
,txn_m3_07_r
,txn_m3_07_pref
,txn_m3_08_m_ch
,txn_m3_08_d
,txn_m3_08_f
,txn_m3_08_f_ch
,txn_m3_08_m
,txn_m3_08_pc
,txn_m3_08_pct
,txn_m3_08_r
,txn_m3_08_pref
,txn_m3_09_m_ch
,txn_m3_09_d
,txn_m3_09_f
,txn_m3_09_f_ch
,txn_m3_09_m
,txn_m3_09_pc
,txn_m3_09_pct
,txn_m3_09_r
,txn_m3_09_pref
,txn_m3_10_m_ch
,txn_m3_10_d
,txn_m3_10_f
,txn_m3_10_f_ch
,txn_m3_10_m
,txn_m3_10_pc
,txn_m3_10_pct
,txn_m3_10_r
,txn_m3_10_pref
,txn_m3_11_m_ch
,txn_m3_11_d
,txn_m3_11_f
,txn_m3_11_f_ch
,txn_m3_11_m
,txn_m3_11_pc
,txn_m3_11_pct
,txn_m3_11_r
,txn_m3_11_pref
,txn_m3_14_m_ch
,txn_m3_14_d
,txn_m3_14_f
,txn_m3_14_f_ch
,txn_m3_14_m
,txn_m3_14_pc
,txn_m3_14_pct
,txn_m3_14_r
,txn_m3_14_pref
,txn_m3_16_m_ch
,txn_m3_16_d
,txn_m3_16_f
,txn_m3_16_f_ch
,txn_m3_16_m
,txn_m3_16_pc
,txn_m3_16_pct
,txn_m3_16_r
,txn_m3_16_pref
,txn_m3_17_m_ch
,txn_m3_17_d
,txn_m3_17_f
,txn_m3_17_f_ch
,txn_m3_17_m
,txn_m3_17_pc
,txn_m3_17_pct
,txn_m3_17_r
,txn_m3_17_pref
,txn_m3_cntry_d
,txn_m3_cn_m_ch
,txn_m3_cn_f
,txn_m3_cn_f_ch
,txn_m3_cn_m
,txn_m3_cn_pc
,txn_m3_cn_pct
,txn_m3_cn_r
,txn_m3_cn_pref
,txn_m3_int_m_ch
,txn_m3_int_f
,txn_m3_int_f_ch
,txn_m3_int_m
,txn_m3_int_pc
,txn_m3_int_pct
,txn_m3_int_r
,txn_m3_int_pref
,txn_m3_brd_d
,txn_m3_mmb_m_ch
,txn_m3_mmb_f
,txn_m3_mmb_f_ch
,txn_m3_mmb_m
,txn_m3_mmb_pc
,txn_m3_mmb_pct
,txn_m3_mmb_r
,txn_m3_mmb_pref
,txn_m3_pb_m_ch
,txn_m3_pb_f
,txn_m3_pb_f_ch
,txn_m3_pb_m
,txn_m3_pb_pc
,txn_m3_pb_pct
,txn_m3_pb_r
,txn_m3_pb_pref
,txn_m3_type_d
,txn_m3_off_m_ch
,txn_m3_off_f
,txn_m3_off_f_ch
,txn_m3_off_m
,txn_m3_off_pc
,txn_m3_off_pct
,txn_m3_off_r
,txn_m3_off_pref
,txn_m3_on_m_ch
,txn_m3_on_f
,txn_m3_on_f_ch
,txn_m3_on_m
,txn_m3_on_pc
,txn_m3_on_pct
,txn_m3_on_r
,txn_m3_on_pref
,txn_m3_supr_f
,txn_m3_supr_m
,txn_m3_supr_pc
,txn_m3_supr_pct
,txn_m3_supr_r
,txn_m3_supr_pref
,txn_m3_new_f
,txn_m3_new_m
,txn_m3_new_pc
,txn_m3_new_pct
,txn_m3_new_r
,txn_m3_new_pref
,txn_m3_pmt_f
,txn_m3_pmt_m
,txn_m3_pmt_pc
,txn_m3_pmt_pct
,txn_m3_pmt_r
,txn_m3_pmt_pref
,txn_m3_cp_f
,txn_m3_cp_m
,txn_m3_cp_pc
,txn_m3_cp_r
,txn_m3_cp_pct
,txn_m3_cp_pref
from model.m_ouser_all cust
left join model.m3_txn_vrt_rfm a on cust.cut_off = a.cut_off and cust.buyer_id = a.buyer_id 
left join model.m3_txn_type_rfm b on cust.cut_off = b.cut_off and cust.buyer_id = b.buyer_id 
left join model.m3_txn_prod_rfm c on cust.cut_off = c.cut_off and cust.buyer_id = c.buyer_id 
left join model.m3_txn_pmt_cp_rfm d on cust.cut_off = d.cut_off and cust.buyer_id = d.buyer_id 
left join model.m3_txn_category_pref f on cust.cut_off = f.cut_off and cust.buyer_id = f.buyer_id;