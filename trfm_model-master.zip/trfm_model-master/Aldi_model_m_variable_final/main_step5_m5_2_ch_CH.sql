--subscription message RFM

DROP TABLE if exists model.m5_ch_subsp_rf no delay;
CREATE TABLE model.m5_ch_subsp_rf
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m5_ch_subsp_rf',
 '{replica}')
ORDER BY tuple() AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select 
assumeNotNull(cod) as cut_off
,user_id as buyer_id
,count(id) as ch_m5_subsp_f
,dateDiff(day,max(create_time),cod) as ch_m5_subsp_r
from raw_data.mlp_ad_aldi_subscription_message_log
where create_time >= date_add(day,-90,cod)
and toDate(create_time) <= cod
and send_status = 0 -- send successfully
--and content like '%thing6%' -- campaign related
group by user_id;

--contact response rate
-- will correct raw_data.mlp_ouser_u_user b.username to b.mobile after data is ready
DROP TABLE if exists model.m5_ch_sms_txn no delay;
CREATE TABLE model.m5_ch_sms_txn 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m5_ch_sms_txn',
 '{replica}')
ORDER BY cut_off AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select cut_off,buyer_id
,round(cast(count(distinct order_code) as float)/ cast(count(buyer_id) as float),2) as ch_m5_sms_txn
from (
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select
assumeNotNull(cod) as cut_off
,b.id as buyer_id
,txn.order_code as order_code
from datamart.tms_sms_header_ID  a
inner join datamart.u_user_2 c on  a.mobile_number = c.mobile
inner join raw_data.mlp_ouser_u_user b on b.id = c.id
ASOF left join
(select cut_off, buyer_id, order_code, payment_date from model.m_dm_txn_90d) txn
on b.id = txn.buyer_id
and txn.payment_date > assumeNotNull(a.sent_time)
--and payment_date <= date_add(day ,7 ,assumeNotNull(sent_time))
where (assumeNotNull(sent_time) >= date_add(day ,-90 ,cod)
and assumeNotNull(sent_time) <= cod
and create_time >= date_add(day,-90,cod)
and create_time <= cod
and c.mobile <> '\N' )
union distinct
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select
assumeNotNull(cod) as cut_off
,b.id as buyer_id
,txn.order_code as order_code
from datamart.tms_sms_header_ID  a
inner join datamart.u_user_2 c on  a.mobile_number = c.mobile
inner join raw_data.mlp_ouser_u_user b on b.id = c.id
ASOF left join
(select cut_off, buyer_id, order_code, payment_date from model.m_dm_txn_90d) txn
on b.id = txn.buyer_id
--and txn.payment_date > assumeNotNull(a.sent_time)
and payment_date <= date_add(day ,7 ,assumeNotNull(sent_time))
where (assumeNotNull(sent_time) >= date_add(day ,-90 ,cod)
and assumeNotNull(sent_time) <= cod
and create_time >= date_add(day,-90,cod)
and create_time <= cod
and c.mobile <> '\N' )
)
group by buyer_id,cut_off;

--sms RFM
-- will correct raw_data.mlp_ouser_u_user b.username to b.mobile after data is ready
DROP TABLE if exists model.m5_ch_sms_rf no delay;
CREATE TABLE model.m5_ch_sms_rf
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m5_ch_sms_rf',
 '{replica}')
ORDER BY cut_off AS
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select 
assumeNotNull(cod) as cut_off
,b.id as buyer_id
,count(id) as ch_m5_sms_f
,dateDiff(day,max(sent_time),cod) as ch_m5_sms_r
from datamart.tms_sms_header_ID as a
inner join raw_data.mlp_ouser_u_user as b on a.mobile_number = b.username 
where (sent_time >= date_add(day,-90,cod)
and sent_time <= cod
and create_time >= date_add(day,-90,cod)
and create_time <= cod )
group by b.id;

