--========= Coupon Variable Part IV ==============

-- preference score (by frequency) 

---------------------------------------------------------------------------
-- 1. 每个 buyer_id 自己的 avg socre 
drop table if exists model.m6_freq_pct1 no delay;
CREATE TABLE model.m6_freq_pct1 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_freq_pct1',
 '{replica}')
ORDER BY tuple() AS 
select
	cut_off
	,buyer_id
	,case when sum(payment_amt) >0 then (round(cast(count(amt_on) as float) / count(payment_amt), 4)) else 0 end as txn_m6_on_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_off) as float) / count(payment_amt), 4)) else 0 end as txn_m6_off_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_cn) as float) / count(payment_amt), 4)) else 0 end as txn_m6_cn_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_int) as float) / count(payment_amt), 4)) else 0 end as txn_m6_int_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_pb) as float) / count(payment_amt), 4)) else 0 end as txn_m6_pb_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_mmb) as float) / count(payment_amt), 4)) else 0 end as txn_m6_mmb_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_new) as float) / count(payment_amt), 4)) else 0 end as txn_m6_new_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_supr) as float) / count(payment_amt), 4))else 0 end as txn_m6_supr_f_pct
	
from (
	select txn.cut_off as cut_off, txn.buyer_id as buyer_id 
	,txn.payment_amt as payment_amt
	,case when source_type in ('O2O_B2C','O2O_DFS', 'NDD') then payment_amt end as amt_on
	,case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') then payment_amt end as amt_off
	,case when country_of_origin = 'CN' then payment_amt end as amt_cn
	,case when country_of_origin <> 'CN' then payment_amt end as amt_int
	,case when pl_flag = 'Y' then payment_amt end as amt_pb
	,case when pl_flag <> 'Y' then payment_amt end as amt_mmb
	,case when is_super_saver =1 then payment_amt end as amt_supr
	,case when toDate(txn.payment_date) < date_add(day, 7, os.on_sale_date) then payment_amt end as amt_new
	from (
	select t.* 
	from model.m6_sale_product_90d t
	inner join model.m6_targt_cust c on t.buyer_id = c.buyer_id
	) txn
	inner join (select md_code, country_of_origin, pl_flag from datamart.on_sale_product_base
				group by md_code, country_of_origin, pl_flag) pd on txn.item_code = pd.md_code
	inner join model.m3_prod_os_lk os on txn.item_code = os.item_code
) m
group by cut_off, buyer_id;


---------------------------------------------------------------------------
-- 2. 大众的平均 avg socre 

drop table if exists model.m6_pref_avg1 no delay;
CREATE TABLE model.m6_pref_avg1 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_pref_avg1',
 '{replica}')
ORDER BY tuple() AS 
select cut_off
,ifNull(round((sum(txn_m6_on_f_pct) / count(distinct buyer_id)), 4), -1) txn_m6_on_pct_avg
,ifNull(round((sum(txn_m6_off_f_pct) / count(distinct buyer_id)), 4), -1) txn_m6_off_pct_avg
,ifNull(round((sum(txn_m6_cn_f_pct) / count(distinct buyer_id)), 4), -1) txn_m6_cn_pct_avg
,ifNull(round((sum(txn_m6_int_f_pct) / count(distinct buyer_id)), 4), -1) txn_m6_int_pct_avg
,ifNull(round((sum(txn_m6_pb_f_pct) / count(distinct buyer_id)) ,4) ,-1) txn_m6_pb_pct_avg
,ifNull(round((sum(txn_m6_mmb_f_pct) / count(distinct buyer_id)) ,4) ,-1) txn_m6_mmb_pct_avg
,ifNull(round((sum(txn_m6_new_f_pct) / count(distinct buyer_id)) ,4) ,-1) txn_m6_new_pct_avg
,ifNull(round((sum(txn_m6_supr_f_pct) / count(distinct buyer_id)) ,4) ,-1) txn_m6_supr_pct_avg

from (
	select
	cut_off
	,buyer_id
	,case when sum(payment_amt) >0 then (round(cast(count(amt_on) as float) / COUNT(payment_amt), 2)) else 0 end as txn_m6_on_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_off) as float) / count(payment_amt), 2)) else 0 end as txn_m6_off_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_cn) as float) / count(payment_amt), 2)) else 0 end as txn_m6_cn_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_int) as float) / count(payment_amt), 2)) else 0 end as txn_m6_int_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_pb) as float) / count(payment_amt), 2)) else 0 end as txn_m6_pb_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_mmb) as float) / count(payment_amt), 2)) else 0 end as txn_m6_mmb_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_new) as float) / count(payment_amt), 2))else 0 end as txn_m6_new_f_pct
	,case when sum(payment_amt) >0 then (round(cast(count(amt_supr) as float) / count(payment_amt), 2))else 0 end as txn_m6_supr_f_pct
	from (
		select txn.cut_off as cut_off, txn.buyer_id as buyer_id 
		,txn.payment_amt as payment_amt
		,case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') then payment_amt end as amt_on
		,case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') then payment_amt end as amt_off
		,case when country_of_origin = 'CN' then payment_amt end as amt_cn
		,case when country_of_origin <> 'CN' then payment_amt end as amt_int
		,case when pl_flag = 'Y' then payment_amt end as amt_pb
		,case when pl_flag <> 'Y' then payment_amt end as amt_mmb
		,case when is_super_saver =1 then payment_amt end as amt_supr
		,case when toDate(txn.payment_date) < date_add(day, 7, os.on_sale_date) then payment_amt end as amt_new
		from model.m6_sale_product_90d txn
		inner join (
					select md_code, country_of_origin, pl_flag 
					from datamart.on_sale_product_base
					group by md_code, country_of_origin, pl_flag
					) pd on txn.item_code = pd.md_code
		inner join model.m3_prod_os_lk os on txn.item_code = os.item_code
		inner join model.m6_targt_cust cust on cust.buyer_id = txn.buyer_id
		) m
		group by cut_off, buyer_id
) m2
group by cut_off;


--select * from model.m6_pref_avg1;

---------------------------------------------------------------------------
-- 3. frequency preference score = 每个 buyer_id avg socre/ base avg score

drop table if exists model.m6_txn_category_f_pref no delay;
CREATE TABLE model.m6_txn_category_f_pref 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_txn_category_f_pref',
 '{replica}')
ORDER BY tuple() AS 
select a.cut_off
, a.buyer_id 
, round((txn_m6_cn_f_pct / cast(txn_m6_cn_pct_avg as float)), 2) txn_m6_cn_f_pref 
, round((txn_m6_int_f_pct / cast(txn_m6_int_pct_avg as float)), 2) txn_m6_int_f_pref 
, round((txn_m6_mmb_f_pct / cast(txn_m6_mmb_pct_avg as float)), 2) txn_m6_mmb_f_pref 
, round((txn_m6_pb_f_pct / cast(txn_m6_pb_pct_avg as float)), 2) txn_m6_pb_f_pref
, round((txn_m6_off_f_pct / cast(txn_m6_off_pct_avg as float)), 2) txn_m6_off_f_pref
, round((txn_m6_on_f_pct / cast(txn_m6_on_pct_avg as float)), 2) txn_m6_on_f_pref
, round((txn_m6_supr_f_pct / cast(txn_m6_supr_pct_avg as float)), 2) txn_m6_supr_f_pref
, round((txn_m6_new_f_pct / cast(txn_m6_new_pct_avg as float)), 4) txn_m6_new_f_pref

from model.m6_freq_pct1 a 
left join model.m6_pref_avg1 c on a.cut_off = c.cut_off;