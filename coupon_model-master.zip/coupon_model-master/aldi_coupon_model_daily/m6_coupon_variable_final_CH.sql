--========= Coupon Variable Part V ==============

-- Select TRFM variables, and collect all the variables
-- 筛选 TRFM 所需字段，并把所有variables 保存到 model.m6_coupon_variable_final

---------------------------------------------------------------------------
-- 1. 筛选 TRFM variables
drop table if exists model.m6_trfm_variables no delay;
CREATE TABLE model.m6_trfm_variables 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_trfm_variables',
 '{replica}')
ORDER BY tuple() AS 
with (select cut_off FROM model.m_cut_off_lk) as cod
select 
	buyer_id, cut_off 
	, cust_m1_points_in_r
	, cust_m1_points_in_f
	, cust_m1_points_in_ch
	, cust_m1_points_out_r
	, cust_m1_points_out_f
	, cust_m1_points_out_ch
	, cust_m1_tenure
	, txn_m2_cust_pc
	, txn_m2_cust_r
	, txn_m2_cust_f
	, txn_m2_cust_m
	, txn_m2_cust_atv
	, txn_m2_type_main
	, txn_m2_type_d
	, txn_m3_cn_pref
	, txn_m3_int_pref
	, txn_m3_mmb_pref
	, txn_m3_pb_pref
	, txn_m3_type_d
	, txn_m3_off_pref
	, txn_m3_on_pref
	, txn_m3_new_pref
	, txn_m3_supr_pref
	, txn_m3_cn_f_ch 
	, txn_m3_int_f_ch 
	, txn_m3_pb_f_ch
	, txn_m3_mmb_f_ch 
	, txn_m3_off_f_ch 
	, txn_m3_on_f_ch 
	
from model.m_variable_final
where buyer_id in (
select buyer_id from model.m6_targt_cust);
--and cut_off = @cod
--  model: model.m_variable_final_history 
-- where cut_off = @cod 

---------------------------------------------------------------------------

----插入历史数据
insert into model.m_coupon_variable_final_history select  *  from model.m_coupon_variable_final;


-- 2. 所有variables 保存到 model.m6_coupon_variable_final

drop table if exists model.m_coupon_variable_final no delay;
CREATE TABLE model.m_coupon_variable_final 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_coupon_variable_final',
 '{replica}')
ORDER BY tuple() AS 
select t.buyer_id as buyer_id, t.cut_off as cut_off, t.txn_m4_cust_micro_seg as txn_m4_cust_micro_seg
, cust_m6_cp_bind_cnt
, cust_m6_cp_used_cnt
, cp_m6_camp_bind_cnt
, cp_m6_cate_bind_cnt
, cp_m6_recu_bind_cnt
, cp_m6_bene_bind_cnt
, cp_m6_points_bind_cnt
, cp_m6_camp_use_cnt
, cp_m6_cate_use_cnt
, cp_m6_recu_use_cnt
, cp_m6_bene_use_cnt
, cp_m6_points_use_cnt
, cust_m6_cp_pay_amt
, cust_m6_cp_discnt_amt
, cust_m6_cp_ttl_price
, cust_m6_cp_discnt_pct
, cust_m6_cp_use_r
, cust_m6_cp_use_pc
, cust_m6_txn_cp_pct
, cust_m6_cp_entry_low_cnt
, cust_m6_cp_entry_mid_cnt
, cust_m6_cp_entry_hi_cnt
, cust_m6_cp_value_low_cnt
, cust_m6_cp_value_mid_cnt
, cust_m6_cp_value_hi_cnt
, cust_m6_cp_diversity_cnt
, cust_m6_cp_f_ch
, cust_m6_act_cp_cnt
, cust_m6_pass_cp_cnt
, cp_m6_txn_camp_pct
, cp_m6_txn_cate_pct
, cp_m6_txn_recu_pct
, cp_m6_txn_bene_pct
, cp_m6_txn_points_pct
, cp_m6_camp_pay_amt
, cp_m6_cate_pay_amt
, cp_m6_recu_pay_amt
, cp_m6_bene_pay_amt
, cp_m6_points_pay_amt
, cp_m6_camp_payment_pct
, cp_m6_cate_payment_pct
, cp_m6_recu_payment_pct
, cp_m6_bene_payment_pct
, cp_m6_points_payment_pct
, cp_m6_online_bind_cnt
, cp_m6_offline_bind_cnt
, cp_m6_online_use_cnt
, cp_m6_offline_use_cnt
, cp_m6_txn_online_pct
, cp_m6_txn_offline_pct
, cp_m6_online_pay_amt
, cp_m6_offline_pay_amt
, cp_m6_online_payment_pct
, cp_m6_offline_payment_pct
, txn_m6_cn_f_pref
, txn_m6_int_f_pref
, txn_m6_mmb_f_pref
, txn_m6_pb_f_pref
, txn_m6_off_f_pref
, txn_m6_on_f_pref
, txn_m6_supr_f_pref
, txn_m6_new_f_pref
, cust_m1_points_in_r
, cust_m1_points_in_f
, cust_m1_points_in_ch
, cust_m1_points_out_r
, cust_m1_points_out_f
, cust_m1_points_out_ch
, cust_m1_tenure
, txn_m2_cust_pc
, txn_m2_cust_r
, txn_m2_cust_f
, txn_m2_cust_m
, txn_m2_cust_atv
, txn_m2_type_main
, txn_m2_type_d
, txn_m3_cn_pref
, txn_m3_int_pref
, txn_m3_mmb_pref
, txn_m3_pb_pref
, txn_m3_type_d
, txn_m3_off_pref
, txn_m3_on_pref
, txn_m3_new_pref
, txn_m3_supr_pref
, txn_m3_cn_f_ch 
, txn_m3_int_f_ch 
, txn_m3_pb_f_ch
, txn_m3_mmb_f_ch 
, txn_m3_off_f_ch 
, txn_m3_on_f_ch
,now() as create_date 

from model.m6_targt_cust t 
inner join model.m6_coupon_cnt a on a.buyer_id = t.buyer_id and a.cut_off = t.cut_off
inner join model.cust_m6_cp_1 b on a.buyer_id = b.buyer_id and a.cut_off = b.cut_off
inner join model.cust_m6_cp_2 c on b.buyer_id = c.buyer_id and b.cut_off = c.cut_off
inner join model.cust_m6_cp_level d on c.buyer_id = d.buyer_id and c.cut_off = d.cut_off
inner join model.m6_5types_coupon e on e.buyer_id = d.buyer_id and e.cut_off = d.cut_off
inner join model.m6_on_off_coupon f on e.buyer_id = f.buyer_id and e.cut_off = f.cut_off
inner join model.m6_txn_category_f_pref g on f.buyer_id = g.buyer_id and f.cut_off = g.cut_off
inner join model.m6_trfm_variables h on g.buyer_id = h.buyer_id and g.cut_off = h.cut_off;


--select * from model.m6_coupon_variable_final;


----更新状态表 

alter table model.job_running_monitor update end_time= now(),status='SUCCESS' where cut_off in (select max(cut_off) from model.m_cut_off_lk) and Job_name='coupon_variable_final_job' and status='RUNNING' and toDate(start_time) in (select max(cut_off)+1 from model.m_cut_off_lk) 
SETTINGS allow_nondeterministic_mutations=1;

