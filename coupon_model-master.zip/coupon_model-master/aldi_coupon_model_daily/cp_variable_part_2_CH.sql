--========= Coupon Variable Part III ==============

---------------------------------------------------------------------------
-- 1. 5 type coupons: Campaign / Category / Recurring / Benefit / Points Exchange
-- coupon use freq percentage / average payment / % of sum ttl payment
 
drop table if exists model.m6_5types_coupon no delay;
CREATE TABLE model.m6_5types_coupon 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_5types_coupon',
 '{replica}')
ORDER BY tuple() AS 
select --sum(camp_f), sum(cate_f), sum(recu_f), sum(bene_f), sum(points_f)
	t.buyer_id, t.cut_off
	, case when ttl_txn_cnt > 0 then round(cast(camp_f as float) / ttl_txn_cnt, 4) end as cp_m6_txn_camp_pct
	, case when ttl_txn_cnt > 0 then round(cast(cate_f as float) / ttl_txn_cnt, 4) end as cp_m6_txn_cate_pct
	, case when ttl_txn_cnt > 0 then round(cast(recu_f as float) / ttl_txn_cnt, 4) end as cp_m6_txn_recu_pct
	, case when ttl_txn_cnt > 0 then round(cast(bene_f as float) / ttl_txn_cnt, 4) end as cp_m6_txn_bene_pct
	, case when ttl_txn_cnt > 0 then round(cast(points_f as float) / ttl_txn_cnt, 4) end as cp_m6_txn_points_pct
	, toDecimal64(ifNull(camp_avg_m, 0),6) as cp_m6_camp_pay_amt
	, toDecimal64(ifNull(cate_avg_m, 0),6) as cp_m6_cate_pay_amt
	, toDecimal64(ifNull(recu_avg_m, 0),6) as cp_m6_recu_pay_amt
	, toDecimal64(ifNull(bene_avg_m, 0),6) as cp_m6_bene_pay_amt
	, toDecimal64(ifNull(points_avg_m, 0),6) as cp_m6_points_pay_amt
	, ifNull(round(cast(camp_m as Nullable(float)) / cast(sum_m as Nullable(float)), 4), 0) as cp_m6_camp_payment_pct
	, ifNull(round(cast(cate_m as Nullable(float)) / cast(sum_m as Nullable(float)), 4), 0) as cp_m6_cate_payment_pct
	, ifNull(round(cast(recu_m as Nullable(float)) / cast(sum_m as Nullable(float)), 4), 0) as cp_m6_recu_payment_pct
	, ifNull(round(cast(bene_m as Nullable(float)) / cast(sum_m as Nullable(float)), 4), 0) as cp_m6_bene_payment_pct
	, ifNull(round(cast(points_m as Nullable(float)) / cast(sum_m as Nullable(float)), 4), 0) as cp_m6_points_payment_pct
	
	from (
	select o.buyer_id, o.cut_off
		, count(DISTINCT case when payment_amt > 0 then Real_order_code end ) as ttl_txn_cnt
		, count(DISTINCT case when o.Segment = 'Campaign Coupon' and o.real_coupon_amt > 0 then Real_order_code end) as camp_f
		, count(DISTINCT case when o.Segment = 'Category Coupon' and o.real_coupon_amt > 0 then Real_order_code end) as cate_f
		, count(DISTINCT case when o.Segment = 'Recurring Coupon' and o.real_coupon_amt > 0 then Real_order_code end) as recu_f
		, count(DISTINCT case when o.Segment = 'Benefit Coupon' and o.real_coupon_amt > 0 then Real_order_code end) as bene_f
		, count(DISTINCT case when o.Segment = 'Points Exchange Coupon' and o.real_coupon_amt > 0 then Real_order_code end) as points_f
		, round(avg(case when o.Segment = 'Campaign Coupon' and o.real_coupon_amt > 0 then o.payment_amt end), 4) camp_avg_m
		, round(avg(case when o.Segment = 'Category Coupon' and o.real_coupon_amt > 0 then o.payment_amt end), 4) cate_avg_m
		, round(avg(case when o.Segment = 'Recurring Coupon' and o.real_coupon_amt > 0 then o.payment_amt end), 4) recu_avg_m
		, round(avg(case when o.Segment = 'Benefit Coupon' and o.real_coupon_amt > 0 then o.payment_amt end), 4) bene_avg_m
		, round(avg(case when o.Segment = 'Points Exchange Coupon' and o.real_coupon_amt > 0 then o.payment_amt end), 4) points_avg_m
		, round(sum(case when o.Segment = 'Campaign Coupon' and o.real_coupon_amt > 0 then o.payment_amt end), 4) camp_m
		, round(sum(case when o.Segment = 'Category Coupon' and o.real_coupon_amt > 0 then o.payment_amt end), 4) cate_m
		, round(sum(case when o.Segment = 'Recurring Coupon' and o.real_coupon_amt > 0 then o.payment_amt end), 4) recu_m
		, round(sum(case when o.Segment = 'Benefit Coupon' and o.real_coupon_amt > 0 then o.payment_amt end), 4) bene_m
		, round(sum(case when o.Segment = 'Points Exchange Coupon' and o.real_coupon_amt > 0 then o.payment_amt end), 4) points_m
		, round(sum(case when o.real_coupon_amt > 0 then o.payment_amt end), 4) as sum_m
	from model.m6_txn_90d_Coupon o	
	group by o.buyer_id , o.cut_off 
) t;
--select count(*) from model.m6_5types_coupon;
---------------------------------------------------------------------------
-- 2. online/offline coupon
-- cp used time / used percet / avg net sales / sum sales percent
drop table if exists model.m6_on_off_coupon no delay;
CREATE TABLE model.m6_on_off_coupon 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_on_off_coupon',
 '{replica}')
ORDER BY tuple() AS 
select 
	t.buyer_id, t.cut_off
	, online_bind_cnt as cp_m6_online_bind_cnt
	, offline_bind_cnt as cp_m6_offline_bind_cnt
	, online_used_cnt as cp_m6_online_use_cnt
	, offline_used_cnt as cp_m6_offline_use_cnt
	, case when ttl_txn_cnt > 0 then round(cast(online_used_cnt as float) / ttl_txn_cnt, 4) end as cp_m6_txn_online_pct
	, case when ttl_txn_cnt > 0 then round(cast(offline_used_cnt as float) / ttl_txn_cnt, 4) end as cp_m6_txn_offline_pct
	, toDecimal64(ifNull(on_avg_payment, 0),6) as cp_m6_online_pay_amt 
	, toDecimal64(ifNull(off_avg_payment, 0),6) AS cp_m6_offline_pay_amt
	, case when ttl_amt > 0 then ifNull(round(cast(t.on_sum_payment as Nullable(float)) / cast(t.ttl_amt as Nullable(float)), 4), 0) end as cp_m6_online_payment_pct
	, case when ttl_amt > 0 then ifNull(round(cast(t.off_sum_payment as Nullable(float)) / cast(t.ttl_amt as Nullable(float)), 4), 0) end as cp_m6_offline_payment_pct
	
from(
	select txn.buyer_id, txn.cut_off
		, ifNull(count(DISTINCT txn.Real_order_code), -1) as ttl_txn_cnt
		, count(case when source_type in ('O2O_DFS', 'O2O_B2C', 'NDD') then txn.bind_time end) as online_bind_cnt
		, count(case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') then txn.bind_time end) as offline_bind_cnt
		, count(DISTINCT case when source_type in ('O2O_DFS', 'O2O_B2C', 'NDD') and txn.real_coupon_amt <> 0 then txn.order_code end) as online_used_cnt
		, count(DISTINCT case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') and txn.real_coupon_amt <> 0 then txn.order_code end) as offline_used_cnt
		, round(avg(case when source_type in ('O2O_DFS', 'O2O_B2C', 'NDD') and txn.real_coupon_amt <> 0 then txn.payment_amt end), 4) on_avg_payment
		, round(sum(case when source_type in ('O2O_DFS', 'O2O_B2C', 'NDD') and txn.real_coupon_amt <> 0 then txn.payment_amt end), 4) on_sum_payment
		, round(avg(case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') and txn.real_coupon_amt <> 0 then txn.payment_amt end), 4) off_avg_payment
		, round(sum(case when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') and txn.real_coupon_amt <> 0 then txn.payment_amt end), 4) off_sum_payment
		, ifNull(round(sum(case when txn.real_coupon_amt <> 0 then txn.payment_amt end), 4), -1) as ttl_amt
	from model.m6_txn_90d_Coupon txn 
	group by txn.buyer_id , txn.cut_off
) t ;
