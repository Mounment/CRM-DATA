--========= Coupon Variable Part II ==============

---------------------------------------------------------------------------
-- 1. 统计所有优惠券的绑定和使用次数 bind_time / used_time 

drop table if exists model.m6_coupon_cnt no delay;
CREATE TABLE model.m6_coupon_cnt 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_coupon_cnt',
 '{replica}')
ORDER BY tuple() AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select cust.buyer_id as buyer_id, cust.cut_off as cut_off
	, count(bind_time) as cust_m6_cp_bind_cnt
	, count(used_time) as cust_m6_cp_used_cnt
	, count(case when Segment = 'Campaign Coupon' then bind_time end) as cp_m6_camp_bind_cnt
	, count(case when Segment = 'Category Coupon' then bind_time end) as cp_m6_cate_bind_cnt
	, count(case when Segment = 'Recurring Coupon' then bind_time end) as cp_m6_recu_bind_cnt
	, count(case when Segment = 'Benefit Coupon' then bind_time end) as cp_m6_bene_bind_cnt
	, count(case when Segment = 'Points Exchange Coupon' then bind_time end) as cp_m6_points_bind_cnt
	, count(case when Segment = 'Campaign Coupon' then used_time end ) as cp_m6_camp_use_cnt
	, count(case when Segment = 'Category Coupon' then used_time end) as cp_m6_cate_use_cnt
	, count(case when Segment = 'Recurring Coupon' then used_time end) as cp_m6_recu_use_cnt
	, count(case when Segment = 'Benefit Coupon' then used_time end) as cp_m6_bene_use_cnt
	, count(case when Segment = 'Points Exchange Coupon' then used_time end) as cp_m6_points_use_cnt
	
from raw_data.mlp_promotion_coupon c 
--inner join raw_data.mlp_ouser_u_user u on c.bind_tel = u.username --will correct to mobile 
inner join raw_data.mlp_ouser_u_user u on c.bind_tel = u.mobile
inner join model.m6_targt_cust cust on cust.buyer_id = u.id 
inner join model.m6_cp_theme ct on ct.id = c.coupon_theme_id 
where Segment in ('Campaign Coupon', 'Category Coupon', 'Recurring Coupon', 'Benefit Coupon', 'Points Exchange Coupon')
and bind_time >= date_add(day, -90, cut_off) and bind_time <= cut_off --'2021-06-01' 
group by cust.buyer_id, cust.cut_off;



---------------------------------------------------------------------------
--2. 刷新所有 coupon transaction: payment amt / ttl price / cp value / % of discount by coupon 
--begin
drop table if exists model.cust_m6_cp_1 no delay;
CREATE TABLE model.cust_m6_cp_1 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.cust_m6_cp_1',
 '{replica}')
ORDER BY tuple() AS 
select buyer_id, cut_off
	, ifNull(avg_payment, 0) as cust_m6_cp_pay_amt
	, ifNull(avg_cp_amt, 0) as cust_m6_cp_discnt_amt
	, ifNull(avg_ttl_price, 0) as cust_m6_cp_ttl_price
	, ifNull(round((avg_cp_amt / avg_ttl_price), 4), 0) as cust_m6_cp_discnt_pct
	
from ( 
select DISTINCT c.buyer_id as buyer_id, c.cut_off as cut_off
	, case when sum(real_coupon_amt) > 0 then round(avg(real_coupon_amt), 2) end as avg_cp_amt
	, case when sum(ttl_cp_used_cnt) > 1 and sum(real_coupon_amt) <> 0 then round(avg(payment_amt), 2) 
		   when sum(ttl_cp_used_cnt) = 1 then 99 end as avg_payment --> 实付金额, the avg payment amnt = 99 who only coupon ONCE 
	, case when sum(ttl_cp_used_cnt) > 1 and sum(real_coupon_amt) <> 0 then round(avg(total_price), 2) 
		   when sum(ttl_cp_used_cnt) = 1 then 99 end as avg_ttl_price --> 总金额,  the avg ttl price = 99 who only coupon ONCE 
from (
	select buyer_id
	, count(DISTINCT case when used_time is not null then Real_order_code end) as ttl_cp_used_cnt
	from model.m6_txn_90d_Coupon 
	group by buyer_id
) t 
inner join model.m6_txn_90d_Coupon c on t.buyer_id = c.buyer_id --where c.buyer_id = '1002120601000495'
group by c.buyer_id, c.cut_off
) tb ;

--select * from model.cust_m6_cp_1;

---------------------------------------------------------------------------
-- 3. coupon used recency / purchase cycel / coupon use freq percent 
--BEGIN
drop table if exists model.cust_m6_cp_2 no delay;
CREATE TABLE model.cust_m6_cp_2 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.cust_m6_cp_2',
 '{replica}')
ORDER BY tuple() AS 
select 
	t.buyer_id as buyer_id, t.cut_off as cut_off
	, case when ttl_cp_used_cnt > 0 then dateDiff(day, max_cp_used, cut_off) else 9999 end as cust_m6_cp_use_r
	, case when ttl_cp_used_cnt > 1 then dateDiff(day, min_cp_used, max_cp_used) / (ttl_cp_used_cnt - 1)
			when ttl_cp_used_cnt <= 1 then 9999 end as cust_m6_cp_use_pc
	, case when ttl_cp_used_cnt > 0 and ttl_txn_cnt > 0 then round((cast(ttl_cp_used_cnt as float) / ttl_txn_cnt), 2) else 0 end as cust_m6_txn_cp_pct
	
from (
	select buyer_id, cut_off
		, count(DISTINCT case when used_time is not null then Real_order_code end) as ttl_cp_used_cnt
		, case when sum(real_coupon_amt) <> 0 then max(used_time) end as max_cp_used
		, case when sum(real_coupon_amt) <> 0 then min(used_time) end as min_cp_used
		, count(DISTINCT case when payment_amt > 0 then Real_order_code end ) as ttl_txn_cnt
	from model.m6_txn_90d_Coupon 
	group by buyer_id, cut_off
) t;

--select * from model.cust_m6_cp_2 where buyer_id = '1001104101017396' ;

---------------------------------------------------------------------------
-- 4. 刷新5种类型coupon 低/中/高 门槛和 coupon value 


drop table if exists model.m6_cp_level_pre no delay;
CREATE TABLE model.m6_cp_level_pre 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_cp_level_pre',
 '{replica}')
ORDER BY tuple() AS 
with e as (select DISTINCT c.use_limit as use_lm
, cp.Segment
from raw_data.mlp_promotion_coupon_theme c
inner join model.m6_cp_theme cp on c.id = cp.id  
where Segment in ('Campaign Coupon', 'Category Coupon', 'Recurring Coupon', 'Benefit Coupon', 'Points Exchange Coupon')
group by Segment, c.use_limit 
),
c as (
select DISTINCT c.coupon_value as cp_val
, cp.Segment
from raw_data.mlp_promotion_coupon c
inner join model.m6_cp_theme cp on c.coupon_theme_id = cp.id  
where Segment in ('Campaign Coupon', 'Category Coupon', 'Recurring Coupon', 'Benefit Coupon', 'Points Exchange Coupon')
group by Segment, c.coupon_value 
)
select  DISTINCT e.Segment as Segment
, quantileExactHigh(0.33)(e.use_lm) OVER (PARTITION BY e.Segment) as entry_low_mid
, quantileExactHigh(0.67)(e.use_lm) OVER (PARTITION BY e.Segment) as entry_mid_hi
, quantileExactHigh(0.33)(c.cp_val) OVER (PARTITION BY c.Segment) as cp_low_mid
, quantileExactHigh(0.67)(c.cp_val) OVER (PARTITION BY c.Segment) as cp_mid_hi

from e inner join c on e.Segment = c.Segment;


---------------------------------------------------------------------------
-- 5. 5种类型coupon 低/中/高 门槛和coupon value的使用频率
-- 从 4 中选择刷新后的值

-- coupon_type EC.dbo.V_Coupon_Theme 
-- 				entry			cp_value
-- campg_cp 	40.9 / 159		19 / 45
-- cate_cp 		59 / 119		7 / 30
-- recur_cp 	139 / 249		25 / 40
-- bene_cp 		99 / 159		20 / 60
-- point_ex 	49 / 159		10 / 40

DROP table if exists model.cust_m6_cp_level no delay;
CREATE TABLE model.cust_m6_cp_level 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.cust_m6_cp_level',
 '{replica}')
ORDER BY tuple() AS 
select t.buyer_id, t.cut_off
	, entry_low_cnt as cust_m6_cp_entry_low_cnt
	, entry_mid_cnt as cust_m6_cp_entry_mid_cnt
	, entry_hi_cnt as cust_m6_cp_entry_hi_cnt
	, cp_low_cnt as cust_m6_cp_value_low_cnt
	, cp_mid_cnt as cust_m6_cp_value_mid_cnt
	, cp_hi_cnt as cust_m6_cp_value_hi_cnt
	, cp_diversity_cnt as cust_m6_cp_diversity_cnt
	, (count(distinct case when toDateTime(txn.payment_date) >= min_bind_time then Real_order_code end) - count(distinct case when toDateTime(txn.payment_date) < min_bind_time then Real_order_code end) )as cust_m6_cp_f_ch 
	, act_cp_cnt as cust_m6_act_cp_cnt
	, pass_cp_cnt as cust_m6_pass_cp_cnt 
	
from(
SELECT buyer_id, cut_off 
	, min(bind_time) as min_bind_time
	, count(DISTINCT case when real_coupon_amt <> 0 and Segment = 'Category Coupon' and use_limit <= entry_low_mid then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Campaign Coupon' and use_limit <= entry_low_mid then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Benefit Coupon' and use_limit <= entry_low_mid then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Recurring Coupon' and use_limit <= entry_low_mid then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Points Exchange Coupon' and use_limit <= entry_low_mid then Real_order_code 
	end) as entry_low_cnt 
	, count(DISTINCT case when real_coupon_amt <> 0 and Segment = 'Category Coupon' and use_limit > entry_low_mid and use_limit <= entry_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Campaign Coupon' and use_limit > entry_low_mid and use_limit <= entry_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Benefit Coupon' and use_limit > entry_low_mid and use_limit <= entry_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Recurring Coupon' and use_limit > entry_low_mid and use_limit <= entry_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Points Exchange Coupon' and use_limit > entry_low_mid and use_limit <= entry_mid_hi then Real_order_code 
	end) as entry_mid_cnt 
	, count(DISTINCT case when real_coupon_amt <> 0 and Segment = 'Category Coupon' and use_limit > entry_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Campaign Coupon' and use_limit > entry_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Benefit Coupon' and use_limit > entry_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Recurring Coupon' and use_limit > entry_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Points Exchange Coupon' and use_limit > entry_mid_hi then Real_order_code 
	end) as entry_hi_cnt 
	, count(DISTINCT case when real_coupon_amt <> 0 and Segment = 'Category Coupon' and coupon_value <= cp_low_mid then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Campaign Coupon' and coupon_value <= cp_low_mid then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Benefit Coupon' and coupon_value <= cp_low_mid then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Recurring Coupon' and coupon_value <= cp_low_mid then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Points Exchange Coupon' and coupon_value <= cp_low_mid then Real_order_code 
	end) as cp_low_cnt
	, count(DISTINCT case when real_coupon_amt <> 0 and Segment = 'Category Coupon' and coupon_value > cp_low_mid and coupon_value <= cp_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Campaign Coupon' and coupon_value > cp_low_mid and coupon_value <= cp_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Benefit Coupon' and coupon_value > cp_low_mid and coupon_value <= cp_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Recurring Coupon' and coupon_value > cp_low_mid and coupon_value <= cp_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Points Exchange Coupon' and coupon_value > cp_low_mid and coupon_value <= cp_mid_hi then Real_order_code 
	end) as cp_mid_cnt
	, count(DISTINCT case when real_coupon_amt <> 0 and Segment = 'Category Coupon' and coupon_value > cp_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Campaign Coupon' and coupon_value > cp_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Benefit Coupon' and coupon_value > cp_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Recurring Coupon' and coupon_value > cp_mid_hi then Real_order_code 
				when real_coupon_amt <> 0 and Segment = 'Points Exchange Coupon' and coupon_value > cp_mid_hi then Real_order_code 
	end) as cp_hi_cnt 
	, count(DISTINCT case when used_time is not null then Segment end ) as cp_diversity_cnt
	, count(DISTINCT case when bind_time is not null and availability = 1 then bind_time end ) as act_cp_cnt
	, count(DISTINCT case when bind_time is not null and availability = 2 then bind_time end ) as pass_cp_cnt
from model.m6_txn_90d_Coupon a left join model.m6_cp_level_pre b
on a.Segment = b.Segment
group by buyer_id, cut_off) t 
inner join model.m6_txn_90d_Coupon txn on t.buyer_id = txn.buyer_id 
group by t.buyer_id, t.cut_off
	, entry_low_cnt
	, entry_mid_cnt
	, entry_hi_cnt
	, cp_low_cnt
	, cp_mid_cnt
	, cp_hi_cnt
	, cp_diversity_cnt
	, act_cp_cnt
	, pass_cp_cnt;


