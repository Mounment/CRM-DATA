--insert running status:插入运行状态
INSERT INTO model.job_running_monitor(Job_name,cut_off,status,start_time,end_time) VALUES ('coupon_variable_final_job', today()-1,'RUNNING',now(), '');



--========= Coupon Variable Part I ==============

-- variable 中间表储存位置: model.m6 

---------------------------------------------------------------------------
-- Step 1. TRFM 模型跑完后，生成 8 个 customer groups，从 TRFM 模型里筛选 Activated / At Risk / Engaged / Core 作为目标客群
DROP TABLE if exists model.m6_targt_cust no delay;
CREATE TABLE model.m6_targt_cust 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_targt_cust',
 '{replica}')
ORDER BY cut_off AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
SELECT DISTINCT buyer_id
	, cut_off
	, txn_m4_cust_micro_seg 
	
from model.m_variable_final --variable需要的表：model.m_variable_final / 建模需要的表：model.m_variable_final_history
where txn_m4_cust_micro_seg in ('Activated', 'At Risk', 'Engaged', 'Core')
AND cut_off = cod;

---------------------------------------------------------------------------
-- Step 2. 更新 sales_order 表 (90天的transaction)
 
--declare cod date
--select cod = cut_off from model.m_cut_off_lk
--BEGIN 
DROP TABLE if exists model.m6_sale_order_90d no delay;
CREATE TABLE model.m6_sale_order_90d 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_sale_order_90d',
 '{replica}')
ORDER BY cut_off AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
SELECT assumeNotNull(cod) as cut_off 
	, pk_order_code as order_code
	, (CASE WHEN source_type = 'POS' THEN out_order_code ELSE pk_order_code END) AS Real_order_code
	, a.longitude as longitude
	, a.latitude as latitude
	, order_delivery_method_id
	, source_type
	, a.merchant_code as merchant_code
	, shop_name
	, order_date
	, toString(payment_date) AS payment_date --2021-01-01 01:11:11
	, payment_date AS payment_date1
	, date_add(day, -3, toDate(payment_date)) AS payment_date2
	, map_desc
	, payment_map_desc
	, (CASE WHEN a.buyer_id = '-1' THEN NULL ELSE a.buyer_id END) AS buyer_id
	, self_checkout
	, payment_amt
	, coupon_amt
	, promotion_amt
	, delivery_fee_amt
	, net_sales
	, total_price 
	, receiver_address
	, receiver_name
	, b.longitude AS Shop_Long
	, b.latitude AS Shop_lat
	
FROM raw_data.ec_sale_order a 
LEFT JOIN datamart.merchant b on a.merchant_code = b.merchant_code
WHERE source_type NOT IN ( 'JDDJ', 'LST1688', 'MTWM', 'MTSG', 'OMS') AND map_desc <> '已取消' 
AND shop_name <> '奥乐齐零售通店' AND payment_date <> '' AND toDate(payment_date) >= date_add(day, -90, cod) --'2019-06-01 00:00:00.000'
and toDate(payment_date) <= cod;

--SELECT * from model.m6_sale_order_90d where order_code = '210412308115836495';

---------------------------------------------------------------------------
--Step 3. 先删掉coupon theme表，然后更新

drop table if exists model.m6_cp_theme no delay;
CREATE TABLE model.m6_cp_theme 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_cp_theme',
 '{replica}')
ORDER BY tuple() AS 
--BEGIN 
WITH coupon_theme AS (
SELECT coupon_use_type
, id
, theme_title
, coupon_use_comment
FROM raw_data.mlp_promotion_coupon_theme
)
, cp_tb AS (
select coupon_use_type,
case when coupon_use_type = 1 then 'CRM-新人券' when coupon_use_type = 2 then 'CRM-积分兑换优惠券'
	when coupon_use_type = 3 then 'CRM-活动券' when coupon_use_type = 4 then 'CRM-日常权益券'
	when coupon_use_type = 5 then 'CRM-WOM' when coupon_use_type = 6 then 'Store Ops'
	when coupon_use_type = 7 then 'Customer Service'when coupon_use_type = 8 then 'EC coupon'
	when coupon_use_type = 9 then 'MKT' when coupon_use_type = 10 then 'B2B'
	when coupon_use_type = 11 then 'HR' when coupon_use_type = 12 then 'Others' else 'Others' 
	end as coupon_type
, case when id in (
'2105140001474735', '2105140001497134', '2105140001501338', '2105220001442361', '2105220001446273', '2105220001447980'
, '2104070001818840', '2104070001821838', '2104070001823442', '2104070001825101', '2104070001826593', '2104070001827495'
, '1021168100000282', '1021168100000321', '1017168100000567', '1021168100000360', '2103170001446541', '2103170001456383'
, '2103170001465924', '1021166900008357', '1017166900004193', '1017166900004217', '1017166900004283', '1017166900004172'
, '1021166900008406', '1017166900004233', '1017166900004257'
) then 'Recurring Coupon'
when coupon_use_type = 8 and theme_title like '%冰淇淋%' then 'Category Coupon'
when coupon_use_type = 8 and theme_title like '%奶%' then 'Category Coupon'
when coupon_use_type = 8 and theme_title like '%酒%' then 'Category Coupon'
when coupon_use_type = 8 and theme_title like '%轻食%' then 'Category Coupon'
when coupon_use_type = 8 and theme_title like '%品类%' then 'Category Coupon'
when coupon_use_type = 8 and theme_title like '%肉%' then 'Category Coupon'
when coupon_use_type = 8 and theme_title like '%谷悦%' then 'Category Coupon'
when coupon_use_type = 8 and theme_title like '%热狗%' then 'Category Coupon'
when coupon_use_type = 8 and theme_title like '%乳品%' then 'Category Coupon'
when coupon_use_type = 8 and theme_title like '%烘焙%' then 'Category Coupon'
when coupon_use_type = 8 and theme_title like '%指定商品%' then 'Category Coupon'
when (theme_title like '%测试%' or theme_title like '%test%') then 'Others'
when coupon_use_type = 1 then 'New member development'
when coupon_use_type = 2 then 'Points Exchange Coupon'
when coupon_use_type = 3 then 'Campaign Coupon'
when coupon_use_type = 4 then 'Benefit Coupon'
when coupon_use_type = 5 then 'WOM'
when coupon_use_type = 6 then 'Store Ops'
when coupon_use_type = 7 then 'Customer Service'
when coupon_use_type = 8 and coupon_use_comment like '%地推%' and theme_title like '%W%' then 'New member development'
when coupon_use_type = 8 and coupon_use_comment like '%拉新%' and theme_title like '%W%' then 'New member development'
when coupon_use_type = 8 and (coupon_use_comment like '%地推%' or coupon_use_comment like '%地推%') then 'New member conversion'
when coupon_use_type = 8 and coupon_use_comment like '%复购%' then 'Recurring Coupon'
when coupon_use_type = 9 and theme_title like '%拉新%' then 'New member conversion'
when coupon_use_type = 10 then 'B2B'
when coupon_use_type = 11 then 'HR'
when coupon_use_type = 12 and theme_title like '%指定%' then 'Customer Service'
when coupon_use_type = 12 then 'Others' else 'Campaign Coupon' 
end as Segment
, case when id in (
'2105140001474735', '2105140001497134', '2105140001501338', '2105220001442361', '2105220001446273', '2105220001447980'
, '2104070001818840', '2104070001821838', '2104070001823442', '2104070001825101', '2104070001826593', '2104070001827495'
, '1021168100000282', '1021168100000321', '1017168100000567', '1021168100000360', '2103170001446541', '2103170001456383'
, '2103170001465924', '1021166900008357', '1017166900004193', '1017166900004217', '1017166900004283', '1017166900004172'
, '1021166900008406', '1017166900004233', '1017166900004257'
) then 3
when coupon_use_type = 8 and theme_title like '%冰淇淋%' then 6
when coupon_use_type = 8 and theme_title like '%奶%' then 6
when coupon_use_type = 8 and theme_title like '%酒%' then 6
when coupon_use_type = 8 and theme_title like '%轻食%' then 6
when coupon_use_type = 8 and theme_title like '%品类%' then 6
when coupon_use_type = 8 and theme_title like '%肉%' then 6
when coupon_use_type = 8 and theme_title like '%谷悦%' then 6
when coupon_use_type = 8 and theme_title like '%热狗%' then 6
when coupon_use_type = 8 and theme_title like '%乳品%' then 6
when coupon_use_type = 8 and theme_title like '%烘焙%' then 6
when coupon_use_type = 8 and theme_title like '%指定商品%' then 6
when (theme_title like '%测试%' or theme_title like '%test%') then NULL
when coupon_use_type = 1 then 2
when coupon_use_type = 2 then 5
when coupon_use_type = 3 then 4
when coupon_use_type = 4 then NULL
when coupon_use_type = 5 then NULL
when coupon_use_type = 6 then NULL
when coupon_use_type = 7 then NULL
when coupon_use_type = 8 and coupon_use_comment like '%地推%' and theme_title like '%W%' then 2
when coupon_use_type = 8 and coupon_use_comment like '%拉新%' and theme_title like '%W%' then 2
when coupon_use_type = 8 and coupon_use_comment like '%地推%' or coupon_use_comment like '%地推%' then 1
when coupon_use_type = 8 and coupon_use_comment like '%复购%' then 3
when coupon_use_type = 9 and theme_title like '%拉新%' then 1
when coupon_use_type = 10 then NULL
when coupon_use_type = 11 then NULL
when coupon_use_type = 12 then NULL else 4 
end as analysis_type
, id, theme_title 
from coupon_theme --where coupon_use_type<>''
)
select *, 
case when Segment in ('Campaign Coupon', 'Category Coupon', 'Recurring Coupon', 'Benefit Coupon') then 2 
	when Segment = 'Points Exchange Coupon' then 1 end as availability
	
from cp_tb;

---------------------------------------------------------------------------
-- Step 4. Select all the traget customer and ALL transaction (includes coupon transaction) 
-- 更新 90天的 transaction, 增加了 coupon transaction / coupon type / 

--declare cod date
--select cod = cut_off from model.m_cut_off_lk;
drop table if exists model.m6_txn_90d_Coupon no delay;
CREATE TABLE model.m6_txn_90d_Coupon 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_txn_90d_Coupon',
 '{replica}')
ORDER BY tuple() AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod,
TargCust AS
(select *
from model.m6_targt_cust
)
, CouponTxn AS (
select case when t.Real_order_code is null then t.real_buyer_id else t.buyer_id end as buyer_id
	, order_date 
	, source_type
	, payment_date 
	, payment_amt 
	, coupon_amt 
	, real_coupon_amt
	, total_price
	, net_sales
	, promotion_amt
	, Real_order_code 
	, order_code 
	, coupon_theme_id
	, start_time 
	, end_time 
	, bind_time 
	, used_time 
	, coupon_value 
	, use_limit 
	, bind_tel 
	, Segment
	, availability
from (
select txn.*
, cp.*
, case when cp.order_code is null then 0 else cp.coupon_value end as real_coupon_amt
from (
select buyer_id
	, order_date 
	, source_type
	, payment_date1 as payment_date 
	, payment_amt 
	, coupon_amt 
	, total_price
	, net_sales
	, promotion_amt
	, Real_order_code 
	from model.m6_sale_order_90d o
	where payment_amt > 0 and net_sales > 0 
) txn
full OUTER join 
(
select u.id as real_buyer_id
	, order_code 
	, coupon_theme_id
	, start_time 
	, end_time 
	, bind_time 
	, used_time 
	, coupon_value 
	, use_limit 
	, bind_tel 
	, ct.Segment as Segment
	, ct.availability as availability
	from raw_data.mlp_promotion_coupon cp
	--inner join raw_data.mlp_ouser_u_user u on cp.bind_tel = u.username --will correct to mobile
        inner join raw_data.mlp_ouser_u_user u on cp.bind_tel = u.mobile
	inner join model.m6_cp_theme ct on cp.coupon_theme_id = ct.id
	where ct.Segment in ('Campaign Coupon', 'Category Coupon', 'Recurring Coupon', 'Benefit Coupon', 'Points Exchange Coupon')
	and cp.bind_time >= date_add(day, -90, cod) and cp.bind_time <= cod 
) cp on txn.Real_order_code = cp.order_code 
) t 
)
SELECT a.cut_off, a.txn_m4_cust_micro_seg, a.buyer_id as buyer_id, b.* except (buyer_id)
FROM TargCust a 
INNER JOIN CouponTxn b on a.buyer_id = b.buyer_id;

--select * from model.m6_txn_90d_Coupon where buyer_id = '1002120601000495';

---------------------------------------------------------------------------
-- Step 5. sale product table => same with TRFM sale_order_90day, used to the coupon model
--declare cod date
--set cod = (select cut_off from model.m_cut_off_lk)
--BEGIN
drop table if exists model.m6_sale_product_90d no delay;
CREATE TABLE model.m6_sale_product_90d 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m6_sale_product_90d',
 '{replica}')
ORDER BY tuple() AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select 
cod as cut_off
,order_code
,source_type
,merchant_code
,longitude
,latitude
,buyer_id
,payment_date
,product_id
,item_code
,item_category_name
,item_sub_category_name
,buy_qty
,payment_amt
,coupon_amt
,promotion_amt
,is_super_saver

from raw_data.ec_sale_order_product desp
where toDate(payment_date) >= date_add(day, -90, cod)
and toDate(payment_date) <= cod
and toString(buyer_id) <> ''
and order_code in (select pk_order_code 
from raw_data.ec_sale_order where toString(payment_date) <>'' and map_desc <>'已取消');
