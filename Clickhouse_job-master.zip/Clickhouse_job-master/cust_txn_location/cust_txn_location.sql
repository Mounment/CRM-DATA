DROP TABLE IF EXISTS business_domain.cust_txn_location no delay ;
CREATE TABLE business_domain.cust_txn_location
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/business_domain/business_domain.cust_txn_location',
 '{replica}')
ORDER BY tuple() AS 
WITH Merchant_Loc AS (
select SUBSTRING(org_code, 1, 4) as merchant_code
, longitude as shop_longitude 
, latitude as shop_latitude 
from raw_data.mlp_merchant_store_org_info
where SUBSTRING(org_code, 5, 8) = 'SO2O'
)
select a.pk_order_code as order_code 
, a.longitude as cust_long 
, a.latitude as cust_lat
, b.shop_longitude AS shop_longitude
, b.shop_latitude AS shop_latitude
, now() as refresh_date
from raw_data.ec_sale_order a
inner join Merchant_Loc b on a.merchant_code = b.merchant_code 
;