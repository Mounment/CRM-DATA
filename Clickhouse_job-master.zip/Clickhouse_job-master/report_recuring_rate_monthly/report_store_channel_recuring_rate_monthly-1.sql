/*
 * Date: 2021-12-31
 * 
 * Tables for power bi report
 * 
 * PART 1 - Recurring rate by store
 * 
 * PART 2 - Recurring rate by channel 
 */

--=========================== PART 1 ====================================

-- 1. sum of ttl customers by store
DROP TABLE IF EXISTS report.recu_cust_by_store_mth no delay ;
CREATE TABLE report.recu_cust_by_store_mth
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/report/report.recu_cust_by_store_mth', '{replica}')
ORDER BY tuple() AS
WITH RecuCust AS (
select Merchant_code 
, sum(case when Y2019_M06 is not null then Y2019_M06 end ) as YM_1906
, sum(case when Y2019_M07 is not null then Y2019_M07 end ) as YM_1907
, sum(case when Y2019_M08 is not null then Y2019_M08 end ) as YM_1908
, sum(case when Y2019_M09 is not null then Y2019_M09 end ) as YM_1909
, sum(case when Y2019_M10 is not null then Y2019_M10 end ) as YM_1910
, sum(case when Y2019_M11 is not null then Y2019_M11 end ) as YM_1911
, sum(case when Y2019_M12 is not null then Y2019_M12 end ) as YM_1912
, sum(case when Y2020_M01 is not null then Y2020_M01 end ) as YM_2001
, sum(case when Y2020_M02 is not null then Y2020_M02 end ) as YM_2002
, sum(case when Y2020_M03 is not null then Y2020_M03 end ) as YM_2003
, sum(case when Y2020_M04 is not null then Y2020_M04 end ) as YM_2004
, sum(case when Y2020_M05 is not null then Y2020_M05 end ) as YM_2005
, sum(case when Y2020_M06 is not null then Y2020_M06 end ) as YM_2006
, sum(case when Y2020_M07 is not null then Y2020_M07 end ) as YM_2007
, sum(case when Y2020_M08 is not null then Y2020_M08 end ) as YM_2008
, sum(case when Y2020_M09 is not null then Y2020_M09 end ) as YM_2009
, sum(case when Y2020_M10 is not null then Y2020_M10 end ) as YM_2010
, sum(case when Y2020_M11 is not null then Y2020_M11 end ) as YM_2011
, sum(case when Y2020_M12 is not null then Y2020_M12 end ) as YM_2012
, sum(case when Y2021_M01 is not null then Y2021_M01 end ) as YM_2101
, sum(case when Y2021_M02 is not null then Y2021_M02 end ) as YM_2102
, sum(case when Y2021_M03 is not null then Y2021_M03 end ) as YM_2103
, sum(case when Y2021_M04 is not null then Y2021_M04 end ) as YM_2104
, sum(case when Y2021_M05 is not null then Y2021_M05 end ) as YM_2105
, sum(case when Y2021_M06 is not null then Y2021_M06 end ) as YM_2106
, sum(case when Y2021_M07 is not null then Y2021_M07 end ) as YM_2107
, sum(case when Y2021_M08 is not null then Y2021_M08 end ) as YM_2108
, sum(case when Y2021_M09 is not null then Y2021_M09 end ) as YM_2109
, sum(case when Y2021_M10 is not null then Y2021_M10 end ) as YM_2110
, sum(case when Y2021_M11 is not null then Y2021_M11 end ) as YM_2111
, sum(case when Y2021_M12 is not null then Y2021_M12 end ) as YM_2112
, sum(case when Y2022_M01 is not null then Y2022_M01 end ) as YM_2201
, sum(case when Y2022_M02 is not null then Y2022_M02 end ) as YM_2202
, sum(case when Y2022_M03 is not null then Y2022_M03 end ) as YM_2203
, sum(case when Y2022_M04 is not null then Y2022_M04 end ) as YM_2204
, sum(case when Y2022_M05 is not null then Y2022_M05 end ) as YM_2205
, sum(case when Y2022_M06 is not null then Y2022_M06 end ) as YM_2206
, sum(case when Y2022_M07 is not null then Y2022_M07 end ) as YM_2207
, sum(case when Y2022_M08 is not null then Y2022_M08 end ) as YM_2208
, sum(case when Y2022_M09 is not null then Y2022_M09 end ) as YM_2209
, sum(case when Y2022_M10 is not null then Y2022_M10 end ) as YM_2210
, sum(case when Y2022_M11 is not null then Y2022_M11 end ) as YM_2211
, sum(case when Y2022_M12 is not null then Y2022_M12 end ) as YM_2212
, sum(case when Y2023_M01 is not null then Y2023_M01 end ) as YM_2301
from datamart.store_member_natural_mth_new 
--where Merchant_code = '1001'
group by Merchant_code 
)
select Merchant_code 
, recu_cust 
, yr  
, row_number() over(partition by Merchant_code order by yr ) as rk 
from RecuCust 
array join [
YM_1906, YM_1907, YM_1908, YM_1909, YM_1910, YM_1911, YM_1912 -- 2019
, YM_2001, YM_2002, YM_2003, YM_2004, YM_2005, YM_2006
, YM_2007, YM_2008, YM_2009, YM_2010, YM_2011, YM_2012 -- 2020
, YM_2101, YM_2102, YM_2103, YM_2104, YM_2105, YM_2106
, YM_2107, YM_2108, YM_2109, YM_2110, YM_2111, YM_2112 --2021
, YM_2201, YM_2202, YM_2203, YM_2204, YM_2205, YM_2206
, YM_2207, YM_2208, YM_2209, YM_2210, YM_2211, YM_2212 -- 2022
, YM_2301
] as recu_cust 
, splitByString(', '
, '201906, 201907, 201908, 201909, 201910, 201911, 201912
, 202001, 202002, 202003, 202004, 202005, 202006
, 202007, 202008, 202009, 202010, 202011, 202012 
, 202101, 202102, 202103, 202104, 202105, 202106
, 202107, 202108, 202109, 202110, 202111, 202112 
, 202201, 202202, 202203, 202204, 202205, 202206
, 202207, 202208, 202209, 202210, 202211, 202212 
, 202301'
) as yr 
order by Merchant_code, yr  
; --select * from  report.recu_cust_by_store_mth;



--=========================== PART 2.1 ====================================

-- 1. To identify the first year_month of each customer by channel (offline / online) 
DROP TABLE IF EXISTS report.cust_order_rank_channel no delay ;
CREATE TABLE report.cust_order_rank_channel
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/report/report.cust_order_rank_channel', '{replica}')
ORDER BY tuple() AS
SELECT *
, concat(toString(P_Year), toString(P_Mth)) as YM 
, row_number() over(partition by buyer_id, channel order by payment_date1 asc ) as rk 
FROM (select buyer_id 
, P_Year 
, P_month 
, formatDateTime(toDateTime(payment_date1), '%m') as P_Mth
, payment_date1 
, case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') then 'offline' else 'online' end as channel
from datamart.V_Orders_Count
where merchant_code <> '8888') t
;

-- 2. Total new member + recurring member cnt by channel
DROP TABLE IF EXISTS report.ttl_recu_cnt_channel no delay ;
CREATE TABLE report.ttl_recu_cnt_channel
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/report/report.ttl_recu_cnt_channel', '{replica}')
ORDER BY tuple() AS
WITH Recu_Nxt_Mth AS (
SELECT b.YM as YM
, b.channel as channel 
, count(DISTINCT case when b.YM > a.YM then b.buyer_id end ) as recu_member
from (select * from report.cust_order_rank_channel where rk = 1 ) a
left join report.cust_order_rank_channel b on a.buyer_id = b.buyer_id and a.channel = b.channel
group by b.YM, b.channel 
) 
, Recu_This_Mth AS (
select b.YM as YM
, a.channel as channel 
, count(DISTINCT a.buyer_id) as recu_this_mth 
from (select * from report.cust_order_rank_channel where rk = 1) a 
left join report.cust_order_rank_channel b on a.buyer_id = b.buyer_id and a.channel = b.channel
where b.rk > 1 and a.P_month = b.P_month and a.P_Year = b.P_Year 
group by b.YM, a.channel
) 
SELECT a.YM as YM
, a.channel as channel 
, count(DISTINCT case when rk = 1 then a.buyer_id end ) as new_member_cnt
, (recu_this_mth + recu_member) as recu_cnt 
--, recu_this_mt
-- , recu_member
FROM report.cust_order_rank_channel a 
inner join Recu_This_Mth b on a.YM = b.YM and a.channel = b.channel 
inner join Recu_Nxt_Mth c on a.YM = c.YM and a.channel = c.channel 
group by a.YM, a.channel, recu_this_mth, recu_member
order by a.YM 
;

-- 3. Monthly recurring rate by channel 
DROP TABLE IF EXISTS report.recu_rate_channel1 no delay ;
CREATE TABLE report.recu_rate_channel1
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/report/report.recu_rate_channel1', '{replica}')
ORDER BY tuple() AS
WITH Cum_Recu_Cnt AS (
select YM
, channel 
, new_member_cnt 
, sum(new_member_cnt) over(PARTITION by channel order by YM rows between unbounded preceding and current row) as ttl_cnt -- moving sum of new member
from report.ttl_recu_cnt_channel
group by channel, YM, new_member_cnt
)
select YM
, channel 
, round((recu_cnt / ttl_cnt), 4) as recurring_rate 
from Cum_Recu_Cnt a 
inner join report.ttl_recu_cnt_channel b on a.YM = b.YM and a.channel = b.channel 
;

--=========================== PART 2.2 ====================================

-- monthly recurring rate (overall)
-- 1. order rank 
DROP TABLE IF EXISTS report.cust_order_rank_overall no delay ;
CREATE TABLE report.cust_order_rank_overall
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/report/report.cust_order_rank_overall', '{replica}')
ORDER BY tuple() AS
SELECT *
, concat(toString(P_Year), toString(P_Mth)) as YM 
, row_number() over(partition by buyer_id order by payment_date1 asc ) as rk 
FROM (select buyer_id 
, P_Year 
, P_month 
, formatDateTime(toDateTime(payment_date1), '%m') as P_Mth
, payment_date1 
--, case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') then 'offline' else 'online' end as channel
from datamart.V_Orders_Count
where merchant_code <> '8888') t
;

DROP TABLE IF EXISTS report.ttl_recu_cnt no delay ;
CREATE TABLE report.ttl_recu_cnt
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/report/report.ttl_recu_cnt', '{replica}')
ORDER BY tuple() AS
WITH Recu_Nxt_Mth AS (
SELECT b.YM as YM
--, b.channel as channel 
, count(DISTINCT case when b.YM > a.YM then b.buyer_id end ) as recu_member
from (select * from report.cust_order_rank_overall where rk = 1) a 
left join report.cust_order_rank_overall b on a.buyer_id = b.buyer_id --and a.payment_date1 = b.payment_date1
group by b.YM --, b.channel 
) 
, Recu_This_Mth AS (
select b.YM as YM
--, a.channel as channel 
, count(DISTINCT a.buyer_id) as recu_this_mth 
from (select * from report.cust_order_rank_overall where rk = 1) a 
left join report.cust_order_rank_overall b on a.buyer_id = b.buyer_id --and a.payment_date1 = b.payment_date1
where b.rk > 1 and a.P_month = b.P_month and a.P_Year = b.P_Year 
group by b.YM --, a.channel
) 
SELECT a.YM as YM
, 'overall' as channel 
, count(DISTINCT case when rk = 1 then a.buyer_id end ) as new_member_cnt
, (recu_this_mth + recu_member) as recu_cnt 
--, recu_this_mt
-- , recu_member
FROM report.cust_order_rank_overall a 
inner join Recu_This_Mth b on a.YM = b.YM --and a.channel = b.channel 
inner join Recu_Nxt_Mth c on a.YM = c.YM --and a.channel = c.channel 
group by a.YM, channel, recu_this_mth, recu_member
order by a.YM 
;

-- 3. monthly recurring rate (overall)
DROP TABLE IF EXISTS report.recu_rate_channel2 no delay ;
CREATE TABLE report.recu_rate_channel2
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/report/report.recu_rate_channel2', '{replica}')
ORDER BY tuple() AS
WITH Cum_Recu_Cnt AS (
select YM
, channel 
, new_member_cnt 
, sum(new_member_cnt) over(partition by channel order by YM ASC rows between unbounded preceding and current row) as ttl_cnt
from report.ttl_recu_cnt
group by YM, channel, new_member_cnt
) 
select a.YM as YM
, channel 
, round((recu_cnt / ttl_cnt), 4) as recurring_rate 
from Cum_Recu_Cnt a 
inner join report.ttl_recu_cnt b on a.YM = b.YM
;


