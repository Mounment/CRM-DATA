--#t3(part2)
--member_type: non_diamond: new non-diamond customers
--Tuesday/ Friday
insert into datamart.T_F_MemberTag
select 
toInt64(a.id) as Buyer_id
,'Member Type' as TagKey
,'non-diamond' as TagValue -- new non-diamond customers of current month
,toString(toStartOfMonth(addMonths(now(),0))) as BeginDate -- first day of data load month
,toString(toStartOfMonth(addMonths(now(),1))-1) as EndDate -- the last day of load month
,toDateTime(now()) as insert_time
from raw_data.mlp_ouser_u_user a
left join raw_data.mlp_ouser_aldi_member_benefit b on a.id = b.user_id 
and b.valid_month = toString(toYYYYMM(date_add(month,-1,now()))) 
and b.level_code = toString('1001')   -- those 4 customers don't exist in u_user table
where a.create_time >= toDate(toStartOfMonth(addMonths(now(),0)))-- 本月注册的客户
and a.create_time < today()
and toString(a.id) not in 
(select datamart.T_F_MemberTag.Buyer_id from datamart.T_F_MemberTag 
where datamart.T_F_MemberTag.TagKey =toString('Member Type') 
and datamart.T_F_MemberTag.TagValue = toString('non-diamond')
and BeginDate = toDate(toStartOfMonth(addMonths(now(),0)))) -- exclude the new customers who have already been tagged as non-diamond
and b.user_id is null;
