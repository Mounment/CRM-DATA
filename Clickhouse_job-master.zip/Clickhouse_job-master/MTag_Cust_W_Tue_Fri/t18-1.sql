---Tuesday/Friday  Weekly refresh  8:00 
--MTD Benefits
insert into datamart.T_F_MemberTag
select user_id as Buyer_id
,'MTD Benefits' as TagKey
,balence as TagValue
,toDate(toStartOfMonth(addMonths(now(),0))) as BeginDate
,toString(toDate(now())) as  EndDate -- the last day of load month
,toDateTime(now()) as insert_time
from raw_data.mlp_ouser_aldi_member_benefit 
where valid_month = toString(toYYYYMM(now()));
