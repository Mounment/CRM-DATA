--SKU history/new
--insert new orders
insert into datamart.order_sku 
with tmp1 as --last order
(select c.buyer_id as buyer_id, c.order_code as order_code, count(distinct c.item_code) as sku_last_order
from
(select a.buyer_id, a.order_code, item_code, ROW_NUMBER
from datamart.V_Order_Detail as a inner join datamart.V_Orders_Count as b
on a.order_code = b.pk_order_code
where a.buyer_id is not NULL
and toDate(b.payment_date1) = toDate(date_add(day, -1, now()))) c
inner join
(select a.buyer_id, a.order_code, item_code, ROW_NUMBER
from datamart.V_Order_Detail a inner join datamart.V_Orders_Count b
on a.order_code = b.pk_order_code
where a.buyer_id is not NULL) d
on c.buyer_id = d.buyer_id
and toInt64(d.ROW_NUMBER) = c.ROW_NUMBER-1
and c.item_code = d.item_code
group by c.buyer_id, c.order_code),
tmp2 as --history order
(select c.buyer_id, c.order_code, count(distinct c.item_code) as sku_history_orders
from
(select a.buyer_id, a.order_code, item_code, ROW_NUMBER
from datamart.V_Order_Detail a inner join datamart.V_Orders_Count b
on a.order_code = b.pk_order_code
where a.buyer_id is not NULL
and toDate(b.payment_date1) = toDate(dateadd(day, -1, now()))) c
asof inner join
(select a.buyer_id, a.order_code, item_code, ROW_NUMBER
from datamart.V_Order_Detail a inner join datamart.V_Orders_Count b
on a.order_code = b.pk_order_code
where a.buyer_id is not NULL) d
on c.buyer_id = d.buyer_id
and d.ROW_NUMBER < c.ROW_NUMBER
and c.item_code = d.item_code
group by c.buyer_id, c.order_code),
tmp3 as --this order total
(select buyer_id, order_code, payment_date1, count(item_code) as sku_total
from datamart.V_Order_Detail
where buyer_id is not null
and toDate(payment_date1) = toDate(dateadd(day, -1, now()))
group by buyer_id, order_code, payment_date1)
select tmp3.buyer_id, tmp3.order_code, sku_total, ifNull(sku_last_order,0) as sku_last_order, ifNull(sku_history_orders,0) as sku_history_orders, (sku_total-ifNull(sku_history_orders,0)) as sku_new,
payment_date1 as payment_date
,toDateTime(now()) as insert_time
from tmp3 left join tmp1
on tmp3.order_code = tmp1.order_code
left join tmp2
on tmp3.order_code = tmp2.order_code


