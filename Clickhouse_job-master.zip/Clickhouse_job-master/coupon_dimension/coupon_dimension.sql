insert into datamart.coupon_dimension
with cp_txn as
(select buyer_id, a.pk_order_code, a.payment_date
from datamart.V_Order_Header a 
inner join raw_data.mlp_promotion_coupon b
on a.Real_order_code = b.order_code
where toDateTime(payment_date) >= date_add(day,-90,today())
and toDateTime(payment_date) < date_add(day,-30,today()))  -- coupon transactions
,buyer_txn as 
(select a.buyer_id
,count(distinct a.Real_order_code) ttl_trans
,count(distinct case when b.order_code is not null then b.order_code end)ttl_c_trans 
,count(distinct case when b.order_code is not null then a.pk_order_code end)*1.0/count(distinct a.Real_order_code)x_cp
,count(distinct case when toDateTime(payment_date) >= date_add(day,-90,today()) and toDateTime(payment_date) < date_add(day,-30,today()) then a.Real_order_code end)period_trans
,count(distinct case when toDateTime(payment_date) >= date_add(day,-90,today()) and toDateTime(payment_date) < date_add(day,-30,today()) and b.order_code is not null then a.Real_order_code end) period_c_trans
from datamart.V_Order_Header a 
left join raw_data.mlp_promotion_coupon b
on a.Real_order_code = b.order_code
group by a.buyer_id) -- txn count on a customer level
,crvt_amt as 
(select
a.buyer_id
,a.payment_date --1001125701005266
,case when p.order_code is null then a.payment_amt end as payment_amt
from datamart.V_Order_Header a 
left join raw_data.mlp_promotion_coupon p on p.order_code = a.Real_order_code)
select a.buyer_id
,b.ttl_trans -- lifetime txn cnt
,b.ttl_c_trans -- lifetime cp txn cnt
,b.period_trans -- txn cnt in a period of time
,b.period_c_trans -- cp txn cnt in a period of time
,ifNull(sum(case when (toDateTime(a.payment_date) >= date_add(day,-30,toDateTime(tp.payment_date)) 
and toDateTime(a.payment_date) < toDateTime(tp.payment_date)) then payment_amt end),1) as pre_30 -- 30d txn amt before cp
,ifNull(sum(case when (toDateTime(a.payment_date) < date_add(day,30,toDateTime(tp.payment_date)) and toDateTime(a.payment_date) >= toDateTime(tp.payment_date)) then payment_amt end),0) as post_30 -- 30d txn amt after cp
,b.x_cp -- lifetime cp txn %
,ifNull(sum(case when (toDateTime(a.payment_date) < date_add(day,30,toDateTime(tp.payment_date)) 
and toDateTime(a.payment_date) >= toDateTime(tp.payment_date)) then payment_amt end),0)/ifNull(sum(case when (toDateTime(a.payment_date) >= date_add(day,-30,toDateTime(tp.payment_date))
and toDateTime(a.payment_date) < toDateTime(tp.payment_date)) then payment_amt end),1)-1 y_lift -- cp lift
,today() as create_date
from cp_txn tp
inner join crvt_amt a on tp.buyer_id = a.buyer_id
inner join buyer_txn b on tp.buyer_id = b.buyer_id
where tp.buyer_id is not NULL 
group by a.buyer_id,b.ttl_trans,b.ttl_c_trans, b.period_trans,b.x_cp,b.period_c_trans;
