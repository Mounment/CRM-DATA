/*

Date: 2021-11-01

Autor: Nichole QU

====== bi activity summary new columns ======
activity_channel / activity_target / activity_type -- 活动渠道 / 活动目标 / 活动类型

*/

-- 1. activity info table: 活动开始/结束时间，活动名称，渠道，类型，对象
drop table if exists datamart.channel_activity no delay ;
CREATE TABLE datamart.channel_activity (
activity_id Int64
, share_code String
, ad_channel_name String
, name String
, activity_channel Nullable(String)
, activity_target Nullable(String)
, activity_type Nullable(String)
, start_time Date
, end_time Date
)
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.channel_activity',
 '{replica}')
ORDER BY share_code AS 
select distinct 
aoas.activity_id as activity_id 
, aoas.share_code as share_code
, ac.ad_channel_name as ad_channel_name-- channel name
, aoa.name as name --activity_name
, sc.channel as activity_channel -- activity channel
, sc.target as activity_target -- activity target
, sc.`type` as activity_type -- activity type 
, aoa.start_time as start_time --activity start time
, aoa.end_time as end_time --activity end time 
from raw_data.mlp_ad_aldi_ad_offline_activity_setting aoas 
inner join raw_data.mlp_ad_aldi_ad_channel ac on aoas.ad_channel_code = ac.ad_channel_code 
inner join raw_data.mlp_ad_aldi_ad_offline_activity aoa on aoa.id = aoas.activity_id
left join datamart.share_code_summary sc on sc.activity_id = aoas.activity_id and sc.ad_channel_name = ac.ad_channel_name
where aoas.share_code is not null
;
-- 2021/11/01 finished 

-- 2. user traffic table: 扫码用户流量表
drop table if exists datamart.bi_user no delay;
CREATE TABLE datamart.bi_user
(
gu Nullable(String)
, user_id Nullable(Int64)
, ev Int8
, pp Nullable(String)
, cp Nullable(String)
, create_date Nullable(DateTime)
, create_time Nullable(DateTime)
, activity_id Nullable(Int64)
, share_code Nullable(String)
, cr Nullable(Int64)
)
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.bi_user',
 '{replica}')
ORDER BY ev AS
select *
, row_number() over(PARTITION by user_id, toDate(create_time) order by create_time desc) as cr --用户当天扫码倒序-create_time数据有误用tz替代
from (select distinct gu
, user_id 
, ev
, pp
, cp
, toDate(bubs.create_time) as create_date
, bubs.tz as create_time --create_time数据有误用tz替代
, aoas.activity_id
, aoas.share_code
from raw_data.mlp_bi_bi_user_behavior_source bubs
inner join raw_data.mlp_ad_aldi_ad_offline_activity_setting aoas on toString(aoas.activity_id) = (SUBSTRING(pp ,position(pp,'seqId=', 1)+6, 16))
where ev = 22
and bubs.create_time >= '2020-06-01'
UNION distinct
select distinct gu -- user identify code
, user_id
, ev -- event code
, pp -- previous page
, cp -- current page
, toDate(bubs.create_time) as create_date
, bubs.tz as create_time --create_time数据有误用tz替代
, aoas.activity_id
, aoas.share_code
from raw_data.mlp_bi_bi_user_behavior_source bubs
inner join raw_data.mlp_ad_aldi_ad_offline_activity_setting aoas on aoas.share_code = substringUTF8(pvi, 1, 16)
where ev in (5, 23) 
and bubs.create_time >= '2020-06-01') t
;
-- 2021/11/01 finished 

-- 3. Single transaction table: 订单编号，用户id，支付方式，支付金额，实际金额
drop table if exists datamart.dm_bskt_txn no delay;
CREATE TABLE datamart.dm_bskt_txn
(
buyer_id Nullable(Int64)
, order_code String
, source_type Nullable(String)
, payment_date Nullable(DateTime)
, payment_time Nullable(DateTime)
, payment_amt Nullable(Decimal(18,6))
, net_sales Nullable(Decimal(18,6))
)
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.dm_bskt_txn',
 '{replica}')
ORDER BY order_code AS
with tmp as (select pk_order_code
from raw_data.ec_sale_order
where payment_date is not null and map_desc <>'已取消'  
)
select buyer_id
,order_code
,source_type
,payment_date1 as payment_date
,payment_time
,payment_amt
,net_sales
from 
(
select buyer_id 
, c.order_code as order_code
, source_type
, toDate(payment_date) as payment_date1
, payment_date as payment_time
, sum(payment_amt) as payment_amt --basket_payment
, sum(net_sales) as net_sales --basket_netsales
from raw_data.ec_sale_order_product c 
inner join tmp on tmp.pk_order_code = c.order_code 
where payment_date >= toDate('2019-06-07 00:00:00') -- 开业日期
group by buyer_id, source_type, c.order_code, payment_date)
;
-- 2021/11/01 finished 

-- 4. Transaction type info: 支付方式，订单金额，支付金额，支付时间
drop table if exists datamart.dm_txn no delay ;
CREATE TABLE datamart.dm_txn
(
buyer_id Nullable(Int64)
, source_type String
--， order_code String
, payment_date Nullable(DateTime)
--, payment_time Nullable(DateTime)
, payment_amt Nullable(Decimal(18,6))
, net_sales Nullable(Decimal(18,6))
)
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.dm_txn',
 '{replica}')
ORDER BY source_type AS
with tmp as 
(select pk_order_code 
from raw_data.ec_sale_order 
where payment_date is not null and map_desc <>'已取消'
)
select 
buyer_id 
, source_type
, payment_date
, sum(payment_amt) as payment_amt -- txn_payment_day
, sum(net_sales) as net_sales --txn_net_sales
from (
select buyer_id 
, source_type
, c.order_code
, toDate(c.payment_date) as payment_date
, c.payment_date as payment_time
, sum(payment_amt) as payment_amt --basket_payment
, sum(net_sales) as net_sales --basket_netsales
from raw_data.ec_sale_order_product c
inner join tmp on tmp.pk_order_code = c.order_code 
where payment_date >= toDate('2019-06-07 00:00:00')--开业
group by buyer_id, source_type, c.order_code, c.payment_date ) a
group by buyer_id, source_type, payment_date 
;
-- 2021/11/01 finished 

-- 5. New member transaction: 注册用户，注册活动，注册日期，首笔订单时间，实付金额
drop table if exists datamart.register_new_mb_txn no delay ;
CREATE TABLE datamart.register_new_mb_txn
(activity_id Int64
, activity_channel Nullable(String)
, activity_target Nullable(String)
, activity_type Nullable(String)
, create_date Nullable(DateTime)
, payment_date Nullable(DateTime)
, payment_amt Nullable(Decimal(18, 6))
, net_sales Nullable(Decimal(18, 6))
, user_id Nullable(Int64)
, new_register_y_n Nullable(Int64)
)
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.register_new_mb_txn',
 '{replica}')
ORDER BY activity_id AS
select 
channel.activity_id -- 活动编号
, channel.activity_channel --注册活动渠道
, channel.activity_target -- 注册活动目标
, channel.activity_type -- 注册活动类型
, bi.create_date -- 注册日期
, txn.payment_date -- 首笔订单时间
, payment_amt -- 实付金额
, net_sales -- 税后金额
, user_id -- 注册用户
, case when bi.create_date = txn.payment_date then 1 else 0 end as new_register_y_n
from datamart.channel_activity channel
--inner join datamart.share_code_summary sc on sc.activity_id = channel.activity_id 
inner join datamart.bi_user bi on channel.share_code = bi.share_code and ev = 5  -- 通过扫码注册的所有用户
inner join (select buyer_id, payment_date
, sum(net_sales) as net_sales
, sum(payment_amt)as payment_amt
, row_number()over(PARTITION by buyer_id order by payment_date) as nu
from datamart.dm_txn
group by buyer_id, payment_date) txn --用户每天购买总金额
on toString(bi.user_id) = toString(txn.buyer_id) and txn.nu = 1
;
-- 2021/11/01 finished 

-- 6. Transaction after activity：下单前活动
drop table if exists datamart.cust_txn_aft_activity no delay;
CREATE TABLE datamart.cust_txn_aft_activity
(
activity_id Int64
, activity_channel Nullable(String)
, activity_target Nullable(String)
, activity_type Nullable(String) 
, create_date Nullable(DateTime)
, buyer_id Nullable(Int64)
, order_code Nullable(String)
, payment_date Nullable(DateTime)
, source_type Nullable(String)
, payment_time Nullable(DateTime)
, payment_amt Nullable(Decimal(18,6))
, net_sales Nullable(Decimal(18,6))
, nb Nullable(Int64)
)
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.cust_txn_aft_activity',
 '{replica}')
ORDER BY activity_id AS
select 
t.activity_id
, t.activity_channel
, t.activity_target
, t.activity_type 
, t.create_date
, a.buyer_id
, order_code
, payment_date
, source_type
, payment_time
, a.payment_amt
, a.net_sales 
, row_number()over(partition by user_id, order_code, payment_time order by create_time desc) as nb
from (
select activity_id, user_id, create_date, create_time ,activity_channel,activity_target,activity_type
from (select bi.activity_id,user_id, bi.create_date, bi.create_time,channel.activity_channel,channel.activity_target,channel.activity_type
, row_number() over(partition by bi.user_id, bi.activity_id, bi.create_date order by bi.create_time) as rw
from datamart.bi_user bi
inner join datamart.channel_activity channel on bi.share_code = channel.share_code ) b
where b.rw = 1) t
--inner join datamart.share_code_summary sc on sc.activity_id = t.activity_id 
inner join datamart.dm_bskt_txn a on toString(t.user_id) = toString(a.buyer_id) and t.create_date = a.payment_date
where a.payment_time >= date_add(mm,-3,t.create_time)  --同一天但是支付之前的扫码行为
order by nb, buyer_id desc
;
-- 2021/11/01 finished 

-- 7. Summary all the middle tables 
drop table if exists datamart.bi_activity_middle_table no delay;
CREATE TABLE datamart.bi_activity_middle_table
(
activity_id Int64,
check_date Nullable(Date),
pv Nullable(Int64),
uv Nullable(Int64),
new_register_members Nullable(Int64),
new_member_cnt Nullable(Int64),
new_member_payment_amt Nullable(Decimal(18,6)),
new_member_net_sales Nullable(Decimal(18,6)),
new_member_txn_cnt Nullable(Int64),
O2O_new_member_cnt Nullable(Int64),
O2O_payment_amt Nullable(Decimal(18,6)),
O2O_net_sales Nullable(Decimal(18,6)),
O2O_new_member_txn_cnt Nullable(Int64),
total_members Nullable(Int64),
total_transaction Nullable(Decimal(18,6)),
total_payment_amt Nullable(Decimal(18,6)),
total_net_sales Nullable(Decimal(18,6)),
total_O2O_members Nullable(Int64),
total_O2O_transaction Nullable(Decimal(18,6)),
total_O2O_payment_amt Nullable(Decimal(18,6)),
total_O2O_net_sales Nullable(Decimal(18,6))
)
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.bi_activity_middle_table',
 '{replica}')
ORDER BY activity_id AS
select * 
from 
(select 
activity_id
,bi.create_date as check_date
,count(*) as pv
,count(distinct replace(gu, '"', ''))as uv
,null as new_register_members
,null as new_member_cnt
,null as new_member_payment_amt
,null as new_member_net_sales
,null as new_member_txn_cnt
,null as O2O_new_member_cnt
,null as O2O_payment_amt
,null as O2O_net_sales
,null as O2O_new_member_txn_cnt
,null as total_members
,null as total_transaction
,null as total_payment_amt
,null as total_net_sales
,null as total_O2O_members
,null as total_O2O_transaction
,null as total_O2O_payment_amt
,null as total_O2O_net_sales
from datamart.bi_user bi
where ev = 22
group by activity_id, bi.create_date
union distinct
select 
activity_id
,bi.create_date as check_date
,null as pv
,null as uv
,count(distinct user_id) as new_register_members
,null as new_member_cnt
,null as new_member_payment_amt
,null as new_member_net_sales
,null as new_member_txn_cnt
,null as O2O_new_member_cnt
,null as O2O_payment_amt
,null as O2O_net_sales
,null as O2O_new_member_txn_cnt
,null as total_members
,null as total_transaction
,null as total_payment_amt
,null as total_net_sales
,null as total_O2O_members
,null as total_O2O_transaction
,null as total_O2O_payment_amt
,null as total_O2O_net_sales
from datamart.bi_user bi
where ev = 5
group by activity_id, bi.create_date
--通过扫活动太阳码的当天注册人数+ 注册当天成为nm + 以后成为nm
union distinct
select activity_id
,payment_date as check_date
,null as pv
,null as uv
,null as new_register_members
,count(distinct user_id) as new_member_cnt
,sum(payment_amt) as new_member_payment_amt
,sum(net_sales) as new_member_net_sales
,null as new_member_txn_cnt
,null as O2O_new_member_cnt
,null as O2O_payment_amt
,null as O2O_net_sales
,null as O2O_new_member_txn_cnt
,null as total_members
,null as total_transaction
,null as total_payment_amt
,null as total_net_sales
,null as total_O2O_members
,null as total_O2O_transaction
,null as total_O2O_payment_amt
,null as total_O2O_net_sales
from datamart.register_new_mb_txn a --有购买的用户
group by activity_id, payment_date
--通过扫太阳码注册的会员，第一次购买日的交易总数
union distinct
select activity_id
,t1.payment_date as check_date --交易日期
,null as pv
,null as uv
,null as new_register_members
,null as new_member_cnt
,null as new_member_payment_amt
,null as new_member_net_sales
,count(distinct order_code) as new_member_txn_cnt --new_member_txn_count
,null as O2O_new_member_cnt
,null as O2O_payment_amt
,null as O2O_net_sales
,null as O2O_new_member_txn_cnt
,null as total_members
,null as total_transaction
,null as total_payment_amt
,null as total_net_sales
,null as total_O2O_members
,null as total_O2O_transaction
,null as total_O2O_payment_amt
,null as total_O2O_net_sales
from raw_data.ec_sale_order_product dm
inner join datamart.register_new_mb_txn t1 on toString(t1.user_id) = toString(dm.buyer_id) and t1.payment_date = toDate(dm.payment_date)
group by activity_id, t1.payment_date
--通过扫活动太阳码的当天注册人数+ 注册当天成为nm且为o2otxn+ 以后成为nm且为o2o
union distinct
select 
t1.activity_id
,txn.payment_date as check_date
,null as pv
,null as uv
,null as new_register_members
,null as new_member_cnt
,null as new_member_payment_amt
,null as new_member_net_sales
,null as new_member_txn_cnt
,count(distinct txn.buyer_id) as O2O_new_member_cnt
,sum(txn.payment_amt) as O2O_payment_amt
,sum(txn.net_sales) as O2O_net_sales
,null as O2O_new_member_txn_cnt
,null as total_members
,null as total_transaction
,null as total_payment_amt
,null as total_net_sales
,null as total_O2O_members
,null as total_O2O_transaction
,null as total_O2O_payment_amt
,null as total_O2O_net_sales
from datamart.dm_txn txn  
inner join datamart.register_new_mb_txn t1 on toString(txn.buyer_id) = toString(t1.user_id) and txn.payment_date = t1.payment_date -- first txn date
and source_type like 'O2O%' -- o2o basket txn
group by t1.activity_id , txn.payment_date
--通过扫太阳码注册的会员，第一次购买日的o2o交易总数
union distinct
select 
t1.activity_id
,t1.payment_date  as check_date
,null as pv
,null as uv
,null as new_register_members
,null as new_member_cnt
,null as new_member_payment_amt
,null as new_member_net_sales
,null as new_member_txn_cnt
,null as O2O_new_member_cnt
,null as O2O_payment_amt
,null as O2O_net_sales
,count(distinct order_code) as O2O_new_member_txn_cnt
,null as total_members
,null as total_transaction
,null as total_payment_amt
,null as total_net_sales
,null as total_O2O_members
,null as total_O2O_transaction
,null as total_O2O_payment_amt
,null as total_O2O_net_sales
from raw_data.ec_sale_order_product dm
inner join datamart.register_new_mb_txn t1 on toString(t1.user_id) = toString(dm.buyer_id) and t1.payment_date = toDate(dm.payment_date) and dm.source_type like 'O2O%'
group by t1.activity_id,t1.payment_date
--扫码参加活动以后有购买的客户交易
union distinct
select 
activity_id
,create_date as check_date
,null as pv
,null as uv
,null as new_register_members
,null as new_member_cnt
,null as new_member_payment_amt
,null as new_member_net_sales
,null as new_member_txn_cnt
,null as O2O_new_member_cnt
,null as O2O_payment_amt
,null as O2O_net_sales
,null as O2O_new_member_txn_cnt
,count(distinct buyer_id) as total_members
,count(distinct order_code) as total_transaction
,sum(payment_amt) as total_payment_amt
,sum(net_sales) as total_net_sales
,null as total_O2O_members
,null as total_O2O_transaction
,null as total_O2O_payment_amt
,null as total_O2O_net_sales
from datamart.cust_txn_aft_activity
where nb=1
group by activity_id, create_date
union distinct
select 
activity_id
,create_date as check_date
,null as pv
,null as uv
,null as new_register_members
,null as new_member_cnt
,null as new_member_payment_amt
,null as new_member_net_sales
,null as new_member_txn_cnt
,null as O2O_new_member_cnt
,null as O2O_payment_amt
,null as O2O_net_sales
,null as O2O_new_member_txn_cnt
,null as total_members
,null as total_transaction
,null as total_payment_amt
,null as total_net_sales
,count(distinct buyer_id) as total_O2O_members
,count(distinct order_code) as total_O2O_transaction
,sum(payment_amt) as total_O2O_payment_amt
,sum(net_sales) as total_O2O_net_sales
from datamart.cust_txn_aft_activity
where source_type like 'O2O%'
and nb =1
group by activity_id, create_date
)sm
;
-- 2021/11/01 finished 

-- 8. bi activity summary table 活动流量相关表 
drop table if exists datamart.bi_activity_summary no delay ;
CREATE TABLE datamart.bi_activity_summary
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.bi_activity_summary',
 '{replica}')
ORDER BY activity_id AS
with 
bi_activity_middle_table2 as (SELECT 
activity_id
, check_date
, toInt32OrNull(arrayStringConcat(groupArray(toString(toNullable(pv))))) as pv
, toInt32OrNull(arrayStringConcat(groupArray(toString(toNullable(uv))))) as uv 
, toInt32OrNull(arrayStringConcat(groupArray(toString(toNullable(new_register_members))))) as new_register_members
, toInt32OrNull(arrayStringConcat(groupArray(toString(toNullable(new_member_cnt))))) as new_member_cnt
, toFloat32OrNull(arrayStringConcat(groupArray(toString(toNullable(new_member_payment_amt))))) as new_member_payment_amt
, toFloat32OrNull(arrayStringConcat(groupArray(toString(toNullable(new_member_net_sales))))) as new_member_net_sales
, toInt32OrNull(arrayStringConcat(groupArray(toString(toNullable(new_member_txn_cnt))))) as new_member_txn_cnt
, toInt32OrNull(arrayStringConcat(groupArray(toString(toNullable(O2O_new_member_cnt))))) as O2O_new_member_cnt
, toFloat32OrNull(arrayStringConcat(groupArray(toString(toNullable(O2O_payment_amt))))) as O2O_payment_amt
, toFloat32OrNull(arrayStringConcat(groupArray(toString(toNullable(O2O_net_sales))))) as O2O_net_sales
, toInt32OrNull(arrayStringConcat(groupArray(toString(toNullable(O2O_new_member_txn_cnt))))) as O2O_new_member_txn_cnt
, toInt32OrNull(arrayStringConcat(groupArray(toString(toNullable(total_members))))) as total_members
, toFloat32OrNull(arrayStringConcat(groupArray(toString(toNullable(total_transaction))))) as total_transaction
, toFloat32OrNull(arrayStringConcat(groupArray(toString(toNullable(total_payment_amt))))) as total_payment_amt
, toFloat32OrNull(arrayStringConcat(groupArray(toString(toNullable(total_net_sales))))) as total_net_sales
, toInt32OrNull(arrayStringConcat(groupArray(toString(toNullable(total_O2O_members))))) as total_O2O_members
, toFloat32OrNull(arrayStringConcat(groupArray(toString(toNullable(total_O2O_transaction))))) as total_O2O_transaction
, toFloat32OrNull(arrayStringConcat(groupArray(toString(toNullable(total_O2O_payment_amt))))) as total_O2O_payment_amt
, toFloat32OrNull(arrayStringConcat(groupArray(toString(toNullable(total_O2O_net_sales))))) as total_O2O_net_sales 
FROM datamart.bi_activity_middle_table 
WHERE  activity_id = datamart.bi_activity_middle_table.activity_id 
and check_date = datamart.bi_activity_middle_table.check_date 
group by activity_id,check_date )
select distinct 
ca.activity_id
, b.check_date
, ca.ad_channel_name 
, ca.name
, ca.activity_channel  
, ca.activity_target  
, ca.activity_type 
, ca.start_time
, ca.end_time
, (b.pv)
, (b.uv)
, (b.new_register_members)
, (b.new_member_cnt)
, (b.new_member_payment_amt)
, (b.new_member_net_sales)
, (b.new_member_txn_cnt)
, (b.O2O_new_member_cnt)
, (b.O2O_payment_amt)
, (b.O2O_net_sales)
, (b.O2O_new_member_txn_cnt)
, (b.total_members)
, (b.total_transaction)
, (b.total_payment_amt)
, (b.total_net_sales)
, (b.total_O2O_members)
, (b.total_O2O_transaction)
, (b.total_O2O_payment_amt)
, (b.total_O2O_net_sales)
, now() as refresh_date 
from datamart.channel_activity ca 
inner join bi_activity_middle_table2 b
on ca.activity_id = b.activity_id
;

