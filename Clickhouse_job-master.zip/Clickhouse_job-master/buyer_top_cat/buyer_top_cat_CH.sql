drop table if exists datamart.cust_top_vrt_pref_tmp no delay;
CREATE TABLE datamart.cust_top_vrt_pref_tmp 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.cust_top_vrt_pref_tmp',
 '{replica}')
ORDER BY cut_off AS 
with pref as -- get category preference for each customer
(select 
a.cut_off as cut_off
,buyer_id
,round((txn_m3_01_pct / txn_m3_01_pct_avg),2) txn_m3_01_pref
,round((txn_m3_02_pct / txn_m3_02_pct_avg),2) txn_m3_02_pref 
,round((txn_m3_03_pct / txn_m3_03_pct_avg),2) txn_m3_03_pref
,round((txn_m3_04_pct / txn_m3_04_pct_avg),2) txn_m3_04_pref 
,round((txn_m3_05_pct / txn_m3_05_pct_avg),2) txn_m3_05_pref
,round((txn_m3_06_pct / txn_m3_06_pct_avg),2) txn_m3_06_pref
,round((txn_m3_07_pct / txn_m3_07_pct_avg),2) txn_m3_07_pref
,round((txn_m3_08_pct / txn_m3_08_pct_avg),2) txn_m3_08_pref
,round((txn_m3_09_pct / txn_m3_09_pct_avg),2) txn_m3_09_pref
,round((txn_m3_10_pct / txn_m3_10_pct_avg),2) txn_m3_10_pref
,round((txn_m3_11_pct / txn_m3_11_pct_avg),2) txn_m3_11_pref
,round((txn_m3_14_pct / txn_m3_14_pct_avg),2) txn_m3_14_pref
,round((txn_m3_16_pct / txn_m3_16_pct_avg),2) txn_m3_16_pref
,case when txn_m3_17_pct_avg>0 then round((txn_m3_17_pct / txn_m3_17_pct_avg),2) else 0 end as txn_m3_17_pref
from model.m3_txn_vrt_rfm a
inner join model.m3_pref_base_lk1 m on a.cut_off = m.cut_off
)
,tmp as (
select cut_off ,buyer_id,item_category_name,category_pref
from (
select 
cut_off
,buyer_id
,'01 - Alcoholic Beverages' as item_category_name
,ifNull(txn_m3_01_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'02 - Bakery' as item_category_name
,ifNull(txn_m3_02_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'03 - Breakfast' as item_category_name
,ifNull(txn_m3_03_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'04 - Dairy' as item_category_name
,ifNull(txn_m3_04_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'05 - Chilled Convenience' as item_category_name
,ifNull(txn_m3_05_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'06 - Fresh Meat & Fish' as item_category_name
,ifNull(txn_m3_06_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'07 - Freezer' as item_category_name
,ifNull(txn_m3_07_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'08 - Fruits & Vegetables' as item_category_name
,ifNull(txn_m3_08_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'09 - Pantry' as item_category_name
,ifNull(txn_m3_09_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'10 - Non-Alcoholic Beverages' as item_category_name
,ifNull(txn_m3_10_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'11 - Snacking' as item_category_name
,ifNull(txn_m3_11_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'14 - Health, Beauty & Baby' as item_category_name
,ifNull(txn_m3_14_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'16 - Household' as item_category_name
,ifNull(txn_m3_16_pref,0) as category_pref
from pref
union distinct
select 
cut_off
,buyer_id
,'17 - Outdoor/Leisure' as item_category_name
,ifNull(txn_m3_17_pref,0) as category_pref
from pref))
select cut_off 
,buyer_id
,case when rn= 1 and category_pref = 0 then 'na' 
when rn= 1 and category_pref > 0 then item_category_name end as cat1
,case when rn= 1 then category_pref end as cat1_preference_score
,case when rn= 2 and category_pref = 0 then 'na' 
when rn= 2 and category_pref > 0 then item_category_name end as cat2
,case when rn= 2 then category_pref end as cat2_preference_score
,case when rn= 3 and category_pref = 0 then 'na' 
when rn= 3 and category_pref > 0 then item_category_name end as cat3
,case when rn= 3 then category_pref end as cat3_preference_score
from
(select 
cut_off
,buyer_id 
,item_category_name
,category_pref
,row_number() over (partition by cut_off, buyer_id order by category_pref desc) rn
from tmp) t
where t.rn <=3  -- to get top 3 categories
group by cut_off, buyer_id,rn,item_category_name,category_pref;


drop table if exists datamart.cust_top_vrt_pref no delay;
CREATE TABLE datamart.cust_top_vrt_pref 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.cust_top_vrt_pref',
 '{replica}')
ORDER BY cut_off AS
select cut_off
,buyer_id
,arrayStringConcat(groupArray(toString(toNullable(cat1)))) as cat1
,arrayStringConcat(groupArray(toString(toNullable(cat1_preference_score)))) as cat1_preference_score
,arrayStringConcat(groupArray(toString(toNullable(cat2)))) as cat2
,arrayStringConcat(groupArray(toString(toNullable(cat2_preference_score)))) as cat2_preference_score
,arrayStringConcat(groupArray(toString(toNullable(cat3)))) as cat3
,arrayStringConcat(groupArray(toString(toNullable(cat3_preference_score)))) as cat3_preference_score
from datamart.cust_top_vrt_pref_tmp a 
WHERE cut_off = a.cut_off and buyer_id = a.buyer_id
group by cut_off, buyer_id;


---drop table datamart.buyer_top3_cat;修改为append方式
insert into datamart.buyer_top3_cat  
select 
u.cut_off as cut_off
,u.buyer_id as buyer_id
,mt.member_type as member_type
,cat1
,toFloat64OrNull(cat1_preference_score)cat1_preference_score
,cat2
,toFloat64OrNull(cat2_preference_score)cat2_preference_score
,cat3
,toFloat64OrNull(cat3_preference_score)cat3_preference_score
,toDateTime(now()) as insert_time
from model.m_ouser_all u 
left join datamart.tp_customer_RFM mt  on u.cut_off = mt.cutoff and toString(u.buyer_id) = mt.buyer_id 
left join datamart.cust_top_vrt_pref p on u.cut_off = p.cut_off and u.buyer_id = p.buyer_id;

