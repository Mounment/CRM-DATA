----------------------------------------0.1 生成 last_cut_off ----
drop table if exists model.m_cut_off_last_lk no delay;
CREATE TABLE model.m_cut_off_last_lk 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.m_cut_off_last_lk',
 '{replica}')
ORDER BY tuple() AS 
select today()-15 as last_cut_off;


----------------------------------------------------------
----------------------------------------------------------

------1.从m_coupon_scoring_result 获取到trfm ，scoring 结果
 
drop table if exists model.coupon_segment_middle_base no delay;
CREATE TABLE model.coupon_segment_middle_base 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.coupon_segment_middle_base',
 '{replica}')
ORDER BY tuple() AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select 
s.buyer_id as buyer_id,
s.cut_off as cut_off,
s.txn_m4_cust_micro_seg as cur_trfm,
s.Probability as coupon_propensity,
s.Decile as Coupon_decile,
c.txn_m2_type_main as Channel,
c.txn_m2_cust_atv as avg_basket_size
--c.cust_m6_cp_pay_amt as coupon_avg_basket_size
 from  model.m_coupon_scoring_result s
 left join  model.m_coupon_variable_final c on c.buyer_id = s.buyer_id 
 left join  model.m_variable_final m on s.buyer_id = m.buyer_id 
 where toDate(s.cut_off) = cod;
 
-- new column: online transaction percentage 
-- Autor: Nichole Qu (2021-11-15 14:43:00)
Drop table if exists model.coupon_segment_middle_table no delay;
CREATE TABLE model.coupon_segment_middle_table 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.coupon_segment_middle_table',
 '{replica}')
ORDER BY tuple() AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
SELECT buyer_id,
cut_off,
cur_trfm,
coupon_propensity,
Coupon_decile,
Channel,
avg_basket_size
, ROUND((CAST(t.online_cnt as float) / CAST(ttl as float)), 2) as online_txn_perct -- the percentage of online transaction
FROM (
select a.buyer_id as buyer_id 
, count(DISTINCT case when b.source_type in ('O2O_DFS', 'O2O_B2C', 'NDD') then b.order_code end ) as online_cnt 
, count(DISTINCT b.order_code) as ttl 
from model.coupon_segment_middle_base a 
inner join model.m_dm_txn_90d b on a.buyer_id = b.buyer_id and toDate(a.cut_off) = b.cut_off 
group by a.buyer_id 
) t
inner join model.coupon_segment_middle_base a on a.buyer_id = t.buyer_id;

 
------2.计算 4个 coupon  segment 的avg probability 和coupon lift  
 
drop table if exists model.coupon_lift_middle_table no delay;
CREATE TABLE model.coupon_lift_middle_table 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.coupon_lift_middle_table',
 '{replica}')
ORDER BY tuple() AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
,avg_all as (select
*
from 
(select
txn_m4_cust_micro_seg,
case when txn_m4_cust_micro_seg = 'Activated' then  avg(Probability) 
when txn_m4_cust_micro_seg = 'At Risk' then  avg(Probability)
when txn_m4_cust_micro_seg = 'Core' then  avg(Probability)
when txn_m4_cust_micro_seg = 'Engaged' then  avg(Probability) end as avg_num
from model.m_coupon_scoring_result s where s.txn_m4_cust_micro_seg  in ('Activated','At Risk','Core','Engaged')
group by txn_m4_cust_micro_seg) t ) 
select 
m.buyer_id,
m.txn_m4_cust_micro_seg,
case when m.txn_m4_cust_micro_seg = 'Activated' then round(cast(m.Probability as float) / avg_all.avg_num, 4) 
when m.txn_m4_cust_micro_seg = 'At Risk' then round(cast(m.Probability as float) / avg_all.avg_num, 4) 
when m.txn_m4_cust_micro_seg = 'Core' then round(cast(m.Probability as float) / avg_all.avg_num, 4) 
when m.txn_m4_cust_micro_seg = 'Engaged' then round(cast(m.Probability as float) / avg_all.avg_num, 4) END as coupon_lift 
from model.m_coupon_scoring_result m 
left join avg_all on avg_all.txn_m4_cust_micro_seg = m.txn_m4_cust_micro_seg
where m.txn_m4_cust_micro_seg  in ('Activated','At Risk','Core','Engaged')
and toDate(m.cut_off) = cod;

---------------3.计算 4个 coupon  segment 的avg probability 和TRFM  lift 


drop table if exists model.trfm_lift_middle_table no delay;
CREATE TABLE model.trfm_lift_middle_table 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.trfm_lift_middle_table',
 '{replica}')
ORDER BY tuple() AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
,avg_all as (select
*
from 
(select
txn_m4_cust_micro_seg,
case when txn_m4_cust_micro_seg = 'Activated' then  avg(Probability) 
when txn_m4_cust_micro_seg = 'At Risk' then  avg(Probability)
when txn_m4_cust_micro_seg = 'Core' then  avg(Probability)
when txn_m4_cust_micro_seg = 'Engaged' then  avg(Probability) end as avg_num
from model.m_cust_scoring_result s where s.txn_m4_cust_micro_seg  in ('Activated','At Risk','Core','Engaged')
group by txn_m4_cust_micro_seg) t ) 
select 
m.buyer_id,
m.txn_m4_cust_micro_seg,
case when m.txn_m4_cust_micro_seg = 'Activated' then round(cast(m.Probability as float) / avg_all.avg_num, 4) 
when m.txn_m4_cust_micro_seg = 'At Risk' then round(cast(m.Probability as float) / avg_all.avg_num, 4) 
when m.txn_m4_cust_micro_seg = 'Core' then round(cast(m.Probability as float) / avg_all.avg_num, 4) 
when m.txn_m4_cust_micro_seg = 'Engaged' then round(cast(m.Probability as float) / avg_all.avg_num, 4) END as trfm_lift 
from model.m_cust_scoring_result m 
left join avg_all on avg_all.txn_m4_cust_micro_seg = m.txn_m4_cust_micro_seg
where m.txn_m4_cust_micro_seg  in ('Activated','At Risk','Core','Engaged')
and toDate(m.cut_off) = cod;


------ 4. 组合生产 trfm lift 和coupon lift  	

drop table if exists model.Coupon_trfm_middle_table no delay;
CREATE TABLE model.Coupon_trfm_middle_table 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.Coupon_trfm_middle_table',
 '{replica}')
ORDER BY tuple() AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
select
c.buyer_id as buyer_id
,c.cut_off as cut_off
,c.cur_trfm as cur_trfm
,c.coupon_propensity as coupon_propensity
,c.Coupon_decile as Coupon_decile
,c.Channel as Channel
,c.avg_basket_size as avg_basket_size
,c.online_txn_perct as online_txn_perct
,t.trfm_lift as trfm_lift
,co.coupon_lift as coupon_lift
from model.coupon_segment_middle_table c 
left join model.trfm_lift_middle_table t  on c.buyer_id = t.buyer_id
left join model.coupon_lift_middle_table co on c.buyer_id = co.buyer_id
and toDate(c.cut_off) = cod;

---- 5.获取上次cut_off 客群的 last trfm  

drop table if exists model.coupon_trfm_lift_middle no delay;
CREATE TABLE model.coupon_trfm_lift_middle 
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.coupon_trfm_lift_middle',
 '{replica}')
ORDER BY tuple() AS 
WITH (SELECT cut_off FROM model.m_cut_off_lk) AS cod
, (SELECT last_cut_off FROM model.m_cut_off_last_lk) AS last_cod
SELECT 
c.buyer_id as buyer_id
,c.cut_off as cut_off
,c.cur_trfm as cur_trfm
,c.coupon_propensity as coupon_propensity
,c.Coupon_decile as Coupon_decile
,c.Channel as Channel
,c.avg_basket_size as avg_basket_size
,c.online_txn_perct as online_txn_perct
,c.trfm_lift as trfm_lift
,c.coupon_lift as coupon_lift
,m.txn_m4_cust_micro_seg as last_trfm
from  model.Coupon_trfm_middle_table c
left join model.m_variable_final_history m on c.buyer_id = m.buyer_id
where toDate(m.cut_off) = last_cod and toDate(c.cut_off) =  cod;

---------------6.--插入数据到历史数据 
insert into model.coupon_trfm_lift_final_hist select * from model.coupon_trfm_lift_final;

------------------7. 生成 movement 数据    

drop table if exists model.coupon_trfm_lift_final no delay;
CREATE TABLE model.coupon_trfm_lift_final
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/model/model.coupon_trfm_lift_final',
 '{replica}')
ORDER BY tuple() AS 
select
m.buyer_id as buyer_id
,m.cut_off as cut_off
,m.cur_trfm as cur_trfm
,m.coupon_propensity as coupon_propensity
,m.Coupon_decile as Coupon_decile
,m.Channel as Channel
,m.avg_basket_size as avg_basket_size
,m.online_txn_perct as online_txn_perct
,m.trfm_lift as trfm_lift
,m.coupon_lift as coupon_lift
,m.last_trfm as last_trfm
,case when m.last_trfm ='Activated' and m.cur_trfm ='Activated' then 'retain'
when m.last_trfm ='At Risk' and m.cur_trfm ='At Risk' then 'retain'
when m.last_trfm ='Core' and m.cur_trfm ='Core' then 'retain'
when m.last_trfm ='Engaged' and m.cur_trfm ='Engaged' then 'retain' 
when m.last_trfm ='Core' and m.cur_trfm ='At Risk' then 'Negative' 
when m.last_trfm ='Core' and m.cur_trfm ='Engaged' then 'Negative'
when m.last_trfm ='Core' and m.cur_trfm ='Disengaged' then 'Negative' 
when m.last_trfm ='Engaged' and m.cur_trfm ='At Risk' then 'Negative' 
when m.last_trfm ='Engaged' and m.cur_trfm ='Disengaged' then 'Negative'
when m.last_trfm ='Engaged' and m.cur_trfm ='Frozen' then 'Negative'
when m.last_trfm ='At Risk' and m.cur_trfm ='Disengaged' then 'Negative'
when m.last_trfm ='At Risk' and m.cur_trfm ='Frozen' then 'Negative'
when m.last_trfm ='Activated' and m.cur_trfm ='Disengaged' then 'Negative'
when m.last_trfm ='Activated' and m.cur_trfm ='Frozen' then 'Negative'
when m.last_trfm ='Engaged' and m.cur_trfm ='Core' then 'Positive' 
when m.last_trfm ='Activated' and m.cur_trfm ='Engaged' then 'Positive' 
when m.last_trfm ='Activated' and m.cur_trfm ='Core' then 'Positive' 
when m.last_trfm ='Activated' and m.cur_trfm ='At Risk' then 'Positive' 
when m.last_trfm ='At Risk' and m.cur_trfm ='Engaged' then 'Positive' 
when m.last_trfm ='At Risk' and m.cur_trfm ='Core' then 'Positive' 
when m.last_trfm ='Disengaged' and m.cur_trfm ='At Risk' then 'Positive' 
when m.last_trfm ='Disengaged' and m.cur_trfm ='Core' then 'Positive' 
when m.last_trfm ='Disengaged' and m.cur_trfm ='Engaged' then 'Positive' 
when m.last_trfm ='Frozen' and m.cur_trfm ='At Risk' then 'Positive'
when m.last_trfm ='Frozen' and m.cur_trfm ='Core' then 'Positive'
when m.last_trfm ='Frozen' and m.cur_trfm ='Engaged' then 'Positive' 
when m.last_trfm ='Frozen' and m.cur_trfm ='Disengaged' then 'Positive'
when m.last_trfm ='Inactive New' and m.cur_trfm ='Engaged' then 'Positive'  
when m.last_trfm ='Inactive New' and m.cur_trfm ='At Risk' then 'Positive'
when m.last_trfm ='Inactive New' and m.cur_trfm ='Core' then 'Positive'
when m.last_trfm ='Passive' and m.cur_trfm ='At Risk' then 'Positive' 
when m.last_trfm ='Passive' and m.cur_trfm ='Engaged' then 'Positive'  
when m.last_trfm ='Passive' and m.cur_trfm ='Activated' then 'Positive'  
when m.last_trfm ='Passive' and m.cur_trfm ='Core' then 'Positive' end as movement
from model.coupon_trfm_lift_middle m;

