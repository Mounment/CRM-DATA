insert into datamart.T_F_MemberTag
with student as
(
select c.id AS id 
from datamart.external_tag as a
inner join analysis.mobile_device_id as b on a.idfa= b.IDFA
inner join datamart.u_user_2 as uu on b.mobile=uu.mobile
inner join raw_data.mlp_ouser_u_user as c on uu.id = c.id
--inner join raw_data.mlp_ouser_u_user as c on b.mobile = c.mobile
where a.tag_code = toInt32('030301') --Occupation is student
union distinct 
select c.id AS id 
from datamart.external_tag as a
inner join analysis.mobile_device_id as b on a.IMEI = b.imei 
inner join datamart.u_user_2 as uu on b.mobile=uu.mobile
inner join raw_data.mlp_ouser_u_user as c on uu.id = c.id
--inner join raw_data.mlp_ouser_u_user as c on b.mobile = c.mobile
where a.tag_code = toInt32('030301') --Occupation is student
) -- student list                         --Finish
,age as
(select id as buyer_id
from raw_data.mlp_ouser_u_user a
where case when toDayOfYear(toDate(concat('2000',subString(birthday,5,6)))) >= toDayOfYear(toDate(concat('2000',subString(toString(today()),5,6)))) then 
minus(toInt64(toYear(today())),toInt64OrZero(substring(birthday,1,4)))-1
else minus(toInt64(toYear(today())),toInt64OrZero(substring(birthday,1,4))) end > 17 
and case when toDayOfYear(toDate(concat('2000',subString(birthday,5,6)))) >= toDayOfYear(toDate(concat('2000',subString(toString(today()),5,6)))) then 
minus(toInt64(toYear(today())),toInt64OrZero(substring(birthday,1,4)))-1
else minus(toInt64(toYear(today())),toInt64OrZero(substring(birthday,1,4))) end < 50  
union distinct
select c.id as buyer_id
from datamart.external_tag a
inner join analysis.mobile_device_id b on a.idfa= b.IDFA
inner join datamart.u_user_2 as uu on b.mobile=uu.mobile
inner join raw_data.mlp_ouser_u_user as c on uu.id = c.id
--inner join raw_data.mlp_ouser_u_user c on b.mobile = c.mobile
where tag_code in (toInt64('030602'),toInt64('030603'),toInt64('030604'),toInt64('030605'),toInt64('030606'),toInt64('030607')) --18--49岁--8,562
UNION distinct 
select c.id as buyer_id
from datamart.external_tag a
inner join analysis.mobile_device_id b on a.imei= b.IMEI
inner join datamart.u_user_2 as uu on b.mobile=uu.mobile
inner join raw_data.mlp_ouser_u_user as c on uu.id = c.id
--inner join raw_data.mlp_ouser_u_user c on b.mobile = c.mobile
where tag_code in (toInt64('030602'),toInt64('030603'),toInt64('030604'),toInt64('030605'),toInt64('030606'),toInt64('030607')) 
)
,rte as
(SELECT DISTINCT buyer_id FROM 
(select 
buyer_id 
,order_date
,order_code 
,payment_date
,case when source_type in ('O2O_B2C','O2O_DFS','NDD') then 1 
when source_type in ('POS','SCAN_QR_CODE','MOBILE_POS') then 0
end as online_flg
from raw_data.ec_sale_order_product a
where toDayOfWeek(payment_date) not in (6,7)
and item_sub_subcategory_name in ('01 - Delicatessen Food','03 - Salads','04 - Ready-to-Eat Salad','06 - Sandwiches & Snacks') 
--and payment_date >= date_add(dd,-91,today())
and a.buyer_id <>'-1'
) as m
where m.online_flg = 1
or 
(m.online_flg = 0 
and parseDateTimeBestEffort(substring(toString(payment_date),12,8)) >= parseDateTimeBestEffort('11:30:00')
and parseDateTimeBestEffort(substring(toString(payment_date),12,8)) <= parseDateTimeBestEffort('14:00:00')) -- 线下11:30 -- 14:00消费RTE
)
select buyer_id
,'Occupation' as TagKey
,'Office_Worker' as TagValue
,today() as BeginDate
,today()+6 as EndDate
,toDateTime(now()) as insert_time
from (select buyer_id from age where buyer_id not in (select id from student)
union distinct
select buyer_id from rte where buyer_id not in (select id from student))tp
group by buyer_id;
