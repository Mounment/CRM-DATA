insert into datamart.T_F_MemberTag
select 
buyer_id 
,'F_cat1' as TagKey
,item_category_name as TagValue
,date_add(dd,-90,cutoff) as BeginDate
,cutoff as EndDate
,toDateTime(now()) as insert_time
from datamart.cat_f_preference
where F_DA_rank =1
and cutoff = (select max(cutoff) from datamart.cat_f_preference)
and buyer_id <> '-1'