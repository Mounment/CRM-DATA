-- Wednesday Weekly refresh   
--Survey
insert into datamart.T_F_MemberTag
select 
b.buyer_id as buyer_id
,'Survey' as TagKey
,case when payment_amt >=100 and payment_amt <=200 then 1 else 0 end as TagValue
,date_add(dd,-14,cut_off) as BeginDate
,b.cut_off as EndDate
,toDateTime(now()) as insert_time
from model.m_ouser_all b 
left join (select buyer_id, sum(payment_amt) as payment_amt from model.m_dm_txn_90d a 
where toDate(a.payment_date) > toDate(date_add(dd,-14,cut_off))
and toDate(a.payment_date) <=cut_off group by buyer_id) a -- has txn in lastest 14 days, and sum their payment_amt
on b.buyer_id = a.buyer_id;