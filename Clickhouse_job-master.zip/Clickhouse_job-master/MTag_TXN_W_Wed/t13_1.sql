insert into datamart.T_F_MemberTag
select 
buyer_id
,'Mainstore'as TagKey
,txn_m2_str_main as TagValue
,date_add(dd,-90,cut_off) as BeginDate
,cut_off as EndDate
,toDateTime(now()) as insert_time
from model.m2_txn_cust_str_main where buyer_id <> '-1';
