--Store -- first payment_date of each customer and store
insert into datamart.T_F_MemberTag
select 
a.buyer_id as Buyer_id 
,'Store' as TagKey 
,merchant_code as TagValue
,toDate(payment_date) as BeginDate
,'2099-12-31' as EndDate
,toDateTime(now()) as insert_time
from
(select 
buyer_id
,merchant_code
,min(payment_date) as payment_date
from model.m_dm_txn_all group by buyer_id, merchant_code) a
left join 
(select Buyer_id,TagValue from datamart.T_F_MemberTag where TagKey = 'Store') b 
on toInt64(a.buyer_id) = toInt64(b.Buyer_id) and a.merchant_code = b.TagValue
where b.Buyer_id =''
and a.buyer_id <> '-1'
