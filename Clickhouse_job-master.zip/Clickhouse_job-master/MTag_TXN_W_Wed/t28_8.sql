insert into datamart.T_F_MemberTag
select buyer_id,TagKey,TagValue,BeginDate,EndDate,toDateTime(now()) as insert_time from(
select 
ord.buyer_id as buyer_id,
'Txn-Channel' as TagKey,
'Online' as TagValue,
toDate(min(ord.payment_date)) as BeginDate,
'2099-12-31' as EndDate
from 
raw_data.ec_sale_order ord 
inner join raw_data.mlp_ouser_u_user u 
on ord.buyer_id=u.id 
and ord.payment_date is not null 
and ord.map_desc <>'已取消' 
and ord.buyer_id is not null 
--and ord.buyer_id<>''
and ord.source_type like 'O2O%'
left join datamart.T_F_MemberTag tag 
on toInt64(tag.Buyer_id)=toInt64(ord.buyer_id)
and tag.TagValue='Online' 
and tag.TagKey='Txn-Channel'
where tag.Buyer_id is null
group by ord.buyer_id) temp;
