--Category -- first payment_date of each customer and category
insert into datamart.T_F_MemberTag
select 
a.buyer_id as buyer_id 
,'Category' as TagKey 
,a.item_category_name as TagValue
,toDate(a.payment_date) as BeginDate
,'2099-12-31' as EndDate
,toDateTime(now()) as insert_time
from
(select 
buyer_id
,item_category_name
,min(payment_date) as payment_date
from model.m_dm_txn_all
group by buyer_id, item_category_name) a
left join 
(select Buyer_id, TagValue from datamart.T_F_MemberTag where TagKey = 'Category') b 
on toInt64(a.buyer_id) = toInt64(b.Buyer_id) and a.item_category_name = b.TagValue
where b.Buyer_id =''
and a.buyer_id <> '-1'
