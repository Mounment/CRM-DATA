
--CatP1
insert into datamart.T_F_MemberTag
select buyer_id
,'CatP1' as TagKey
,cat1 as TagValue
,date_add(dd,-7,cut_off) as BeginDate
,cut_off as EndDate
,toDateTime(now()) as insert_time
from datamart.cust_top_vrt_pref  where buyer_id <> '-1';

--CatP2
insert into datamart.T_F_MemberTag
select buyer_id
,'CatP2' as TagKey
,cat2 as TagValue
,date_add(dd,-7,cut_off) as BeginDate
,cut_off as EndDate
,toDateTime(now()) as insert_time
from datamart.cust_top_vrt_pref 
where cat2 <> 'na' and buyer_id <>'-1';

--CatP3
insert into datamart.T_F_MemberTag
select buyer_id
,'CatP3' as TagKey
,cat3 as TagValue
,date_add(dd,-7,cut_off) as BeginDate
,cut_off as EndDate
,toDateTime(now()) as insert_time
from datamart.cust_top_vrt_pref 
where cat3 <> 'na' and buyer_id <> '-1';
