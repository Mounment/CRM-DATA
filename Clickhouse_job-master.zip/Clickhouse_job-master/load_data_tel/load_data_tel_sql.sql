alter table analysis.mlp_promotion_coupon_encryption delete 
where coupon_code
in (SELECT coupon_code from analysis.mlp_promotion_coupon_encryption_tmp);

insert into analysis.mlp_promotion_coupon_encryption 
SELECT * from analysis.mlp_promotion_coupon_encryption_tmp where toDate(dt)=toDate(now()) ;
