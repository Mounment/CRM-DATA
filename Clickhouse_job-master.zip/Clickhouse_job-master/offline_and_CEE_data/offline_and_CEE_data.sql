--offline new member
--delete historical data
truncate table datamart.dm_offline_new_member;

--insert new data
-- correct b.username=c.bind_tel after mobile fixed.
insert into datamart.dm_offline_new_member 
with tmp1 as (select toString(toDate(a.payment_date1)) as date
              ,a.shop_name as shop_name
              ,count(distinct a.buyer_id) as new_member_cnt
              ,count(distinct case when d.id is NULL then NULL else c.bind_tel end) as binded_member_cnt
              ,count(distinct case when d.id is NULL then NULL else c.id end) as binded_coupon_cnt
         from datamart.V_Orders_Count a
         join raw_data.mlp_ouser_u_user b
         on a.buyer_id = b.id
         left join raw_data.mlp_promotion_coupon c
         on b.username = c.bind_tel
         and c.id not in (select id from raw_data.mlp_promotion_coupon p 
         where (p.theme_title like '%新用户券%' or p.theme_title like '%周末做啥%' or p.theme_title like '%地推拉新新人券%'))
         left join raw_data.mlp_promotion_coupon_theme d
         on c.coupon_theme_id = d.id
         and coupon_use_type = 1
         where (a.payment_date1 between date_add(day,-30,now()) and now())
         and source_type in ('MOBILE_POS', 'POS', 'SCAN_QR_CODE')
         and ROW_NUMBER=1
         group by toString(toDate(a.payment_date1)), a.shop_name)
,tmp2 as (select toString(toDate(payment_date1)) as date
                 ,merchant_code
                 ,shop_name
                 ,sum(case when buyer_id is null then 1 else 0 end) as non_member_trans
                 ,sum(case when buyer_id is null then 0 else 1 end) as member_trans
          from datamart.V_Order_Header
          where (payment_date1 between date_add(day,-30,now()) and now())
          and source_type in ('MOBILE_POS', 'POS', 'SCAN_QR_CODE')
          group by toString(toDate(payment_date1)), shop_name, merchant_code)
         select tmp2.date
                ,tmp2.merchant_code
                ,tmp2.shop_name
                ,tmp2.non_member_trans
                ,tmp2.member_trans
                ,tmp1.new_member_cnt
                ,tmp1.binded_member_cnt
                ,tmp1.binded_coupon_cnt
                ,now()
         from tmp1
         join tmp2
         on tmp1.date = tmp2.date
         and tmp1.shop_name = tmp2.shop_name;

--CEE
--delete historical data
truncate table datamart.dm_cee_tracking;

--insert new data
insert into datamart.dm_cee_tracking 
with tmp1 as (select replace(a.name,'-首页','') as cee_name
                   , toDate(d.bind_time) as date
                   , count(distinct d.id) as coupon_binded
                   , count(distinct d.bind_tel) as coupon_member_cnt
             from datamart.channel_activity a
             left join datamart.register_new_mb_txn b
                   on a.activity_id = b.activity_id
             left join raw_data.mlp_ouser_u_user c
                   on b.user_id = c.id
             left join raw_data.mlp_promotion_coupon d
                   on c.username = d.bind_tel
             left join raw_data.mlp_promotion_coupon_theme e
                   on d.coupon_theme_id = e.id
             where b.create_date between dateadd(day,-30,now()) and now()
             and d.bind_time between dateadd(day,-30,now()) and now()
             and a.ad_channel_name = 'CEE'
             and e.coupon_use_type = 1
             group by replace(a.name,'-首页','')
             ,toDate(d.bind_time))
,tmp2 as (select replace(name,'-首页','') as cee_name
                 ,check_date as date
                 ,sum(ifNull(new_register_members,0)) as registerd_member_cnt
                 ,sum(ifNull(new_member_cnt,0)) as new_member_cnt
                 ,round(sum(ifNull(new_member_payment_amt,0)),2) as new_member_payment
                 ,sum(ifNull(new_member_txn_cnt,0)) as new_member_txn
                 ,sum(case when isFinite(ifNull(new_member_payment_amt,0)/new_member_txn_cnt)=0 then 0 
                      else round(ifNull(new_member_payment_amt,0)/new_member_txn_cnt,2)  end) as basket_size
           from datamart.bi_activity_summary
           where check_date between date_add(day,-30,now()) and now()
           and ad_channel_name = 'CEE'
           and name like 'CEE%'
           group by replace(name,'-首页','')
           , check_date)
select tmp2.date
       ,tmp2.cee_name
       ,tmp2.registerd_member_cnt as registerd_member_cnt
       ,tmp2.new_member_cnt as new_member_cnt
       ,tmp2.new_member_payment as new_member_payment
       ,tmp2.new_member_txn
       ,tmp2.basket_size
       ,ifNull(tmp1.coupon_member_cnt,0) as binded_member_cnt
       ,ifNull(tmp1.coupon_binded,0) as coupon_binded
       ,now()
from tmp2
left join tmp1
on tmp2.cee_name = tmp1.cee_name
and tmp2.date = tmp1.date
/*group by tmp2.cee_name
union all
select 'Grand Total'
, sum(tmp2.registerd_member_cnt) as registerd_member_cnt
, sum(tmp2.new_member_cnt) as new_member_cnt
, sum(tmp2.new_member_payment) as new_member_payment
, sum(ifNull(tmp1.coupon_member_cnt,0)) as binded_member_cnt
, sum(cast(ifNull(tmp1.coupon_member_cnt,0) as numeric))/sum(cast(tmp2.new_member_cnt as numeric)) as coupon_binded_rate
, now()
from tmp2
left join tmp1
on tmp2.cee_name = tmp1.cee_name
and tmp2.date = tmp1.date*/;

