insert into datamart.experience_refund
with tmp as
(select order_code, create_time, refund_time, user_id, ifNull(sys_source, 'O2O') as source_type,
case when toInt64(return_reason_id) in (9, 11, 0) then 0 else 1 end as return_satisfaction,
case when toInt64(return_reason_id) = 9 then 1 else 0 end as return_oos,
case when toInt64(return_reason_id) in (11, 0) then 1 else 0 end as return_cancellation,
case when toInt64(return_reason_id) in (9, 11, 0) then 0 else actual_return_amount end as return_satisfaction_amt,
case when toInt64(return_reason_id) = 9 then actual_return_amount else 0 end as return_oos_amt,
case when toInt64(return_reason_id)  in (11, 0) then actual_return_amount else 0 end as return_cancellation_amt,
case when toInt64(return_reason_id) in (3,6,9) then 0 when return_status = 8 then 2 else 1 end as return_status,
--0-rejected, 1-in process, 2-approved
refund_status --1-no refund, 2--refunded
from raw_data.mlp_oms_so_return
where toDate(create_time) = toDate(date_add(day, -1, now())))
select order_code, min(source_type) as source_type, min(create_time) as create_time, max(refund_time) as refund_time, min(user_id) as user_id, 
sum(return_satisfaction) as return_satisfaction, sum(return_oos) as return_oos, sum(return_cancellation) as return_cacellation,
sum(return_satisfaction_amt) as return_satisfaction_amt, sum(return_oos_amt) as return_oos_amt, sum(return_cancellation_amt) as return_cacellation_amt,
max(return_status) as return_status, max(refund_status) as refund_status
,toDateTime(now()) as insert_time
from tmp
group by order_code;
