--t27
--cherry_picker| 优惠券交易之后30天内没有非优惠券消费的客户
insert into datamart.T_F_MemberTag
select 
buyer_id
,'Coupon' as TagKey
,'Cherry_picker'as TagValue
,today() as BeginDate
,today()+6 as EndDate
,toDateTime(now()) as insert_time
from datamart.coupon_dimension a
where create_date = (select max(create_date)from datamart.coupon_dimension)
and aft_30 = 0;
