--t26
--优惠券订单渗透率(x_cp)小于10%的用户 且 券后自然订单增长(y_lift)小于10%
insert into datamart.T_F_MemberTag
select 
buyer_id
,'Coupon' as TagKey
,'Coupon_no_need'as TagValue
,today() as BeginDate
,today()+6 as EndDate
,toDateTime(now()) as insert_time
from datamart.coupon_dimension a
where create_date = (select max(create_date)from datamart.coupon_dimension)
and x_cp <0.1
and y_lift <0.1;