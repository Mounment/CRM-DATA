insert into datamart.T_F_MemberTag
select o.id as buyer_id
,'Redemption' as TagKey
,'Coupon' as TagValue
,toDate(a.start_time) as BeginDate
,today()-1  as EndDate
,toDateTime(now()) as insert_time
from raw_data.mlp_promotion_coupon a
inner join raw_data.mlp_promotion_coupon_theme b on a.coupon_theme_id=b.id
inner join datamart.u_user_2 uu on a.bind_tel=uu.mobile
inner join raw_data.mlp_ouser_u_user o on uu.id=o.id
--inner join raw_data.mlp_ouser_u_user o on a.bind_tel=o.mobile
where a.start_time <= today()--优惠券已生效且在有效期内
and a.end_time >= today()
and a.status=1 --优惠券尚未使用
and b.coupon_use_type = '1' -- CRM-新人券
group by o.id, toDate(a.start_time);
