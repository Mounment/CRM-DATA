--t25
--Redemption--Coupon --Weekly Refresh(Tuesday/ Friday)
-- customer who got the activated crm coupon, the corresponding merchant code of the coupon
insert into datamart.T_F_MemberTag
select o.id as buyer_id
,'Coupon_new' as TagKey
,m.merchant_code as TagValue
,toDate(a.start_time) as BeginDate
,today()-1  as EndDate
,toDateTime(now()) as insert_time
from raw_data.mlp_promotion_coupon a
inner join raw_data.mlp_promotion_coupon_theme b on a.coupon_theme_id=b.id and b.coupon_use_type = '1' -- CRM-新人券
inner join datamart.u_user_2 uu on a.bind_tel=uu.mobile
inner join raw_data.mlp_ouser_u_user o on uu.id=o.id
--inner join raw_data.mlp_ouser_u_user o on a.bind_tel=o.mobile
left join raw_data.mlp_promotion_mkt_use_rule p on a.coupon_theme_id=p.theme_ref and rule_type='1'-----limit_ref为门店字段
left join raw_data.mlp11_merchant_merchant m on p.limit_ref=m.id
where a.start_time <= today() --优惠券已生效且在有效期内
and a.end_time >= today()
and a.status=1 --可使用的优惠券
group by o.id,m.merchant_code,toDate(a.start_time);
