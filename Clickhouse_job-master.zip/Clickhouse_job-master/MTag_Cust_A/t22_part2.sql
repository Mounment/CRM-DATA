--t22
--Occupation--Student / Adhoc Refresh
-- all the student customers: using talking data as source
insert into datamart.T_F_MemberTag
select id as buyer_id
,'Occupation' as TagKey
,'Student' as TagValue
,toDate(refresh_date) as BeginDate
,today() as EndDate
,toDateTime(now()) as insert_time
from
(select c.id as id,a.refresh_date as refresh_date
from datamart.external_tag a
inner join analysis.mobile_device_id b on a.idfa= b.IDFA 
inner join datamart.u_user_2 uu on b.mobile=uu.mobile
inner join raw_data.mlp_ouser_u_user c on uu.id=c.id
--inner join raw_data.mlp_ouser_u_user c on b.mobile = c.mobile
where tag_code = toInt64('030301') --Occupation is student
UNION DISTINCT 
select raw_data.mlp_ouser_u_user.id as id, datamart.external_tag.refresh_date as refresh_date
from datamart.external_tag a
inner join analysis.mobile_device_id b on datamart.external_tag.imei = analysis.mobile_device_id.IMEI  
inner join datamart.u_user_2 uu on b.mobile=uu.mobile
inner join raw_data.mlp_ouser_u_user c on uu.id=c.id
--inner join raw_data.mlp_ouser_u_user c on analysis.mobile_device_id.mobile = raw_data.mlp_ouser_u_user.mobile
where a.tag_code = toInt64('030301') --Occupation is student
)tp;
