drop table if EXISTS datamart.experience_delivery no delay;

CREATE TABLE datamart.experience_delivery(
	payment_date Nullable(DateTime),
	order_code Nullable(String),
	buyer_id Nullable(Int64),
	order_status Nullable(Int64),
	error_status Nullable(Int64),
	source_type String,
	delivery_now Nullable(Int64),
	expect_receive_date_start Nullable(DateTime),
	expect_receive_date_end Nullable(DateTime),
	estimated_time_of_arrival Nullable(String),
	order_amount Nullable(decimal(18, 2)),
	operate_content Nullable(String),
	operate_no Nullable(Int64),
	receive_time Nullable(DateTime),
	diff_dfs_mins Nullable(Int64),
	diff_b2c_days Nullable(Int64),
	actual_return_amount Nullable(decimal(38, 3)),
	delivery_result Nullable(String),
	delivery_sub_result Nullable(String),
	create_time DateTime
)ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.experience_delivery',
 '{replica}')
ORDER BY source_type ;


insert into datamart.experience_delivery
with s as
(
select 
s.order_payment_confirm_date
,s.order_code
,s.user_id
,s.order_status --in('25','35')
,s.error_status  -- 0 okay, 99: 蜂鸟拒单，199：蜂鸟延迟
,s.order_delivery_method_id
,s.delivery_now -- = 0 预约单(non-instant), 1 即时单
,s.expect_receive_date_start
,s.expect_receive_date_end
,s.estimated_time_of_arrival
,s.order_amount
from raw_data.mlp_oms_so s where toDate(s.order_payment_confirm_date)>='2020-08-01'
),
t as
(
select 
order_code
,create_time
,operate_content
,operate_no
from
(select 
order_code
,create_time
,operate_content
,operate_no
,row_number()over(partition by order_code
order by case when (operate_content like '%已送到%' or operate_content like '%订单已出库%') and operate_no=21 then 1 end desc,create_time desc)cn
from raw_data.mlp_oms_do_track)m
where cn = 1
),
r as
(
select 
order_code
, sum(actual_return_amount)as actual_return_amount
from raw_data.mlp_oms_so_return
group by order_code
)
select m1.*
,case when error_status in ('99','199') and actual_return_amount>= order_amount then 'O2O_DFS_fail'--'11'-- fully failed
when order_status in ('25','35') then 'success'--'00' --success
when order_status in ('34') and error_status='0' then 'order_cancelled' -- customer cancelled*
end as delivery_result
,case when order_status in('25','35') and source_type = 'O2O_DFS_fnps'  and diff_dfs_mins<=15 then 'success<=15'--'01' -- dfs success and no delay
when order_status in('25','35')and source_type = 'O2O_DFS_fnps'and diff_dfs_mins>=15 and diff_dfs_mins <30 then '15<success_delay<30'--011' -- dfs success and s_delay
when order_status in('25','35')and source_type = 'O2O_DFS_fnps' and diff_dfs_mins>=30 and diff_dfs_mins <60 then '30<=success_delay<60'--'012' --dfs success and s_m_delay
when order_status in('25','35')and source_type = 'O2O_DFS_fnps' and diff_dfs_mins>=60 and diff_dfs_mins <120 then '60<=success_delay<120'--'013' --dfs success and s_s_delay
when order_status in('25','35')and source_type = 'O2O_DFS_fnps' and diff_dfs_mins >=120 then 'success_delay>=120'--'014' --dfs success and s_m_delay
when order_status in ('25','35') and source_type = 'O2O_DFS_fnps'and error_status in ('99','199') then 'success_ss' -- 门店闪送
when order_status in ('25','35') and source_type = 'O2O_DFS_fnps' and error_status in ('99','199','0') and operate_no ='21' and operate_content like '订单已出库'
then 'success_mdzps'
when order_status in('25','35')and source_type = 'O2O_B2C' and diff_b2c_days >1 then 'B2C_Success_TBC' -- b2c success and delay
end as delivery_sub_result
,now() as create_time
--into dbo.experience_delivery
from
(select
m.*
,case when source_type = 'O2O_DFS_fnps' and delivery_now = 0 then dateDiff(minute,expect_receive_date_end,receive_time)
when source_type = 'O2O_DFS_fnps' and delivery_now = 1 then dateDiff(minute,payment_date,receive_time)-60
end as diff_dfs_mins
,case when source_type = 'O2O_B2C' then dateDiff(dd,payment_date,receive_time) end as diff_b2c_days
,actual_return_amount
from
(select
s.order_payment_confirm_date as payment_date
,s.order_code
,s.user_id as buyer_id
,s.order_status --in('25','35')
,s.error_status  -- 0 okay, 99: 蜂鸟拒单，199：蜂鸟延迟
,case when s.order_delivery_method_id='998' then 'O2O_DFS_mdzps' --'美团，达达，10km' s.sys_source='WX_O2O' and s.merchant_id != 1784079900000000 then 'O2O_DFS' --'WX_O2O' ---蜂鸟配送--!= 1784079900000000 排除B2C
when s.order_delivery_method_id='4640' then 'O2O_DFS_fnps' --s.sys_source='WX_O2O' and s.merchant_id = 1784079900000000 then 'O2O_B2C'
when s.order_delivery_method_id='10000'  then 'O2O_B2C'
else 'others' END as source_type
,s.delivery_now -- = 0 预约单(non-instant), 1 即时单
,s.expect_receive_date_start
,s.expect_receive_date_end
,s.estimated_time_of_arrival
,s.order_amount
,t.operate_content
,t.operate_no
,case when s.order_delivery_method_id ='4640' and t.operate_no=21 and t.operate_content like '%已送到%' then t.create_time end as receive_time
from s
left join t on s.order_code=t.order_code)m
left join  r -- group by for duplication
on m.order_code = r.order_code)m1;
--完成测试

--add by Shirley 2021-07-08
insert into datamart.experience_delivery
with s as(select s.order_payment_confirm_date
				,s.order_code
				,s.user_id
				,s.order_status --'1070'：已签收,'1999'：已完成
				,ifNull(s.error_status,0) error_status  -- 0 okay, 99: 蜂鸟拒单，199：蜂鸟延迟
				,s.order_delivery_method_id
				,s.delivery_now -- = 0 预约单(non-instant), 1 即时单
				,s.expect_receive_date_start
				,s.expect_receive_date_end
				,s.estimated_time_of_arrival
				,s.order_amount
				,s.order_receive_date
			from raw_data.mlp_oms_so s),
r as(select order_code
			, sum(actual_return_amount)as actual_return_amount
	from raw_data.mlp_oms_so_return
	group by order_code)
select m1.*
		,case when error_status in ('99','199') and actual_return_amount>= order_amount then 'O2O_DFS_fail'--'11'-- fully failed
				when order_status in ('1070','1999') then 'success'--'00' --success
				when order_status in ('9000') and error_status='0' then 'order_cancelled' -- customer cancelled*
		end as delivery_result
		,case when order_status in('1070','1999') and source_type = 'O2O_DFS_fnps'  and diff_dfs_mins<=15 then 'success<=15'--'01' -- dfs success and no delay
				when order_status in('1070','1999')and source_type = 'O2O_DFS_fnps'and diff_dfs_mins>=15 and diff_dfs_mins <30 then '15<success_delay<30'--011' -- dfs success and s_delay
				when order_status in('1070','1999')and source_type = 'O2O_DFS_fnps' and diff_dfs_mins>=30 and diff_dfs_mins <60 then '30<=success_delay<60'--'012' --dfs success and s_m_delay
				when order_status in('1070','1999')and source_type = 'O2O_DFS_fnps' and diff_dfs_mins>=60 and diff_dfs_mins <120 then '60<=success_delay<120'--'013' --dfs success and s_s_delay
				when order_status in('1070','1999')and source_type = 'O2O_DFS_fnps' and diff_dfs_mins >=120 then 'success_delay>=120'--'014' --dfs success and s_m_delay
				when order_status in ('1070','1999') and source_type = 'O2O_DFS_fnps'and error_status in ('99','199') then 'success_mdzps' -- 门店自配送
				--when order_status in ('1070','1999') and source_type = 'O2O_DFS_fnps' and error_status in ('99','199','0') and delivery_method is null  and operate_no ='21' and operate_content like N'订单已出库' then 'success_mdzps'
				when order_status in('1070','1999')and source_type = 'O2O_B2C' and diff_b2c_days >1 then 'B2C_Success_TBC' -- b2c success and delay
		end as delivery_sub_result
		,now() as create_time
from(select m.*
			,case when source_type = 'O2O_DFS_fnps' and delivery_now = 0 then dateDiff(minute,expect_receive_date_end,receive_time)
					when source_type = 'O2O_DFS_fnps' and delivery_now = 1 then dateDiff(minute,payment_date,receive_time)-60
			end as diff_dfs_mins
			,case when source_type = 'O2O_B2C' then dateDiff(dd,payment_date,receive_time) end as diff_b2c_days
			,actual_return_amount
	from(select s.order_payment_confirm_date as payment_date
				,s.order_code
				,s.user_id as buyer_id
				,s.order_status --in('1070','1999')
				,s.error_status  -- null okay, 99: 蜂鸟拒单，199：蜂鸟延迟
				,case when s.order_delivery_method_id='998' then 'O2O_DFS_mdzps' --'美团，达达，10km' s.sys_source='WX_O2O' and s.merchant_id != 1784079900000000 then 'O2O_DFS' --'WX_O2O' ---蜂鸟配送--!= 1784079900000000 排除B2C
						when s.order_delivery_method_id='4640' then 'O2O_DFS_fnps' --s.sys_source='WX_O2O' and s.merchant_id = 1784079900000000 then 'O2O_B2C'
						when s.order_delivery_method_id='10000'  then 'O2O_B2C'
				else 'others' END as source_type
				,s.delivery_now -- = 0 预约单(non-instant), 1 即时单
				,s.expect_receive_date_start
				,s.expect_receive_date_end
				,s.estimated_time_of_arrival
				,s.order_amount
				,NULL AS operate_content
				,NULL AS operate_no
				,order_receive_date AS receive_time
		from s)m
	left join  r
		on m.order_code = r.order_code)m1;
--完成测试