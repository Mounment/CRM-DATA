insert into datamart.diamond_member_type
select user_id,
case when claim_channel = 1 then '消费满800' 
when claim_channel = 2 then '小程序积分兑换' 
when claim_channel = 3 then '公众号兑换' 
when claim_channel = 4 then '邀请用户' end,
toMonth(now()) as month, --钻石会员当月
toYear(now()) as year --钻石会员当年
from raw_data.mlp_ouser_aldi_member_benefit
where valid_month = toString(toYYYYMM(date_add(month,-1,now()))) --成为钻石会员的上一个月
and level_code = '1001'
