------StoredProcedure [dbo].[Proc_Total_Frequency_Basket_Size_Seg]
--TOTAL
------------------------------------------------------------------------------------------------------------------------
---- Recency Table #RA: buyer_id,recency, R
---- member last order
drop table if exists datamart.recency_temp1 no delay;
CREATE TABLE datamart.recency_temp1
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.recency_temp1',
 '{replica}')
ORDER BY tuple() AS
with date_add(DAY,-91,toDate(now())) as start,
         today()-1 as end 
select buyer_id
		,recency
		,days
		,row_number() over (order by days) as ranking
from (
select buyer_id
		,recency
		,Datediff(day,recency,end) days
from ( 
select buyer_id,order_code,recency,source_type
from (
select distinct buyer_id as buyer_id
	,pk_order_code as order_code
	,payment_date1 as recency
	,source_type as source_type
	,row_number () over (partition by buyer_id order by payment_date1 desc) rn
from datamart.V_Order_Header a
where buyer_id is not null
and ifNull(buyer_id,889) not in (select ifNull(buyer_id,889) 
from datamart.diamond_member_type 
where year = toYear(date_add(month,-1,end)) and month = toMonth(date_add(month,-1,end)))
and toDate(payment_date1) between start and end)
where rn=1 )
order by days asc);
-----------------------------------------------------------------------------Recency atrributes
drop table if exists datamart.recency_temp2 no delay;
CREATE TABLE datamart.recency_temp2
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.recency_temp2',
 '{replica}')
ORDER BY tuple() AS
with (select count(0) from datamart.recency_temp1 where days is not null) as recency_count1
select buyer_id
		,recency
		,days
		,(case when ranking <=  recency_count1/5 then 'R5'
			  when ranking > recency_count1/5 and ranking <= (2.0/5)*recency_count1 then 'R4'
			  when ranking > (2.0/5)*recency_count1 and ranking <= (3.0/5)*recency_count1 then 'R3' 
			  when ranking > (3.0/5)*recency_count1 and ranking <= (4.0/5)*recency_count1 then 'R2' 
			else 'R1'
		  end ) as R  
from datamart.recency_temp1;

---- Monetary Table #MA: buyer_id,Sales, M
---- member transaction counts
drop table if exists datamart.monetary_temp1 no delay;
CREATE TABLE datamart.monetary_temp1
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.monetary_temp1',
 '{replica}')
ORDER BY tuple() AS
with date_add(DAY,-91,toDate(now())) as start,
today()-1 as end 
select buyer_id
		,basket_size
		,row_number () over (order by basket_size desc )as ranking
from 
(
select buyer_id
,sum(payment_amt)/count(distinct pk_order_code) as basket_size
from datamart.V_Order_Header 
where buyer_id is not null
and ifNull(buyer_id,889) not in (select ifNull(buyer_id,889) from datamart.diamond_member_type where year = toYear(date_add(month,-1,end)) and month = toMonth(date_add(month,-1,end)))
and toDate(payment_date1) between start and end
group by buyer_id);

-----------------------------------------------------------------------------Recency atrributes
drop table if exists datamart.monetary_temp2 no delay;
CREATE TABLE datamart.monetary_temp2
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.monetary_temp2',
 '{replica}')
ORDER BY tuple() AS
with (select count(0) from datamart.monetary_temp1 where basket_size is not null ) as monetary_count1
 select buyer_id
		,basket_size
		,(case when ranking <=  monetary_count1/5 then 'M5'
			  when ranking > monetary_count1/5 and ranking <= (2.0/5)*monetary_count1 then 'M4'
			  when ranking > (2.0/5)*monetary_count1 and ranking <= (3.0/5)*monetary_count1 then 'M3' 
			  when ranking > (3.0/5)*monetary_count1 and ranking <= (4.0/5)*monetary_count1 then 'M2' 
			else 'M1'
		  end ) as M
from datamart.monetary_temp1;


---- Frequency Table #FrA: buyer_id,transactions, F
---- member transaction counts
drop table if exists datamart.frequency_temp1 no delay;
CREATE TABLE datamart.frequency_temp1
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.frequency_temp1',
 '{replica}')
ORDER BY tuple() AS
with date_add(DAY,-91,toDate(now())) as start,
today()-1 as end 
select buyer_id
		,transactions
		,row_number() over (order by transactions desc) as ranking
from (
select buyer_id
,count(pk_order_code) transactions
from datamart.V_Order_Header 
where buyer_id is not null
and ifNull(buyer_id,889) not in (select ifNull(buyer_id,889) from datamart.diamond_member_type where year = toYear(date_add(month,-1,end)) and month = toMonth(date_add(month,-1,end)))
and toDate(payment_date1) between start and end
group by buyer_id
)
where transactions is not null;

-----------------------------------------------------------------------------Recency atrributes
drop table if exists datamart.frequency_temp2 no delay;
CREATE TABLE datamart.frequency_temp2
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.frequency_temp2',
 '{replica}')
ORDER BY tuple() AS
with (select count(0) from datamart.frequency_temp1 where transactions is not null) as frequency_count1
select buyer_id
		,transactions
		,(case when ranking <=  frequency_count1/5 then 'F5'
			  when ranking > frequency_count1/5 and ranking <= (2.0/5)*frequency_count1 then 'F4'
			  when ranking > (2.0/5)*frequency_count1 and ranking <= (3.0/5)*frequency_count1 then 'F3' 
			  when ranking > (3.0/5)*frequency_count1 and ranking <= (4.0/5)*frequency_count1 then 'F2' 
			else 'F1'
		  end ) as F
from datamart.frequency_temp1;


-----------------------------------------------------------------------------
drop table if exists datamart.total_RFM_temp no delay;
CREATE TABLE datamart.total_RFM_temp
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.total_RFM_temp',
 '{replica}')
ORDER BY tuple() AS
select  rfm.buyer_id as buyer_id
		,recency
		,days
		,R
		,transactions
		,F
		,basket_size
		,M
		,trfm.txn_m4_cust_micro_seg as txn_m4_cust_micro_seg
		,vf.txn_m2_str_main as txn_m2_str_main
from (select *, 
		(case when R='R5'and F='F5' and M='M5' then 'Champions'
			  when R='R5'and F='F5' and M='M4' then 'Champions'
			  when R='R5'and F='F4' and M='M4' then 'Champions'
			  when R='R5'and F='F4' and M='M5' then 'Champions'
			  when R='R4'and F='F5' and M='M4' then 'Champions'
			  when R='R4'and F='F5' and M='M5' then 'Champions'
			  when R='R4'and F='F4' and M='M5' then 'Champions'
			  when R='R5'and F='F4' and M='M3' then 'LoyalCustomers'
			  when R='R4'and F='F4' and M='M4' then 'LoyalCustomers'
			  when R='R4'and F='F3' and M='M5' then 'LoyalCustomers'
			  when R='R3'and F='F5' and M='M5' then 'LoyalCustomers'
			  when R='R3'and F='F5' and M='M4' then 'LoyalCustomers'
			  when R='R3'and F='F4' and M='M5' then 'LoyalCustomers'
			  when R='R3'and F='F4' and M='M4' then 'LoyalCustomers'
			  when R='R3'and F='F3' and M='M5' then 'LoyalCustomers'
			  when R='R5'and F='F5' and M='M3' then 'Potential Loyalist'
			  when R='R5'and F='F5' and M='M1' then 'Potential Loyalist'
			  when R='R5'and F='F5' and M='M2' then 'Potential Loyalist'
			  when R='R5'and F='F4' and M='M1' then 'Potential Loyalist'
			  when R='R5'and F='F4' and M='M2' then 'Potential Loyalist'
			  when R='R5'and F='F3' and M='M3' then 'Potential Loyalist'
			  when R='R5'and F='F3' and M='M2' then 'Potential Loyalist'
			  when R='R5'and F='F3' and M='M1' then 'Potential Loyalist'
			  when R='R4'and F='F5' and M='M2' then 'Potential Loyalist'
			  when R='R4'and F='F5' and M='M1' then 'Potential Loyalist'
			  when R='R4'and F='F4' and M='M2' then 'Potential Loyalist'
			  when R='R4'and F='F4' and M='M1' then 'Potential Loyalist'
			  when R='R4'and F='F3' and M='M1' then 'Potential Loyalist'
			  when R='R4'and F='F5' and M='M3' then 'Potential Loyalist'
			  when R='R4'and F='F3' and M='M3' then 'Potential Loyalist'
			  when R='R4'and F='F3' and M='M2' then 'Potential Loyalist'
			  when R='R4'and F='F2' and M='M3' then 'Potential Loyalist'
			  when R='R3'and F='F5' and M='M3' then 'Potential Loyalist'
			  when R='R3'and F='F5' and M='M2' then 'Potential Loyalist'
			  when R='R3'and F='F5' and M='M1' then 'Potential Loyalist'
			  when R='R3'and F='F4' and M='M2' then 'Potential Loyalist'
			  when R='R3'and F='F4' and M='M1' then 'Potential Loyalist'
			  when R='R3'and F='F3' and M='M3' then 'Potential Loyalist'
			  when R='R3'and F='F2' and M='M3' then 'Potential Loyalist'

			  when R='R5'and F='F1' and M='M2' then 'New Customers'
			  when R='R5'and F='F1' and M='M1' then 'New Customers'
			  when R='R4'and F='F2' and M='M2' then 'New Customers'
			  when R='R4'and F='F2' and M='M1' then 'New Customers'
			  when R='R4'and F='F1' and M='M2' then 'New Customers'
			  when R='R4'and F='F1' and M='M1' then 'New Customers'
			  when R='R3'and F='F1' and M='M1' then 'New Customers'

			  when R='R5'and F='F2' and M='M5' then 'Promising'
			  when R='R5'and F='F2' and M='M4' then 'Promising'
			  when R='R5'and F='F2' and M='M3' then 'Promising'
			  when R='R5'and F='F2' and M='M2' then 'Promising'
			  when R='R5'and F='F2' and M='M1' then 'Promising'
			  when R='R5'and F='F1' and M='M5' then 'Promising'
			  when R='R5'and F='F1' and M='M4' then 'Promising'
			  when R='R5'and F='F1' and M='M3' then 'Promising'
			  when R='R4'and F='F2' and M='M5' then 'Promising'
			  when R='R4'and F='F2' and M='M4' then 'Promising'
			  when R='R4'and F='F1' and M='M3' then 'Promising'
			  when R='R4'and F='F1' and M='M4' then 'Promising'
			  when R='R4'and F='F1' and M='M5' then 'Promising'
			  when R='R3'and F='F1' and M='M5' then 'Promising'
			  when R='R3'and F='F1' and M='M4' then 'Promising'
			  when R='R3'and F='F1' and M='M3' then 'Promising'

			  when R='R5'and F='F3' and M='M5' then 'Customers Needing Attention'
			  when R='R5'and F='F3' and M='M4' then 'Customers Needing Attention'
			  when R='R4'and F='F4' and M='M3' then 'Customers Needing Attention'
			  when R='R4'and F='F3' and M='M4' then 'Customers Needing Attention'
			  when R='R3'and F='F4' and M='M3' then 'Customers Needing Attention'
			  when R='R3'and F='F3' and M='M4' then 'Customers Needing Attention'
			  when R='R3'and F='F2' and M='M5' then 'Customers Needing Attention'
			  when R='R3'and F='F2' and M='M4' then 'Customers Needing Attention'

			  when R='R3'and F='F3' and M='M1' then 'About To Sleep'
			  when R='R3'and F='F2' and M='M1' then 'About To Sleep'
			  when R='R3'and F='F1' and M='M2' then 'About To Sleep'
			  when R='R2'and F='F2' and M='M1' then 'About To Sleep'
			  when R='R2'and F='F1' and M='M3' then 'About To Sleep'
			  when R='R2'and F='F3' and M='M1' then 'About To Sleep'
			  when R='R2'and F='F4' and M='M1' then 'About To Sleep'
			  when R='R2'and F='F5' and M='M1' then 'About To Sleep'
			  when R='R2'and F='F5' and M='M5' then 'At Risk'
			  when R='R2'and F='F5' and M='M4' then 'At Risk'
			  when R='R2'and F='F4' and M='M5' then 'At Risk'
			  when R='R2'and F='F4' and M='M4' then 'At Risk'
			  when R='R2'and F='F5' and M='M3' then 'At Risk'
			  when R='R2'and F='F5' and M='M2' then 'At Risk'
			  when R='R2'and F='F4' and M='M3' then 'At Risk'
			  when R='R2'and F='F4' and M='M2' then 'At Risk'
			  when R='R2'and F='F3' and M='M5' then 'At Risk'
			  when R='R2'and F='F3' and M='M4' then 'At Risk'
			  when R='R2'and F='F2' and M='M5' then 'At Risk'
			  when R='R2'and F='F2' and M='M4' then 'At Risk'
			  when R='R1'and F='F5' and M='M3' then 'At Risk'
			  when R='R1'and F='F5' and M='M2' then 'At Risk'
			  when R='R1'and F='F4' and M='M5' then 'At Risk'
			  when R='R1'and F='F4' and M='M3' then 'At Risk'
			  when R='R1'and F='F4' and M='M2' then 'At Risk'
			  when R='R1'and F='F3' and M='M5' then 'At Risk'
			  when R='R1'and F='F3' and M='M4' then 'At Risk'
			  when R='R1'and F='F3' and M='M3' then 'At Risk'
			  when R='R1'and F='F2' and M='M5' then 'At Risk'
			  when R='R1'and F='F2' and M='M4' then 'At Risk'
			  when R='R1'and F='F5' and M='M5' then 'Can’t Lose Them'
			  when R='R1'and F='F5' and M='M4' then 'Can’t Lose Them'
			  when R='R1'and F='F4' and M='M4' then 'Can’t Lose Them'
			  when R='R2'and F='F1' and M='M4' then 'Can’t Lose Them'
			  when R='R2'and F='F1' and M='M5' then 'Can’t Lose Them'
			  when R='R1'and F='F1' and M='M5' then 'Can’t Lose Them'
			  when R='R1'and F='F1' and M='M4' then 'Can’t Lose Them'
			  when R='R1'and F='F1' and M='M3' then 'Can’t Lose Them'
			  when R='R3'and F='F3' and M='M2' then 'Hibernating'
			  when R='R3'and F='F2' and M='M2' then 'Hibernating'
			  when R='R2'and F='F3' and M='M1' then 'Hibernating'
			  when R='R2'and F='F4' and M='M1' then 'Hibernating'
			  when R='R2'and F='F5' and M='M1' then 'Hibernating'
			  when R='R2'and F='F3' and M='M3' then 'Hibernating'
			  when R='R2'and F='F3' and M='M2' then 'Hibernating'
			  when R='R2'and F='F2' and M='M3' then 'Hibernating'
			  when R='R2'and F='F2' and M='M2' then 'Hibernating'
			  when R='R1'and F='F3' and M='M2' then 'Hibernating'
			  when R='R1'and F='F2' and M='M3' then 'Hibernating'
			  when R='R1'and F='F2' and M='M2' then 'Hibernating'
			  when R='R2'and F='F1' and M='M2' then 'Hibernating'
			  when R='R2'and F='F1' and M='M1' then 'Hibernating'
			  when R='R1'and F='F1' and M='M1' then 'lost'
			  when R='R1'and F='F1' and M='M2' then 'lost'
			  when R='R1'and F='F2' and M='M1' then 'lost'
			  when R='R1'and F='F3' and M='M1' then 'lost'
			  when R='R1'and F='F4' and M='M1' then 'lost'
			  when R='R1'and F='F5' and M='M1' then 'lost'
		else 'NA' end ) as score	
from (select  a.buyer_id as buyer_id
		,recency
		,days
		,R
		,transactions
		,F
		,basket_size
		,M
from datamart.recency_temp2 a, datamart.frequency_temp2 b, datamart.monetary_temp2 c
where a.buyer_id=b.buyer_id 
and a.buyer_id=c.buyer_id)) rfm
left join model.m4_trmf_seg_final as trfm
	on rfm.buyer_id=trfm.buyer_id
left join model.m_variable_final as vf
	on trfm.buyer_id=vf.buyer_id;
	
	
drop table if exists datamart.total_RFM_basket_size no delay;
CREATE TABLE datamart.total_RFM_basket_size
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.total_RFM_basket_size',
 '{replica}')
ORDER BY tuple() AS
with date_add(DAY,-91,toDate(now())) as start,
today()-1 as end 
select a.*
,b.item_category_name as cat1
,'-----------no tag----------' as F_tag
,'-----------no tag----------' as BS_tag
,today() as refresh_date
from datamart.total_RFM_temp a
left join datamart.cat_f_preference b
on toString(a.buyer_id)=b.buyer_id
and b.cutoff = end
and b.F_DA_rank=1;
-----------------------------------------------------------------------------	
--FBS_tag
alter table datamart.total_RFM_basket_size UPDATE   F_tag = '1-2',BS_tag = '0-45'
			WHERE transactions < 3
			AND basket_size <= 45;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '1-2',BS_tag = '45.1-70'
			WHERE transactions < 3
			AND basket_size > 45 and basket_size <= 70;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '1-2',BS_tag = '70.1-100'
			WHERE transactions < 3
			AND basket_size > 70 and basket_size <= 100;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '1-2',BS_tag = '100+'
			WHERE transactions < 3
			AND basket_size > 100;

alter table datamart.total_RFM_basket_size UPDATE    F_tag = '3-6',BS_tag = '0-45'
			WHERE transactions between 3 and 6
			AND basket_size <= 45;
			
alter table datamart.total_RFM_basket_size UPDATE   F_tag = '3-6',BS_tag = '45.1-70'
			WHERE transactions between 3 and 6
			AND basket_size > 45 and basket_size <= 70;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '3-6',BS_tag = '70.1-100'
			WHERE transactions between 3 and 6
			AND basket_size > 70 and basket_size <= 100;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '3-6',BS_tag = '100+'
			WHERE transactions between 3 and 6
			AND basket_size > 100;

alter table datamart.total_RFM_basket_size UPDATE    F_tag = '7-12',BS_tag = '0-45'
			WHERE transactions between 7 and 15
			AND basket_size <= 45;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '7-12',BS_tag = '45.1-70'
			WHERE transactions between 7 and 15
			AND basket_size > 45 and basket_size <= 70;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '7-12',BS_tag = '70.1-100'
			WHERE transactions between 7 and 15
			AND basket_size > 70 and basket_size <= 100;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '7-12',BS_tag = '100+'
			WHERE transactions between 7 and 15
			AND basket_size > 100;

alter table datamart.total_RFM_basket_size UPDATE    F_tag = '12+',BS_tag = '0-45'
			WHERE transactions > 15
			AND basket_size <= 45;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '12+',BS_tag = '45.1-70'
			WHERE transactions > 15
			AND basket_size > 45 and basket_size <= 70;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '12+',BS_tag = '70.1-100'
			WHERE transactions > 15
			AND basket_size > 70 and basket_size <= 100;
			
alter table datamart.total_RFM_basket_size UPDATE    F_tag = '12+',BS_tag = '100+'
			WHERE transactions > 15
			AND basket_size > 100;
			
