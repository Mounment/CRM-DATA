drop table if exists datamart.cat_f_tmp1 no delay;
CREATE TABLE datamart.cat_f_tmp1
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.cat_f_tmp1',
 '{replica}')
ORDER BY tuple() AS
with date_add(DAY,-90,toDate(now())) as start,
today()-1 as end,
tmp1 as (select 
buyer_id
,item_category_name
,count(distinct order_code) as cat_F
,toFloat32(0.0) as score
,toInt32(0) as F
,toFloat32(0) as T_cat_score
,toFloat32(0) as F_score
from raw_data.ec_sale_order_product 
WHERE payment_date is not null and buyer_id is NOT NULL 
AND toDate(payment_date) between start and end 
and item_name_zh not like '%购物袋%shopping%bag%'
group by item_category_name,buyer_id),
tmp2 as (select 
buyer_id
,count(distinct order_code) as F
from raw_data.ec_sale_order_product 
WHERE payment_date is not null and buyer_id is NOT NULL 
and item_name_zh not like '%购物袋%shopping%bag%'
and toDate(payment_date) between start and end 
group by  buyer_id)
SELECT 
tmp1.buyer_id,
tmp1.item_category_name ,
tmp1.cat_F,
round(tmp1.cat_F/(tmp2.F *1.0),3) as score ,
tmp2.F as F,
tmp1.T_cat_score ,
tmp1.F_score 
from tmp1 left join tmp2 on tmp1.buyer_id =tmp2.buyer_id;

drop table if exists datamart.cat_f_tmp2 no delay;
CREATE TABLE datamart.cat_f_tmp2
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.cat_f_tmp2',
 '{replica}')
ORDER BY tuple() AS
with tmp3 as (select distinct datamart.cat_f_tmp1.item_category_name, sum(datamart.cat_f_tmp1.cat_F) as cat_F, sum(datamart.cat_f_tmp1.F) as F, round(sum(datamart.cat_f_tmp1.cat_F)/(sum(datamart.cat_f_tmp1.F)*1.0),3) as T_cat_score 
from datamart.cat_f_tmp1 group by item_category_name)
SELECT 
datamart.cat_f_tmp1.buyer_id,
datamart.cat_f_tmp1.item_category_name ,
datamart.cat_f_tmp1.cat_F,
datamart.cat_f_tmp1.score ,
datamart.cat_f_tmp1.F,
tmp3.T_cat_score as T_cat_score
from datamart.cat_f_tmp1 left join tmp3 on datamart.cat_f_tmp1.item_category_name=tmp3.item_category_name;

drop table if exists datamart.cat_f_tmp3 no delay;
CREATE TABLE datamart.cat_f_tmp3
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/cat_f_tmp3',
 '{replica}')
ORDER BY tuple() AS
SELECT 
datamart.cat_f_tmp2.buyer_id,
datamart.cat_f_tmp2.item_category_name ,
datamart.cat_f_tmp2.cat_F,
datamart.cat_f_tmp2.score ,
datamart.cat_f_tmp2.F as F,
datamart.cat_f_tmp2.T_cat_score ,
case when datamart.cat_f_tmp2.T_cat_score = 0 then 0 else round(datamart.cat_f_tmp2.score/datamart.cat_f_tmp2.T_cat_score,3) end as F_score
from datamart.cat_f_tmp2;

drop table if exists datamart.cat_f_tmp4 no delay;
CREATE TABLE datamart.cat_f_tmp4
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.cat_f_tmp4',
 '{replica}')
ORDER BY tuple() AS
select 
datamart.cat_f_tmp3.buyer_id,
datamart.cat_f_tmp3.item_category_name, 
datamart.cat_f_tmp3.F, 
datamart.cat_f_tmp3.cat_F,
datamart.cat_f_tmp3.score as cat_share_score,
datamart.cat_f_tmp3.T_cat_score,
datamart.cat_f_tmp3.F_score as DA_F_score,
row_number()over(partition by datamart.cat_f_tmp3.buyer_id order by datamart.cat_f_tmp3.score desc ) as F_share_rank, 
row_number()over(partition by datamart.cat_f_tmp3.buyer_id order by datamart.cat_f_tmp3.F_score desc ) as F_DA_rank
From datamart.cat_f_tmp3;

insert into datamart.cat_f_preference
select today()-1 as cutoff,* ,toDateTime(now()) as insert_time
from datamart.cat_f_tmp4;
