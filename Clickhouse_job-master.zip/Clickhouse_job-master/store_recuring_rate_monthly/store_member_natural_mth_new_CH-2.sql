drop table if exists datamart.store_member_natural_mth_new no delay;
CREATE TABLE datamart.store_member_natural_mth_new
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.store_member_natural_mth_new',
 '{replica}')
ORDER BY tuple() AS
with Cust_Reg as(
select Buyer_ID,Merchant_code,Store_Open_Date,Reg_week,Reg_month,Reg_year,payment_date as Reg_store_date
from(
select 
      ord.buyer_id as Buyer_ID,
      ord.merchant_code as Merchant_code,
      mch.open_date as Store_Open_Date,
      ord.P_Week as Reg_week,
      ord.P_month as Reg_month,
      ord.P_Year as Reg_year,
      ord.payment_date1 as payment_date,
      row_number() over (partition by ord.buyer_id,ord.merchant_code order by ord.payment_date1) as Rank_By_Store
from  datamart.merchant mch  
inner join datamart.V_Orders_Count ord on mch.merchant_code=ord.merchant_code 
where toDateTime(mch.open_date) <=ord.payment_date1 
and mch.open_date is not null and mch.open_date is not null
and toDate(ord.payment_date1) < toStartOfMonth(now())
) t where t.Rank_By_Store=1
),
/*
步骤一：创建临时table-Cust_reg:
1. 从Variable 客户第一次消费的店客户表中取出：每个客户注册的store，日期，week，month等等信息
1001099601000010,1002,2019-06-07,23,6,2019,2019-06-07 16:00:41.000
1001100002000004,1001,2019-06-07,23,6,2019,2019-06-07 08:28:54.000
1001101201000000,1002,2019-06-07,23,6,2019,2019-06-07 13:10:39.000
*/
txn_all as (
select cu.Buyer_ID,cu.Merchant_code,cu.Reg_month,cu.Reg_year,ord.P_month,ord.P_Year
from Cust_Reg cu inner join datamart.V_Orders_Count ord on cu.Buyer_ID=ord.buyer_id and cu.Merchant_code=ord.merchant_code
where toDateTime(cu.Store_Open_Date)<=ord.payment_date1
and toDate(ord.payment_date1) < toStartOfMonth(now())
group by cu.Buyer_ID,cu.Merchant_code,cu.Reg_month,cu.Reg_year,ord.P_month,ord.P_Year
),
/*
步骤二：创建临时表Txn_All,利用第一步生成的数据：以客户维度-门店信息
在交易表ec.dbo.v_orders_count中找出每个月每个人消费的记录，一个月取一条数据（group by的作用）
--去除当前月，因为当前月还没有结束，统计不完整
*/
month_new_member_count as(
select 
      Merchant_code,
      case when Reg_month <10 then concat(toString(Reg_year),'0',toString(Reg_month)) else concat(toString(Reg_year),toString(Reg_month)) end as Reg_Month,
	  case when P_month <10 then concat(toString(P_Year),'0',toString(P_month)) else concat(toString(P_Year),toString(P_month)) end as Repurchase_Month,  
      count(Buyer_ID) as cnt 
from txn_all 
where concat(toString(Reg_year),toString(Reg_month))=concat(toString(P_Year),toString(P_month))
group by Merchant_code,Reg_month,Reg_year,P_month,P_Year  
),
/*
步骤三：
第二步生成的表中找出每个月每个门店注册的人数，规则：当一个人注册年月和消费年月相同，则是在本月注册。
*/
all_repurchase_list as(
select 
      Merchant_code,
      case when Reg_month <10 then concat(toString(Reg_year),'0',toString(Reg_month)) else concat(toString(Reg_year),toString(Reg_month)) end as mon,
      Reg_year as Year_num,Reg_month as month_num,
	  case when P_month <10 then concat('Y',toString(P_Year),'_M','0',toString(P_month)) else concat('Y',toString(P_Year),'_M',toString(P_month)) end as Repurchase_Month,
      count(Buyer_ID) as cnt  
from txn_all 
where concat(toString(Reg_year),toString(Reg_month))<>concat(toString(P_Year),toString(P_month)) 
group by Merchant_code,Reg_month,Reg_year,P_month,P_Year  
/*
步骤四：
计算出按照store层面每个注册年月后每个月份的复购人数，只要注册月份之后有购买记录就是复购
*/
UNION distinct
select Merchant_code,
      case when Reg_month <10 then concat(toString(Reg_year),'0',toString(Reg_month)) else concat(toString(Reg_year),toString(Reg_month)) end as mon,
      Reg_year as Year_num,Reg_month as month_num,
	  case when P_month <10 then concat('Y',toString(P_Year),'_M','0',toString(P_month)) else concat('Y',toString(P_Year),'_M',toString(P_month)) end as Repurchase_Month,
      count(Buyer_ID) as cnt
from(
select cu.Buyer_ID,cu.Merchant_code,cu.Reg_month,cu.Reg_year,ord.P_month,ord.P_Year
from Cust_Reg cu inner join datamart.V_Orders_Count ord on cu.Buyer_ID=ord.buyer_id  and cu.Merchant_code=ord.merchant_code and
concat(toString(Reg_year),toString(Reg_month))=concat(toString(P_Year),toString(P_month))
where toDateTime(cu.Store_Open_Date)<=ord.payment_date1 and toDate(ord.payment_date1) < toStartOfMonth(now())
group by cu.Buyer_ID,cu.Merchant_code,cu.Reg_month,cu.Reg_year,ord.P_month,ord.P_Year
having count(*)>1) t
group by Merchant_code,Reg_month,Reg_year,P_month,P_Year),
/*
步骤五：
计算出按照store层面每个注册年月当月份的复购人数，需要保证当前的复购次数大于一才算做复购
结果是行形式的
*/
store_purchase_row as(
select 
ar.Merchant_code as Merchant_code,ar.mon as MTH,ar.Year_num,ar.month_num,
ar.Repurchase_Month,new.cnt as new_member_cnt,ar.cnt as member_Re_cnt 
from all_repurchase_list ar join month_new_member_count new on ar.Merchant_code=new.Merchant_code and ar.mon=new.Repurchase_Month
),
/*
步骤六:添加每个注册月的注册人数
*/
store_rep_report as(
select row_number() over (order by Merchant_code,MTH) as ID,
Merchant_code,MTH,Year_num,month_num,new_member_cnt,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2019_M06')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2019_M06')) AS Y2019_M06,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2019_M07')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2019_M07')) AS Y2019_M07,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2019_M08')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2019_M08')) AS Y2019_M08,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2019_M09')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2019_M09')) AS Y2019_M09,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2019_M10')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2019_M10')) AS Y2019_M10,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2019_M11')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2019_M11')) AS Y2019_M11,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2019_M12')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2019_M12')) AS Y2019_M12,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M01')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M01')) AS Y2020_M01,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M02')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M02')) AS Y2020_M02,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M03')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M03')) AS Y2020_M03,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M04')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M04')) AS Y2020_M04,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M05')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M05')) AS Y2020_M05,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M06')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M06')) AS Y2020_M06,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M07')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M07')) AS Y2020_M07,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M08')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M08')) AS Y2020_M08,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M09')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M09')) AS Y2020_M09,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M10')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M10')) AS Y2020_M10,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M11')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M11')) AS Y2020_M11,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2020_M12')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2020_M12')) AS Y2020_M12,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M01')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M01')) AS Y2021_M01,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M02')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M02')) AS Y2021_M02,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M03')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M03')) AS Y2021_M03,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M04')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M04')) AS Y2021_M04,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M05')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M05')) AS Y2021_M05,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M06')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M06')) AS Y2021_M06,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M07')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M07')) AS Y2021_M07,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M08')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M08')) AS Y2021_M08,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M09')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M09')) AS Y2021_M09,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M10')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M10')) AS Y2021_M10,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M11')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M11')) AS Y2021_M11,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2021_M12')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2021_M12')) AS Y2021_M12,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M01')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M01')) AS Y2022_M01,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M02')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M02')) AS Y2022_M02,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M03')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M03')) AS Y2022_M03,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M04')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M04')) AS Y2022_M04,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M05')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M05')) AS Y2022_M05,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M06')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M06')) AS Y2022_M06,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M07')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M07')) AS Y2022_M07,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M08')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M08')) AS Y2022_M08,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M09')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M09')) AS Y2022_M09,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M10')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M10')) AS Y2022_M10,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M11')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M11')) AS Y2022_M11,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2022_M12')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2022_M12')) AS Y2022_M12,
multiIf(sumIf(member_Re_cnt,Repurchase_Month='Y2023_M01')=0,Null,sumIf(member_Re_cnt,Repurchase_Month='Y2023_M01')) AS Y2023_M01
from store_purchase_row
group by Merchant_code,MTH,Year_num,month_num,new_member_cnt)
select * from store_rep_report;


