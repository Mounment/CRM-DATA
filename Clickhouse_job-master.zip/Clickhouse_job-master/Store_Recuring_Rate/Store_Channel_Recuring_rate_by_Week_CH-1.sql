drop table if exists datamart.store_channel_member_natural_wk_new no delay;
CREATE TABLE datamart.store_channel_member_natural_wk_new
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.store_channel_member_natural_wk_new',
 '{replica}')
ORDER BY tuple() AS
with (
select case when DayOfWeek(now())=7 then 0 else DayOfWeek(now()) end as date1
) as  get_sunday
,v_orders_count as (
select buyer_id,pk_order_code,shop_name,merchant_code,source_type,
P_Week_tmp as P_Week,P_month,P_Year,payment_date1,Order_Channel from (
select 
buyer_id,pk_order_code,shop_name,merchant_code,source_type,
case when P_Week=53 then 1 else P_Week end as P_Week_tmp,
P_month,
case when P_Week=53 then P_Year+1 else P_Year end as P_Year,
payment_date1,
case when source_type like 'O2O%' then 'online' else 'offline' end as Order_Channel
from datamart.V_Orders_Count)),
Cust_Reg as(
select Buyer_ID,Merchant_Code,Store_Open_Date,Reg_week,Reg_mon,Reg_year,payment_date1 as Store_Reg_Date,Order_Channel from(
select 
      ord.buyer_id as Buyer_ID,
      mch.merchant_code as Merchant_Code,
      mch.open_date as Store_Open_Date,
      ord.P_Week as Reg_week,
      ord.P_month as Reg_mon,
      ord.P_Year as Reg_year,
      ord.payment_date1 as payment_date1,
      ord.Order_Channel as Order_Channel,
      row_number() over (partition by ord.buyer_id,ord.merchant_code,ord.Order_Channel order by ord.payment_date1) as Rank_By_Store
from 
datamart.merchant mch  
inner join v_orders_count ord  on mch.merchant_code=ord.merchant_code
where toDateTime(mch.open_date) <= ord.payment_date1 and mch.open_date is not null 
--and mch.open_date<>''
and toDate(ord.payment_date1) <  date_add(day, -(get_sunday),now())   
) t where t.Rank_By_Store=1
),
/*
一个人在一个门店一个渠道保留第一次交易数据
*/
txn_all as (
select
cu.Buyer_ID,cu.Merchant_Code,cu.Order_Channel,cu.Reg_week,cu.Reg_year,ord.P_Week,ord.P_Year
from Cust_Reg as cu 
inner join v_orders_count ord on cu.Buyer_ID=ord.buyer_id 
where cu.Order_Channel=ord.Order_Channel and cu.Merchant_Code=ord.merchant_code 
and cu.Store_Reg_Date<=ord.payment_date1
and toDateTime(cu.Store_Open_Date)<= ord.payment_date1
and toDate(ord.payment_date1) < date_add(day, -(get_sunday),now())
group by cu.Buyer_ID,cu.Merchant_Code,cu.Order_Channel,cu.Reg_week,cu.Reg_year,ord.P_Week,ord.P_Year
),
/*
一个门店保留一次transaction
*/
week_new_member_count as(
select 
      Merchant_Code,
      Order_Channel,
      case when Reg_week <10 then concat(toString(Reg_year),'0',toString(Reg_week)) else concat(toString(Reg_year),toString(Reg_week)) end as Reg_WK,
      case when P_Week <10 then concat(toString(P_Year),'0',toString(P_Week)) else concat(toString(P_Year),toString(P_Week)) end as Repurchase_WK,
      count(Buyer_ID) as cnt  
from txn_all 
where concat(toString(Reg_year),toString(Reg_week))=concat(toString(P_Year),toString(P_Week))
group by Merchant_Code,Order_Channel,Reg_week,Reg_year,P_Week,P_Year  
),
all_repurchase_list as(
select 
      Merchant_Code,
      Order_Channel,
      case when Reg_week <10 then concat(toString(Reg_year),'0',toString(Reg_week)) else concat(toString(Reg_year),toString(Reg_week)) end as WK,
      Reg_year as Year_num,Reg_week as Week_num,
      case when P_Week <10 then concat('Y',toString(P_Year),'_WK','0',toString(P_Week)) else concat('Y',toString(P_Year),'_WK',toString(P_Week)) end as Repurchase_WK,
      count(Buyer_ID) as cnt  
from txn_all 
where concat(toString(Reg_year),toString(Reg_week)) <> concat(toString(P_Year),toString(P_Week))
group by Merchant_Code,Order_Channel,Reg_week,Reg_year,P_Week,P_Year 
UNION distinct
select Merchant_Code,Order_Channel,
      case when Reg_week <10 then concat(toString(Reg_year),'0',toString(Reg_week)) else concat(toString(Reg_year),toString(Reg_week)) end as WK,
      Reg_year as Year_num,Reg_week as Week_num,
      case when P_Week <10 then concat('Y',toString(P_Year),'_WK','0',toString(P_Week)) else concat('Y',toString(P_Year),'_WK',toString(P_Week)) end as Repurchase_WK,
      count(Buyer_ID) as cnt
from(
select cu.Buyer_ID
       ,cu.Merchant_Code
       ,cu.Order_Channel
       ,cu.Reg_week
       ,cu.Reg_year
       ,ord.P_Week
       ,ord.P_Year
from Cust_Reg cu inner join v_orders_count ord 
on cu.Buyer_ID=ord.buyer_id  and cu.Order_Channel=ord.Order_Channel and cu.Merchant_Code=ord.merchant_code 
and concat(toString(Reg_year),toString(Reg_week))=concat(toString(P_Year),toString(P_Week))
where toDateTime(cu.Store_Open_Date)<=ord.payment_date1 
and toDate(ord.payment_date1) < date_add(day, -(get_sunday),now())
group by cu.Buyer_ID,cu.Merchant_Code,cu.Order_Channel,cu.Reg_week,cu.Reg_year,ord.P_Week,ord.P_Year
having count(*)>1) t
group by Merchant_Code,Order_Channel,Reg_week,Reg_year,P_Week,P_Year),
store_purchase_row as(
select ar.Merchant_Code,
ar.Order_Channel as Order_Channel,ar.WK,ar.Year_num,ar.Week_num,
ar.Repurchase_WK,new.cnt as new_member_cnt,ar.cnt as member_Re_cnt 
from all_repurchase_list ar join week_new_member_count new on ar.Order_Channel=new.Order_Channel 
and ar.WK=new.Repurchase_WK and ar.Merchant_Code=new.Merchant_Code
),
store_rep_report as(
select row_number() over (order by Merchant_Code,Order_Channel,WK,Year_num,Week_num) as id,
Merchant_Code,Order_Channel,WK,Year_num,Week_num,new_member_cnt,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK23')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK23')) AS Y2019_WK23,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK24')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK24')) AS Y2019_WK24,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK25')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK25')) AS Y2019_WK25,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK26')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK26')) AS Y2019_WK26,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK27')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK27')) AS Y2019_WK27,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK28')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK28')) AS Y2019_WK28,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK29')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK29')) AS Y2019_WK29,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK30')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK30')) AS Y2019_WK30,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK31')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK31')) AS Y2019_WK31,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK32')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK32')) AS Y2019_WK32,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK33')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK33')) AS Y2019_WK33,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK34')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK34')) AS Y2019_WK34,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK35')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK35')) AS Y2019_WK35,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK36')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK36')) AS Y2019_WK36,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK37')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK37')) AS Y2019_WK37,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK38')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK38')) AS Y2019_WK38,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK39')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK39')) AS Y2019_WK39,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK40')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK40')) AS Y2019_WK40,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK41')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK41')) AS Y2019_WK41,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK42')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK42')) AS Y2019_WK42,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK43')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK43')) AS Y2019_WK43,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK44')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK44')) AS Y2019_WK44,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK45')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK45')) AS Y2019_WK45,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK46')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK46')) AS Y2019_WK46,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK47')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK47')) AS Y2019_WK47,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK48')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK48')) AS Y2019_WK48,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK49')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK49')) AS Y2019_WK49,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK50')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK50')) AS Y2019_WK50,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK51')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK51')) AS Y2019_WK51,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK52')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2019_WK52')) AS Y2019_WK52,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK01')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK01')) AS Y2020_WK01,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK02')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK02')) AS Y2020_WK02,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK03')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK03')) AS Y2020_WK03,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK04')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK04')) AS Y2020_WK04,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK05')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK05')) AS Y2020_WK05,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK06')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK06')) AS Y2020_WK06,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK07')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK07')) AS Y2020_WK07,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK08')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK08')) AS Y2020_WK08,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK09')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK09')) AS Y2020_WK09,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK10')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK10')) AS Y2020_WK10,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK11')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK11')) AS Y2020_WK11,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK12')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK12')) AS Y2020_WK12,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK13')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK13')) AS Y2020_WK13,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK14')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK14')) AS Y2020_WK14,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK15')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK15')) AS Y2020_WK15,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK16')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK16')) AS Y2020_WK16,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK17')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK17')) AS Y2020_WK17,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK18')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK18')) AS Y2020_WK18,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK19')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK19')) AS Y2020_WK19,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK20')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK20')) AS Y2020_WK20,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK21')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK21')) AS Y2020_WK21,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK22')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK22')) AS Y2020_WK22,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK23')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK23')) AS Y2020_WK23,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK24')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK24')) AS Y2020_WK24,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK25')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK25')) AS Y2020_WK25,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK26')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK26')) AS Y2020_WK26,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK27')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK27')) AS Y2020_WK27,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK28')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK28')) AS Y2020_WK28,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK29')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK29')) AS Y2020_WK29,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK30')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK30')) AS Y2020_WK30,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK31')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK31')) AS Y2020_WK31,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK32')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK32')) AS Y2020_WK32,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK33')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK33')) AS Y2020_WK33,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK34')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK34')) AS Y2020_WK34,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK35')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK35')) AS Y2020_WK35,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK36')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK36')) AS Y2020_WK36,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK37')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK37')) AS Y2020_WK37,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK38')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK38')) AS Y2020_WK38,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK39')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK39')) AS Y2020_WK39,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK40')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK40')) AS Y2020_WK40,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK41')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK41')) AS Y2020_WK41,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK42')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK42')) AS Y2020_WK42,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK43')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK43')) AS Y2020_WK43,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK44')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK44')) AS Y2020_WK44,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK45')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK45')) AS Y2020_WK45,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK46')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK46')) AS Y2020_WK46,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK47')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK47')) AS Y2020_WK47,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK48')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK48')) AS Y2020_WK48,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK49')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK49')) AS Y2020_WK49,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK50')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK50')) AS Y2020_WK50,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK51')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK51')) AS Y2020_WK51,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK52')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2020_WK52')) AS Y2020_WK52,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK01')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK01')) AS Y2021_WK01,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK02')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK02')) AS Y2021_WK02,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK03')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK03')) AS Y2021_WK03,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK04')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK04')) AS Y2021_WK04,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK05')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK05')) AS Y2021_WK05,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK06')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK06')) AS Y2021_WK06,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK07')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK07')) AS Y2021_WK07,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK08')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK08')) AS Y2021_WK08,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK09')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK09')) AS Y2021_WK09,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK10')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK10')) AS Y2021_WK10,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK11')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK11')) AS Y2021_WK11,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK12')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK12')) AS Y2021_WK12,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK13')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK13')) AS Y2021_WK13,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK14')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK14')) AS Y2021_WK14,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK15')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK15')) AS Y2021_WK15,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK16')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK16')) AS Y2021_WK16,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK17')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK17')) AS Y2021_WK17,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK18')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK18')) AS Y2021_WK18,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK19')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK19')) AS Y2021_WK19,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK20')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK20')) AS Y2021_WK20,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK21')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK21')) AS Y2021_WK21,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK22')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK22')) AS Y2021_WK22,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK23')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK23')) AS Y2021_WK23,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK24')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK24')) AS Y2021_WK24,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK25')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK25')) AS Y2021_WK25,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK26')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK26')) AS Y2021_WK26,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK27')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK27')) AS Y2021_WK27,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK28')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK28')) AS Y2021_WK28,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK29')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK29')) AS Y2021_WK29,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK30')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK30')) AS Y2021_WK30,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK31')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK31')) AS Y2021_WK31,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK32')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK32')) AS Y2021_WK32,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK33')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK33')) AS Y2021_WK33,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK34')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK34')) AS Y2021_WK34,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK35')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK35')) AS Y2021_WK35,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK36')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK36')) AS Y2021_WK36,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK37')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK37')) AS Y2021_WK37,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK38')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK38')) AS Y2021_WK38,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK39')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK39')) AS Y2021_WK39,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK40')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK40')) AS Y2021_WK40,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK41')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK41')) AS Y2021_WK41,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK42')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK42')) AS Y2021_WK42,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK43')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK43')) AS Y2021_WK43,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK44')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK44')) AS Y2021_WK44,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK45')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK45')) AS Y2021_WK45,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK46')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK46')) AS Y2021_WK46,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK47')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK47')) AS Y2021_WK47,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK48')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK48')) AS Y2021_WK48,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK49')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK49')) AS Y2021_WK49,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK50')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK50')) AS Y2021_WK50,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK51')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK51')) AS Y2021_WK51,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK52')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2021_WK52')) AS Y2021_WK52,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK01')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK01')) AS Y2022_WK01,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK02')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK02')) AS Y2022_WK02,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK03')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK03')) AS Y2022_WK03,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK04')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK04')) AS Y2022_WK04,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK05')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK05')) AS Y2022_WK05,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK06')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK06')) AS Y2022_WK06,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK07')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK07')) AS Y2022_WK07,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK08')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK08')) AS Y2022_WK08,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK09')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK09')) AS Y2022_WK09,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK10')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK10')) AS Y2022_WK10,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK11')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK11')) AS Y2022_WK11,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK12')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK12')) AS Y2022_WK12,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK13')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK13')) AS Y2022_WK13,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK14')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK14')) AS Y2022_WK14,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK15')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK15')) AS Y2022_WK15,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK16')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK16')) AS Y2022_WK16,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK17')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK17')) AS Y2022_WK17,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK18')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK18')) AS Y2022_WK18,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK19')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK19')) AS Y2022_WK19,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK20')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK20')) AS Y2022_WK20,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK21')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK21')) AS Y2022_WK21,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK22')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK22')) AS Y2022_WK22,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK23')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK23')) AS Y2022_WK23,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK24')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK24')) AS Y2022_WK24,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK25')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK25')) AS Y2022_WK25,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK26')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK26')) AS Y2022_WK26,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK27')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK27')) AS Y2022_WK27,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK28')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK28')) AS Y2022_WK28,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK29')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK29')) AS Y2022_WK29,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK30')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK30')) AS Y2022_WK30,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK31')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK31')) AS Y2022_WK31,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK32')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK32')) AS Y2022_WK32,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK33')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK33')) AS Y2022_WK33,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK34')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK34')) AS Y2022_WK34,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK35')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK35')) AS Y2022_WK35,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK36')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK36')) AS Y2022_WK36,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK37')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK37')) AS Y2022_WK37,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK38')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK38')) AS Y2022_WK38,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK39')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK39')) AS Y2022_WK39,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK40')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK40')) AS Y2022_WK40,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK41')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK41')) AS Y2022_WK41,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK42')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK42')) AS Y2022_WK42,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK43')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK43')) AS Y2022_WK43,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK44')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK44')) AS Y2022_WK44,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK45')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK45')) AS Y2022_WK45,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK46')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK46')) AS Y2022_WK46,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK47')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK47')) AS Y2022_WK47,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK48')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK48')) AS Y2022_WK48,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK49')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK49')) AS Y2022_WK49,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK50')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK50')) AS Y2022_WK50,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK51')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK51')) AS Y2022_WK51,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK52')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2022_WK52')) AS Y2022_WK52,
multiIf(sumIf(member_Re_cnt,Repurchase_WK='Y2023_WK01')=0,Null,sumIf(member_Re_cnt,Repurchase_WK='Y2023_WK01')) AS Y2023_WK01
from store_purchase_row
group by Merchant_Code,Order_Channel,WK,Year_num,Week_num,new_member_cnt)
select * from store_rep_report;
