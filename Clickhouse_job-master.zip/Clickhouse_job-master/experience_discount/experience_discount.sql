insert into datamart.experience_discount
with tmp1 as
(select order_code, sum((Oprice-Pprice)*buy_qty) as supersaver_amt
from datamart.V_Order_Detail a join datamart.T_Promotion_Supersaver b on a.item_code = b.item_code
WHERE toDate(a.payment_date) >= b.Effective_date
and toDate (a.payment_date) <= b.Edate
group by order_code),
tmp2 as (select a.order_code as order_code
, a.user_id as user_id
, order_payment_confirm_date as payment_date
, sys_source as source_type
, toDecimal64(user_fee,2) as payment_amt
, toDecimal64(ifNull(c.coupon_value,0),4) as coupon_amt
, toDecimal64(ifNull(tmp1.supersaver_amt,0),6) as supersaver_amt
, toDecimal64OrZero(toString(sum(toDecimal64(amount_share_coupon,12))-toDecimal64(ifNull(coupon_value,0),12)-ifNull(supersaver_amt,0)),2) as promotion_amt
, toDecimal64(ifNull(a.member_discount,0),2) as diamond_amt
, sum(toDecimal64(amount_share_coupon,2))+toDecimal64(ifNull(a.member_discount,0),2) as total_discount_amt
, toDecimal64((sum(amount_share_coupon)+ifNull(a.member_discount,0))/(sum(amount_share_coupon)+ifNull(a.member_discount,0)+user_fee),6) as discount_share
from raw_data.mlp_oms_so a inner join datamart.V_Order_Header b on a.order_code = b.pk_order_code
left join raw_data.mlp_promotion_coupon c on b.Real_order_code = c.order_code
inner join raw_data.mlp_oms_so_item d on a.order_code = d.order_code
left join tmp1 on a.order_code = tmp1.order_code
where sys_source ='POS' and user_fee>0
and payment_date >= toDate(date_add(day, -1, now())) 
--and convert(date,payment_date) = convert(date,dateadd(day, -1, GETDATE()))
group by a.order_code, a.user_id, order_payment_confirm_date, sys_source, user_fee,
coupon_value, supersaver_amt, a.member_discount)
select t3.*,toDateTime(now()) as insert_time
from datamart.experience_discount t2
right anti join tmp2 t3
on 
t2.order_code=t3.order_code
and t2.user_id=t3.user_id
and t2.payment_date=t3.payment_date
and t2.source_type=t3.source_type
and t2.payment_amt=t3.payment_amt
and t2.coupon_amt=t3.coupon_amt
and t2.supersaver_amt=t3.supersaver_amt
and t2.promotion_amt=t3.promotion_amt
and t2.diamond_amt=t3.diamond_amt
and t2.total_discount_amt=t3.total_discount_amt
and t2.discount_share=t3.discount_share;


insert into datamart.experience_discount
with tmp1 as
(select order_code, sum((Oprice-Pprice)*buy_qty) as supersaver_amt
from datamart.V_Order_Detail a inner join datamart.T_Promotion_Supersaver b on a.item_code = b.item_code
WHERE toDate(a.payment_date) >= b.Effective_date
and toDate(a.payment_date) <= b.Edate
group by order_code),
tmp2 as (select a.order_code as order_code
, a.user_id as user_id
, order_payment_confirm_date as payment_date
, sys_source as source_type
, toDecimal64(order_amount+order_delivery_fee,2) as payment_amt
, toDecimal64(ifNull(sum(amount_share_coupon),0),4) as coupon_amt
, toDecimal64(ifNull(supersaver_amt,0),6) as supersaver_amt
, toDecimal64(ifNull(sum(e.amount_share_promotion),0),2)-ifNull(supersaver_amt,0) as promotion_amt
, toDecimal64(ifNull(a.member_discount,0),2) as diamond_amt
, toDecimal64(sum(amount_share_coupon)+ifNull(a.member_discount,0)+ifNull(sum(e.amount_share_promotion),0),2) as total_discount_amt
, toDecimal64((sum(amount_share_coupon)+ifNull(a.member_discount,0)+ifNull(sum(e.amount_share_promotion),0))/(sum(amount_share_coupon)+ifNull(a.member_discount,0)+ifNull(sum(e.amount_share_promotion),0)+order_amount+order_delivery_fee),6) as discount_share
from raw_data.mlp_oms_so a inner join datamart.V_Order_Header b on a.order_code = b.pk_order_code
inner join raw_data.mlp_oms_so_item d on a.order_code = d.order_code
left join tmp1 on a.order_code = tmp1.order_code
left join raw_data.mlp_oms_so_promotion_item e on a.order_code = e.order_code and d.id = e.so_item_id
where sys_source ='WX_O2O' and order_amount>0
and payment_date >= toDate(date_add(day, -1, now()))
--and convert(date,payment_date) = convert(date,dateadd(day, -1, GETDATE()))
group by a.order_code, a.user_id, order_payment_confirm_date, sys_source, order_amount, order_delivery_fee,
supersaver_amt, a.member_discount)
select t5.*,toDateTime(now()) as insert_time
from datamart.experience_discount t4
right anti join tmp2 t5
on 
t4.order_code=t5.order_code
and t4.user_id=t5.user_id
and t4.payment_date=t5.payment_date
and t4.source_type=t5.source_type
and t4.payment_amt=t5.payment_amt
and t4.coupon_amt=t5.coupon_amt
and t4.supersaver_amt=t5.supersaver_amt
and t4.promotion_amt=t5.promotion_amt
and t4.diamond_amt=t5.diamond_amt
and t4.total_discount_amt=t5.total_discount_amt
and t4.discount_share=t5.discount_share;
