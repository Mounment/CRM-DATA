insert into datamart.T_F_MemberTag
select 
b.user_id as Buyer_id
,'Diamond' as TagKey
,case when claim_channel = 1 then 'Organic' 
when claim_channel in ('2','3') then 'Exchange' 
when claim_channel = toString('4') then 'Invitation'
end as TagValue
,toString(toStartOfMonth(addMonths(now(),0))) as BeginDate
,toString(toStartOfMonth(addMonths(now(),1))-1) AS EndDate 
from raw_data.mlp_ouser_aldi_member_benefit b 
where b.valid_month = toString(toYYYYMM(date_add(month,-1,now()))) 
and b.level_code = toString('1001');
