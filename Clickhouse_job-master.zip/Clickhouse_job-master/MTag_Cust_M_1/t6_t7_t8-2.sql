--- monthly  1st day of month 
--Diamond: Organic/invitation/exchange
insert into datamart.T_F_MemberTag
select 
b.user_id as Buyer_id
,'Diamond' as TagKey
,case when claim_channel = 1 then 'Organic' 
when claim_channel in ('2','3') then 'Exchange' 
when claim_channel = toString('4') then 'Invitation'
else 'others' end as TagValue
,toString(toStartOfMonth(addMonths(now(),0))) as BeginDate -- first day of data load month
,toString(toStartOfMonth(addMonths(now(),1))-1) AS EndDate -- the last day of load month
,toDateTime(now()) as insert_time
from raw_data.mlp_ouser_aldi_member_benefit b 
where b.valid_month = toString(toYYYYMM(date_add(month,-1,now()))) 
and b.level_code = toString('1001');
