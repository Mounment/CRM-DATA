--#t3(part1),t4
--member_type: diamond/ non_diamond
-- monthly refresh
insert into datamart.T_F_MemberTag
select 
a.id as Buyer_id
,'Member Type' as TagKey
,case when b.user_id is null then 'non-diamond' else 'Diamond' end as TagValue  -- diamond/ non-diamond customers of current month
,toString(toStartOfMonth(addMonths(now(),0))) as BeginDate -- first day of data load month
,toString(toStartOfMonth(addMonths(now(),1))-1) AS EndDate -- the last day of load month
,toDateTime(now()) as insert_time
from raw_data.mlp_ouser_u_user a
left join raw_data.mlp_ouser_aldi_member_benefit b on a.id = b.user_id 
and b.valid_month = toString(toYYYYMM(date_add(month,-1,now()))) 
and b.level_code = toString('1001') -- those 4 customers don't exist in u_user table
where -- 上个月注册的客户 
a.create_time < toDate(toStartOfMonth(addMonths(now(),0))); 
