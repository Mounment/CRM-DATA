--- monthly  1st day of month 
--Diamond: 2mthsdiamond
insert into datamart.T_F_MemberTag
Select 
b.user_id as Buyer_id
,'Diamond' as TagKey
,'2monthsDiamond' as TagValue
,toString(toStartOfMonth(addMonths(now(),-1))) as BeginDate
,toString(toStartOfMonth(addMonths(now(),1))-1) as EndDate
,toDateTime(now()) as insert_time
from raw_data.mlp_ouser_aldi_member_benefit b
inner join raw_data.mlp_ouser_aldi_member_benefit a on a.user_id = b.user_id 
where a.valid_month = toString(toYYYYMM(date_add(MONTH,-1,now()))) 
and a.level_code = toString('1001') -- diamond customers of current month 
and b.valid_month =toString(toYYYYMM(date_add(MONTH,-2,now())))
and b.level_code = toString('1001');  -- diamond customers of previous month;
