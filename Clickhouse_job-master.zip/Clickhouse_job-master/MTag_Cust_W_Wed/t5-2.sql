--New Customer: Wednesday Weekly refresh
insert into datamart.T_F_MemberTag
select 
buyer_id
,'Member Type' as TagKey
,'New Customer' as TagValue
,date_add(dd,-7,cut_off) BeginDate
,cut_off as EndDate
,toDateTime(now()) as insert_time
from model.m_variable_final a 
where cust_m1_tenure < 7 and txn_m4_cust_micro_seg = toString('Passive');