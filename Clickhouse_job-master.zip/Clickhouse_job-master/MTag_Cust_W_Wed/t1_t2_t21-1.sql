insert into datamart.T_F_MemberTag
SELECT buyer_id as Buyer_id 
,'Member Type' as TagKey,
case when txn_m4_cust_micro_seg = 'Activated' then 'New' else txn_m4_cust_macro_seg end as TagValue
,date_add(dd,-90,cut_off) as BeginDate
,cut_off as EndDate
,toDateTime(now()) as insert_time
FROM model.m4_trmf_seg_final
where txn_m4_cust_micro_seg <> 'Passive';