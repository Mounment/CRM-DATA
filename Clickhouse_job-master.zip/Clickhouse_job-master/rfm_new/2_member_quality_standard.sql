drop table if exists datamart.tp_cus_RFM_temp1 no delay;
CREATE TABLE datamart.tp_cus_RFM_temp1
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.tp_cus_RFM_temp1',
 '{replica}')
ORDER BY tuple() AS
select lifetime_type,M_first_30d/(case when lifetime_day < 30 then lifetime_day else 30 end) as avg_M_first_30d
,case when lifetime_day <= 30 then null when lifetime_day > 30 then M_30d_180d/(case when lifetime_day < 180 then lifetime_day else 180 end-30) end as avg_M_30d_180d
,case when lifetime_day <= 180 then null when lifetime_day > 180 then M_180dPlus/(lifetime_day-180) end as avg_M_180dPlus
from datamart.tp_customer_RFM;

drop table if exists datamart.tp_cus_RFM_temp2 no delay;
CREATE TABLE datamart.tp_cus_RFM_temp2
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.tp_cus_RFM_temp2',
 '{replica}')
ORDER BY tuple() AS
select *,((rank_1_30d-1)/(buyer_cnt-1)) as prank_1_30d,((rank_30_180d-1)/(buyer_cnt-1)) as prank_30_180d,((rank_180dp-1)/(buyer_cnt-1)) as prank_180dp from (
select *,
rank () OVER (PARTITION BY lifetime_type order by avg_M_first_30d) as rank_1_30d,
rank () OVER (PARTITION BY lifetime_type order by avg_M_30d_180d) as rank_30_180d,
rank () OVER (PARTITION BY lifetime_type order by avg_M_180dPlus) as rank_180dp
,count(1) OVER (PARTITION BY lifetime_type) as buyer_cnt
from datamart.tp_cus_RFM_temp1);

drop table if exists datamart.tp_cus_RFM_temp3 no delay;
CREATE TABLE datamart.tp_cus_RFM_temp3
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.tp_cus_RFM_temp3',
 '{replica}')
ORDER BY tuple() AS
select lifetime_type
,max(tmp_1_30d_p33) as avg_1_30d_p33
,max(tmp_1_30d_p66) as avg_1_30d_p66
,max(tmp_30_180d_p33) as avg_30_180d_p33
,max(tmp_30_180d_p66) as avg_30_180d_p66
,max(tmp_180_plus_p33) as avg_180_plus_p33
,max(tmp_180_plus_p66) as avg_180_plus_p66
from (
select  lifetime_type
,case when prank_1_30d <=0.33 then rank_1_30d end as tmp_1_30d_p33
,case when prank_1_30d <=0.66 then rank_1_30d end as tmp_1_30d_p66
,case when prank_30_180d <=0.33 then rank_30_180d end as tmp_30_180d_p33
,case when prank_30_180d <=0.66 then rank_30_180d end as tmp_30_180d_p66
,case when prank_180dp <=0.33 then rank_180dp end as tmp_180_plus_p33
,case when prank_180dp <=0.66 then rank_180dp end as tmp_180_plus_p66
from datamart.tp_cus_RFM_temp2) group by lifetime_type;

drop table if exists datamart.member_quality_standard no delay;
CREATE TABLE datamart.member_quality_standard
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.member_quality_standard',
 '{replica}')
ORDER BY tuple() AS
select lifetime_type,buyer_cnt,
max(case when rank_1_30d=avg_1_30d_p33 and lifetime_type =t.lifetime_type then avg_M_first_30d end) as M_first_30d_P33,
max(case when rank_1_30d=avg_1_30d_p66 and lifetime_type =t.lifetime_type then avg_M_first_30d end) as M_first_30d_P66,
max(case when rank_30_180d=avg_30_180d_p33 and lifetime_type =t.lifetime_type then avg_M_30d_180d end) as M_30d_180d_P33,
max(case when rank_30_180d=avg_30_180d_p66 and lifetime_type =t.lifetime_type then avg_M_30d_180d end) as M_30d_180d_P66,
max(case when rank_180dp=avg_180_plus_p33 and lifetime_type =t.lifetime_type then avg_M_180dPlus end) as M_180dPlus_P33,
max(case when rank_180dp=avg_180_plus_p66 and lifetime_type =t.lifetime_type then avg_M_180dPlus end) as M_180dPlus_P66
from 
(
select *
from
datamart.tp_cus_RFM_temp2 as m
left join
datamart.tp_cus_RFM_temp3 as t
on 
m.lifetime_type=t.lifetime_type )
group by lifetime_type,buyer_cnt;
