drop table if exists datamart.tp_order_detail_temp1 no delay;
CREATE TABLE datamart.tp_order_detail_temp1
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.tp_order_detail_temp1',
 '{replica}') order by tuple() as
select a.order_code,a.source_type,a.merchant_code,max(a.shop_name) as shop_name,CASE WHEN a.source_type = 'POS' THEN a.out_order_code ELSE a.order_code END AS out_order_code,max(a.longitude) as longitude,max(a.latitude) as latitude,a.self_checkout,
a.buyer_id
,max(a.payment_date) as payment_date_DT,toDateTime(max(a.payment_date)) as payment_date,max(a.logistics_date) as logistics_date,item_code
,max(a.item_name_zh) as item_name_zh,max(item_category_name) as item_category_name ,max(item_sub_category_name) as item_sub_category_name,max(item_sub_subcategory_name) as item_sub_subcategory_name
,sum(a.buy_qty) as buy_qty,sum(a.payment_amt) as payment_amt,sum(a.coupon_amt) as coupon_amt,sum(a.promotion_amt) as promotion_amt,sum(a.coupon_amt+a.promotion_amt) as discount_amt
,sum(a.delivery_fee_amt) as delivery_fee_amt,sum(a.order_weight) as order_weight,sum(a.net_sales) as net_sales,case when a.buyer_id is not null and a.buyer_id <> '-1' then 1 else 0 end as ismember
,case when is_super_saver = 1 then 1 else 0 end as is_ss
FROM raw_data.ec_sale_order_product a join raw_data.ec_sale_order b on b.pk_order_code = a.order_code
where a.payment_date is not null
and a.source_type in ('O2O_DFS','O2O_B2C','NDD','SCAN_QR_CODE','POS','MOBILE_POS')
and a.shop_name not in ('奥乐齐零售通店')
and b.map_desc <> '已取消'
group by a.order_code,a.source_type,a.merchant_code,CASE WHEN a.source_type = 'POS' THEN a.out_order_code ELSE a.order_code END,a.buyer_id,a.self_checkout,item_code,case when a.buyer_id is not null then 1 else 0 end,is_super_saver;



drop table if exists datamart.tp_order_detail no delay;
CREATE TABLE datamart.tp_order_detail
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.tp_order_detail',
 '{replica}') order by tuple() as
select t.* 
,case when t.ismember = 1 then t.order_times_tmp end as order_times
from 
(select a.*
,row_number() over (partition by order_code order by buy_qty desc) as item_rank_qty_withinOrder
,row_number() over (partition by order_code order by payment_amt desc) as item_rank_gmv_withinOrder
,dense_rank() over (partition by buyer_id order by payment_date_DT asc) as order_times_tmp
from datamart.tp_order_detail_temp1 a )t;



drop table if exists datamart.tp_customer_order no delay;
CREATE TABLE datamart.tp_customer_order
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.tp_customer_order',
 '{replica}') order by tuple() as
select *,row_number() over (partition by buyer_id order by payment_date_DT desc) as order_rank_latest
,toMonth(payment_date) as payment_mon,toWeek(payment_date)+1 as payment_wk
from (
select order_code,source_type,merchant_code,max(shop_name) as shop_name,out_order_code as Real_order_code,buyer_id,self_checkout,ismember
,max(payment_date) as payment_date,max(payment_date_DT) as payment_date_DT,max(logistics_date) as logistics_date,max(longitude) as longitude,max(latitude) as latitude
,sum(t.buy_qty) as buy_qty,sum(t.payment_amt) as payment_amt,sum(t.coupon_amt) as coupon_amt,sum(t.promotion_amt) as promotion_amt,sum(t.coupon_amt+t.promotion_amt) as discount_amt
,sum(delivery_fee_amt) as delivery_fee_amt,sum(order_weight) as order_weight,sum(net_sales) as net_sales,max(t.order_times) as order_times
,sum(t.payment_amt)/sum(t.buy_qty) as avg_unit_price,sum(t.coupon_amt+t.promotion_amt)/sum(t.buy_qty) as avg_unit_discount,sum(t.payment_amt+t.coupon_amt+t.promotion_amt)/sum(t.buy_qty) as avg_original_price
,sum(case when is_ss = 1 then t.payment_amt else 0 end) as payment_amt_ss,sum(case when is_ss = 1 then t.buy_qty else 0 end) as buy_qty_ss
,max(case when item_rank_gmv_withinOrder = 1 then item_category_name end) as top1seller_cate_by_gmv
,max(case when item_rank_qty_withinOrder = 1 then item_category_name end) as top1seller_cate_by_qty
from datamart.tp_order_detail t
group by order_code,source_type,merchant_code,out_order_code,buyer_id,self_checkout,ismember
) a;
