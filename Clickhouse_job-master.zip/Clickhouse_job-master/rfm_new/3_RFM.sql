/*
 * Update Date: 2021-12-14
 * Update Content: add lifecycle recency to the current cut off
 */
insert into datamart.tp_customer_RFM
with addDays(now(),-1) as cutoff_tmp
select *,case when recent_status in ('1','2') then 'Churn_30Days' 
when M_30d > 0 and M_30d <= 200 then '0~200' 
when M_30d > 200 and M_30d <= 400 then '200~400' 
when M_30d > 400 and M_30d <= 600 then '400~600' 
when M_30d > 600 and M_30d <= 800 then '600~800' 
when M_30d > 800 and M_30d <= 1000 then '800~1000'
when M_30d > 1000 then '>1000' end as member_type
from (
select b.*,datediff(day,last_2nd_purchase,lifecycle_R) as reactive_from
,case when lifetime_day <= 180 then lifetime_day when lifetime_day > 180 then 200 end as lifetime_type
,case when toDateTime(lifecycle_R) between dateadd(day,-6,b.cutoff) and b.cutoff then 'Week_purchase' else 'non_purchase' end as is_purchased
,case when lifetime_day <= 30 then '1'
when lifetime_day > 30 and lifetime_day <= 180 then '2'
when lifetime_day > 180 then '3' end as lifetime_stage
-------各个阶段的quality
,case when M_first_30d/(case when lifetime_day < 30 then lifetime_day else 30 end) < a.M_first_30d_P33 then '1'    
when M_first_30d/(case when lifetime_day < 30 then lifetime_day else 30 end) > a.M_first_30d_P66 then '3' else '2' end as NC_stage_quality

,case when lifetime_day <= 30 then '0' when lifetime_day > 30 and M_30d_180d/(case when lifetime_day < 180 then lifetime_day else 180 end-30) < a.M_30d_180d_P33 then '1'   
when lifetime_day > 30 and M_30d_180d/(case when lifetime_day < 180 then lifetime_day else 180 end-30) > a.M_30d_180d_P66 then '3'  else '2' end as Growth_stage_quality

,case when lifetime_day <= 180 then '0' when lifetime_day > 180 and M_180dPlus/(lifetime_day-180) < a.M_180dPlus_P33 then '1' 
when lifetime_day > 180 and M_180dPlus/(lifetime_day-180) > a.M_180dPlus_P66 then '3' else '2' end as Mature_stage_quality
-----------近期状态，不满足唤醒条件的都算作低频次，但是属于活跃状态
,case when datediff(day,lifecycle_R,cutoff)+1 > 180 then '1'
when datediff(day,lifecycle_R,cutoff)+1 > 30 and datediff(day,lifecycle_R,cutoff)+1 <= 180 then '2'
when datediff(day,lifecycle_R,cutoff)+1 <= 30 then '3' 
when datediff(day,lifecycle_R,cutoff)+1 <= 30 and datediff(day,last_2nd_purchase,lifecycle_R)+1 > 180 then '4' 
end as recent_status
--------------近期质量表现,如果不满30天，180天怎么办,不满按照实际天数计算，一般来说不满情况下，短期和长期的情况基本相同，也就是会被判定为稳定状态
,case when ifnull(M_30d,0) = 0  then '1' 
when M_30d/(case when lifetime_day < 30 then lifetime_day else 30 end) < M_180d*cast(0.8 as Decimal(38,3))/(case when lifetime_day < 180 then lifetime_day else 180 end) then '2'
when M_30d/(case when lifetime_day < 30 then lifetime_day else 30 end) >= M_180d*cast(0.8 as Decimal(38,3))/(case when lifetime_day < 180 then lifetime_day else 180 end) and 
M_30d/(case when lifetime_day < 30 then lifetime_day else 30 end) <= M_180d*cast(1.2 as Decimal(38,3))/(case when lifetime_day < 180 then lifetime_day else 180 end) then '3'
when M_30d/(case when lifetime_day < 30 then lifetime_day else 30 end) > M_180d*cast(1.2 as Decimal(38,3))/(case when lifetime_day < 180 then lifetime_day else 180 end) then '4' end as recent_performance


from (
select cutoff_tmp as cutoff,buyer_id,min(toDate(b.create_time)) as registered_date,max(a.first_purchase) as first_purchase,max(case when order_times = 1 then order_code end ) as first_order_code
,max(case when order_times = 1 then source_type end ) as first_order_channel
,max(order_times) as lifecycle_F,count(distinct toDate(payment_date)) as lifecycle_F_day,sum(payment_amt) as lifecycle_M
,sum(buy_qty) as lifecycle_qty,sum(discount_amt) as lifecycle_discount,sum(net_sales) as lifecycle_netsales
,max(last_purchase) as lifecycle_R,max(case when toDate(payment_date) < last_purchase then toDate(payment_date) end) as last_2nd_purchase
,datediff(day,min(a.first_purchase),cutoff_tmp)+1 as lifetime_day
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') then 1 end) as lifecycle_F_offline
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') then payment_amt end) as lifecycle_M_offline
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') then buy_qty end) as lifecycle_qty_offline
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') then discount_amt end) as lifecycle_discount_offline
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') then net_sales end) as lifecycle_netsales_offline
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') then 1 end) as lifecycle_F_online
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') then payment_amt end) as lifecycle_M_online
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') then buy_qty end) as lifecycle_qty_online
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') then discount_amt end) as lifecycle_discount_online
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') then net_sales end) as lifecycle_netsales_online
,max(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') then payment_date end) as lifecycle_R_offline
,max(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') then payment_date end) as lifecycle_R_online

,sum(case when toDate(payment_date) >= toDate(a.first_purchase) and toDate(payment_date) <= dateadd(day,29,a.first_purchase) then 1 else 0 end) as F_first_30d
,ifnull(count(distinct case when toDate(payment_date) >= toDate(a.first_purchase) and toDate(payment_date) <= dateadd(day,29,a.first_purchase) then toDate(payment_date) end),0) as F_day_first_30d
,sum(case when toDate(payment_date) >= toDate(a.first_purchase) and toDate(payment_date) <= dateadd(day,29,a.first_purchase) then payment_amt else 0 end) as M_first_30d

,sum(case when toDate(payment_date) >= dateadd(day,29,a.first_purchase) and toDate(payment_date) <= dateadd(day,179,a.first_purchase) then 1 else 0 end) as F_30d_180d
,ifnull(count(distinct case when toDate(payment_date) >= dateadd(day,29,a.first_purchase) and toDate(payment_date) <= dateadd(day,179,a.first_purchase) then toDate(payment_date) end),0) as F_day_30d_180d
,sum(case when toDate(payment_date) >= dateadd(day,29,a.first_purchase) and toDate(payment_date) <= dateadd(day,179,a.first_purchase) then payment_amt else 0 end) as M_30d_180d

,sum(case when toDate(payment_date) >= dateadd(day,179,a.first_purchase) then 1 else 0 end) as F_180dPlus
,ifnull(count(distinct case when toDate(payment_date) >= dateadd(day,179,a.first_purchase) then toDate(payment_date) end),0) as F_day_180dPlus
,sum(case when toDate(payment_date) >= dateadd(day,179,a.first_purchase) then payment_amt else 0 end) as M_180dPlus
   

,sum(case when toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(year,-1,cutoff_tmp) then 1 end) as F_1y
,count(distinct case when toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(year,-1,cutoff_tmp) then toDate(payment_date) end) as F_day_1y
,sum(case when toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(year,-1,cutoff_tmp) then payment_amt end) as M_1y
	
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(year,-1,cutoff_tmp) then 1 end) as F_offline_1y
,count(distinct case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(year,-1,cutoff_tmp) then toDate(payment_date) end) as F_day_offline_1y
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(year,-1,cutoff_tmp) then payment_amt end) as M_offline_1y
   	
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(year,-1,cutoff_tmp) then 1 end) as F_online_1y
,count(distinct case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(year,-1,cutoff_tmp) then toDate(payment_date) end) as F_day_online_1y
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(year,-1,cutoff_tmp) then payment_amt end) as M_online_1y

,sum(case when toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-179,cutoff_tmp) then 1 end) as F_180d
,count(distinct case when toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-179,cutoff_tmp) then toDate(payment_date) end) as F_day_180d
,sum(case when toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-179,cutoff_tmp) then payment_amt end) as M_180d
	
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-179,cutoff_tmp) then 1 end) as F_offline_180d
,count(distinct case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-179,cutoff_tmp) then toDate(payment_date) end) as F_day_offline_180d
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-179,cutoff_tmp) then payment_amt end) as M_offline_180d
   	
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-179,cutoff_tmp) then 1 end) as F_online_180d
,count(distinct case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-179,cutoff_tmp) then toDate(payment_date) end) as F_day_online_180d
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-179,cutoff_tmp) then payment_amt end) as M_online_180d


,sum(case when toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-29,cutoff_tmp) then 1 end) as F_30d
,count(distinct case when toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-29,cutoff_tmp) then toDate(payment_date) end) as F_day_30d
,sum(case when toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-29,cutoff_tmp) then payment_amt end) as M_30d	
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-29,cutoff_tmp) then 1 end) as F_offline_30d
,count(distinct case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-29,cutoff_tmp) then toDate(payment_date) end) as F_day_offline_30d
,sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-29,cutoff_tmp) then payment_amt end) as M_offline_30d   	
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-29,cutoff_tmp) then 1 end) as F_online_30d
,count(distinct case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-29,cutoff_tmp) then toDate(payment_date) end) as F_day_online_30d
,sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff_tmp and toDate(payment_date) >= dateadd(day,-29,cutoff_tmp) then payment_amt end) as M_online_30d
-- 60 day ==> freq, monetary, offline_freq, online_freq, offline_m, online_m
, sum(case when toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day, -59, cutoff) then 1 end ) as F_60d
, sum(case when toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day, -59, cutoff) then payment_amt end) as M_60d
, sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-59, cutoff) then 1 end) as F_offline_60d
, sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-59, cutoff) then payment_amt end) as M_offline_60d
, sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-59, cutoff) then 1 end) as F_online_60d
, sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-59, cutoff) then payment_amt end) as M_online_60d

-- 90 day ==> freq, monetary, offline_freq, online_freq, offline_m, online_m
, sum(case when toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day, -89, cutoff) then 1 end ) as F_90d
, sum(case when toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day, -89, cutoff) then payment_amt end) as M_90d
, sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-89, cutoff) then 1 end) as F_offline_90d
, sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-89, cutoff) then payment_amt end) as M_offline_90d
, sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-89, cutoff) then 1 end) as F_online_90d
, sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-89, cutoff) then payment_amt end) as M_online_90d

-- 120 day ==> freq, monetary, offline_freq, online_freq, offline_m, online_m
, sum(case when toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day, -119, cutoff) then 1 end ) as F_120d
, sum(case when toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day, -119, cutoff) then payment_amt end) as M_120d
, sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-119, cutoff) then 1 end) as F_offline_120d
, sum(case when source_type in ('POS', 'SCAN_QR_CODE', 'MOBILE_POS') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-119, cutoff) then payment_amt end) as M_offline_120d
, sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-119, cutoff) then 1 end) as F_online_120d
, sum(case when source_type in ('O2O_B2C', 'O2O_DFS', 'NDD') and toDate(payment_date) <= cutoff and toDate(payment_date) >= dateadd(day,-119, cutoff) then payment_amt end) as M_online_120d
--, max(last_purchase)
, datediff(dd, a.last_purchase, cutoff_tmp) as lifecycle_R_day
from (
select *,min(toDate(payment_date)) over (partition by buyer_id) as first_purchase
,max(toDateTime(payment_date)) over (partition by buyer_id) as last_purchase
from datamart.tp_customer_order 
where ismember = 1 
and toDate(payment_date) <= cutoff_tmp
and payment_amt > 0 
) a join raw_data.mlp_ouser_u_user b on b.id = a.buyer_id
group by buyer_id, last_purchase
) b join datamart.member_quality_standard a on case when b.lifetime_day <= 180 then b.lifetime_day when b.lifetime_day > 180 then 200 end = a.lifetime_type
) c
;
