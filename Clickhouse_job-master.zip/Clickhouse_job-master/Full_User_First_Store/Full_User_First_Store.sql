drop table if exists datamart.full_user_fst_store no delay;

CREATE TABLE datamart.full_user_fst_store
ENGINE = ReplicatedMergeTree('/clickhouse/tables/{shard}/datamart/datamart.full_user_fst_store',
 '{replica}')
ORDER BY buyer_id AS
with all_user as(SELECT id,toDate(create_time) as create_time
FROM raw_data.mlp_ouser_u_user)
,
go_activity as
(select distinct b.buyer_id, a.merchant_code as merchant_code 
from analysis.go_activity a join business_domain.ec_share_code_tracking_final b 
on a.activity_id = b.activity_id 
and b.new_register_flag = 1
),
merchant_from_beh as(select distinct buds.user_id as user_id
,mc.merchant_code as merchant_code
from raw_data.mlp_bi_bi_user_behavior_source buds 
inner join model.m_variable_final var
on var.buyer_id = buds.user_id
and buds.user_id is not null
and buds.create_time between toDateTime('2019-06-07') and toDateTime('2021-03-15')
and buds.ev = 5
and buds.old_merchant_id is not null
and var.txn_m2_str_fst is null
join datamart.merchant mc
on buds.old_merchant_id = mc.id
union all
select distinct buds.user_id
,left(ms.org_code, 4) as merchant_code
from raw_data.mlp_bi_bi_user_behavior_source buds
inner join model.m_variable_final var
on var.buyer_id = buds.user_id
and buds.user_id is not null
and buds.create_time >= toDateTime('2021-03-15')
and buds.ev = 5
and buds.store_id is not null
and var.txn_m2_str_fst is null
join raw_data.mlp_merchant_store_org_info ms
on buds.store_id = ms.org_id)
,

closest_open_store as(select *
from (select a.id
,b.merchant_code as merchant_code
,row_number()over(partition by a.id order by abs(dateDiff(day,a.create_time,toDate(b.open_date)))) as rnk
from all_user a,datamart.merchant b) c
where c.rnk = 1)
,
TMP AS(SELECT *
FROM (SELECT buyer_id
,merchant_code
,row_number() over(partition by buyer_id order by payment_date1) as RNK   
FROM datamart.V_Orders_Count
WHERE merchant_code <> '8888') A
WHERE RNK = 1)
select buyer_id,Status,case when f.first_store = '8888' then ifNull(e.merchant_code,'8888') else f.first_store end as first_store
,refresh_date
from
(
select a.id as buyer_id
,case when b.buyer_id is not null then 1 else 0 end as Status
,case when g.merchant_code ='' or g.merchant_code is null THEN 
(case when b.merchant_code ='' or b.merchant_code is null THEN 
(case WHEN mfb.merchant_code ='' or mfb.merchant_code is null THEN 
d.merchant_code ELSE mfb.merchant_code end ) ELSE b.merchant_code end)ELSE g.merchant_code end as first_store
,now() as refresh_date
--into full_user_fst_store
from all_user a
left join go_activity g 
on a.id = g.buyer_id
left join (select distinct buyer_id,merchant_code from datamart.V_Orders_Count where ROW_NUMBER = 1 and buyer_id is not null) b
on (a.id) = (b.buyer_id)
left join merchant_from_beh mfb
on a.id = mfb.user_id
left join closest_open_store d
on a.id = d.id) f
left join TMP e
on f.buyer_id = e.buyer_id;
