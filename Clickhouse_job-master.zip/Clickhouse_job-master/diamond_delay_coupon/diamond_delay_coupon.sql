ALTER TABLE datamart.diamond_delay_coupon DELETE WHERE toDate(payment_date)>=toDate(date_add(day,-7,now()))
SETTINGS allow_nondeterministic_mutations=1;

insert into datamart.diamond_delay_coupon
select a.buyer_id, c.mobile, order_code, payment_date,
case when delivery_sub_result = '15<success_delay<30' then 5 when delivery_sub_result = '30<=success_delay<60' then 7 when delivery_sub_result = '60<=success_delay<120' then 10 
when delivery_sub_result = 'success_delay>=120' then 10 end as coupon_value
,toDateTime(now()) as insert_time
from datamart.experience_delivery a 
--join ouser.u_member_benefit b
inner join raw_data.mlp_ouser_aldi_member_benefit b
on a.buyer_id = b.user_id
and level_code = toString('1001')
and toString(toYYYYMM(date_add(MONTH,-1,now()))) = valid_month
and toDate(payment_date) >= toDate(dateadd(day, -7, now()))
and a.delivery_sub_result in (
'15<success_delay<30',
'30<=success_delay<60',
'60<=success_delay<120',
'success_delay>=120')
--join ouser.u_user c
inner join raw_data.mlp_ouser_u_user c
on a.buyer_id = c.id;
